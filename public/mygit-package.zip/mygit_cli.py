#!/usr/bin/env python3
"""mygit CLI launcher wrapper."""
from __future__ import annotations
import sys
import os

# Ensure UTF-8 console output on Windows (prevents 'charmap' UnicodeEncodeError)
for _stream in (sys.stdout, sys.stderr):
    if hasattr(_stream, "reconfigure"):
        try:
            _stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

# Add project root to sys.path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from mygit.cli import main
from mygit.shell import run_shell

if __name__ == "__main__":
    if len(sys.argv) == 1:
        # No args provided: launch interactive dedicated terminal!
        run_shell()
    else:
        main()
