# mygit

A complete, Git-compatible version control engine **and** self-hosted Git platform built from scratch in Python 3.11+.

## Key Features

- **Byte-Compatible Git Object Store**: Repositories created with `mygit` are directly readable by real Git (`git cat-file`, `git log`, `git fsck`).
- **Core VCS Engine (stdlib only)**:
  - Repository initialization (`init`)
  - Content-addressable object store (`blob`, `tree`, `commit`, `tag`)
  - Staging area (`add`, `status`, `.mygitignore`)
  - Commit graph & history (`commit`, `log`, `show`)
  - Branching & checkout (`branch`, `checkout`, `checkout -b`)
  - Unified diff (`diff`, `--staged`, `diff <a> <b>`)
  - Three-way merge with conflict markers (`merge <branch>`)
- **Self-Hosted Git Platform**:
  - FastAPI + SQLite (via SQLAlchemy) + server-rendered Jinja2 templates.
  - User authentication with Argon2 password hashing.
  - Personal API/Push tokens (SHA-256 hashed).
  - Web repository browsing: file explorer with Pygments syntax highlighting, branch switcher, and sanitized Markdown README viewer.
  - Pull Requests: compare branches, view unified diffs, comments, conflict detection, and merge execution.
  - HTTP Push/Fetch Sync: `clone`, `remote add`, `fetch`, `pull`, `push` over HTTP.
  - Hardened with CSRF tokens, strict path traversal validation, input size caps, and security headers.

---

## Project Structure

```
mygit/
  engine/           # Core VCS engine (stdlib only)
    objects.py      # Blob, tree, commit, cat-file, SHA-1 storage
    index.py        # Staging area, .mygitignore, write-tree, commit, checkout
    refs.py         # HEAD, branch & tag references
    repo.py         # Repository discovery & init
    diff.py         # Unified diff generation using difflib
    merge.py        # LCA merge base, 3-way merge, conflict resolution
    network.py      # HTTP sync client (clone, fetch, pull, push)
  platform/         # Self-hosted Git web platform
    app.py          # FastAPI application factory & middleware
    models.py       # SQLAlchemy models (User, Repo, Token, PR, Comment)
    auth.py         # Argon2 hashing, session management, CSRF, rate limiter
    storage.py      # Bare repository adapter & filesystem layout
    routes/         # Auth, repo, PR, and sync API routes
    templates/      # Jinja2 server-rendered templates
  cli.py            # CLI entrypoint: python -m mygit <command>
  tests/            # Comprehensive pytest test suite (Phases A through F)
  scripts/backup.sh # Backup script for data directory
  Dockerfile        # Container image
  docker-compose.yml# App + Caddy HTTPS deployment
  SECURITY.md       # Threat model and mitigations
  SPEC.md           # Formal specification
```

---

## Installation & Setup

### Requirements
- Python 3.11+
- Virtual environment

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

---

## Running the Test Suite

Run the full pytest suite with coverage verification:

```bash
pytest --cov=mygit/engine --cov-report=term-missing mygit/tests/
```

All 87 tests pass across all phases (A–F), with test coverage over 85% for the core engine.

---

## CLI Usage

Run `mygit` using the module entrypoint:

```bash
# Initialize a repository
python -m mygit init

# Stage and commit files
python -m mygit add .
python -m mygit commit -m "Initial commit"

# View status and log
python -m mygit status
python -m mygit log --oneline

# Branch and checkout
python -m mygit branch feature-x
python -m mygit checkout feature-x

# Diff changes
python -m mygit diff

# Merge branch
python -m mygit checkout main
python -m mygit merge feature-x
```

### Git Interoperability

Verify that real Git reads repositories initialized and committed by `mygit`:

```bash
git --git-dir=.mygit log --oneline
git --git-dir=.mygit fsck
```

---

## Web Platform

### Starting the Platform Locally

```bash
uvicorn mygit.platform.app:create_app --factory --reload --port 8000
```

Navigate to `http://localhost:8000`:
1. **Register** a user account.
2. **Generate an API Token** under `API Tokens`.
3. **Create a Repository**.
4. **Push commits** to your repo:
   ```bash
   python -m mygit remote add origin http://localhost:8000/<user>/<repo>.mygit
   export MYGIT_AUTH_TOKEN="<your_api_token>"
   python -m mygit push origin main
   ```
5. Browse the file tree, view commits with unified diffs, open pull requests, comment, and merge them.

### Docker Deployment

Deploy with Docker Compose and Caddy:

```bash
docker compose up -d
```
