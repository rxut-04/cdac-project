"""mygit - A Git-compatible version control engine."""
from __future__ import annotations
