"""mygit - A Git-compatible version control engine."""
