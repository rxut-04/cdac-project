"""Network sync client implementation for mygit (remote, clone, fetch, pull, push)."""

import json
import os
import urllib.request
import urllib.error
from typing import Optional

from mygit.engine.repo import find_repo_root, repo_path, init_repo
from mygit.engine.refs import resolve_ref, update_ref, set_head, read_head, resolve_head
from mygit.engine.objects import read_object, hash_object, parse_commit, parse_tree
from mygit.engine.index import checkout_tree, _get_author_info


def get_remote_url(root: str, remote_name: str = "origin") -> Optional[str]:
    """Get remote URL from config file."""
    config_file = repo_path(root, "config")
    if not os.path.isfile(config_file):
        return None
    with open(config_file, "r") as f:
        for line in f:
            line = line.strip()
            if line.startswith(f"remote.{remote_name}.url="):
                return line.split("=", 1)[1]
    return None


def set_remote_url(root: str, remote_name: str, url: str) -> None:
    """Set remote URL in config file."""
    config_file = repo_path(root, "config")
    lines = []
    if os.path.isfile(config_file):
        with open(config_file, "r") as f:
            lines = [l for l in f if not l.startswith(f"remote.{remote_name}.url=")]
    lines.append(f"remote.{remote_name}.url={url}\n")
    with open(config_file, "w") as f:
        f.writelines(lines)


def _collect_objects_for_commit(root: str, commit_sha: str, known_shas: set[str], collected: dict[str, tuple[str, bytes]]) -> None:
    """Recursively collect all objects needed for a commit."""
    if commit_sha in known_shas or commit_sha in collected:
        return

    obj_type, body = read_object(root, commit_sha)
    collected[commit_sha] = (obj_type, body)

    commit_info = parse_commit(body)
    _collect_objects_for_tree(root, commit_info["tree"], known_shas, collected)

    for parent in commit_info["parents"]:
        _collect_objects_for_commit(root, parent, known_shas, collected)


def _collect_objects_for_tree(root: str, tree_sha: str, known_shas: set[str], collected: dict[str, tuple[str, bytes]]) -> None:
    """Recursively collect all objects in a tree."""
    if tree_sha in known_shas or tree_sha in collected:
        return

    obj_type, body = read_object(root, tree_sha)
    collected[tree_sha] = (obj_type, body)

    entries = parse_tree(body)
    for mode, name, sha in entries:
        if sha in known_shas or sha in collected:
            continue
        if mode in ("40000", "040000"):
            _collect_objects_for_tree(root, sha, known_shas, collected)
        else:
            btype, bdata = read_object(root, sha)
            collected[sha] = (btype, bdata)


def push(root: str, remote_name: str = "origin", branch: Optional[str] = None, token: Optional[str] = None, client_module=None) -> None:
    """Push commits and objects to a remote repository."""
    url = get_remote_url(root, remote_name)
    if not url:
        raise ValueError(f"No remote URL configured for '{remote_name}'")

    if not branch:
        from mygit.engine.refs import get_current_branch
        branch = get_current_branch(root)
        if not branch:
            raise ValueError("Detached HEAD; specify branch to push")

    local_ref = f"refs/heads/{branch}"
    local_sha = resolve_ref(root, local_ref)
    if not local_sha:
        raise ValueError(f"Local branch '{branch}' has no commits")

    # If token not supplied, check env or stored terminal credentials
    from mygit.engine.credentials import load_token
    token = token or os.environ.get("MYGIT_AUTH_TOKEN") or load_token() or ""

    # 1. Fetch remote refs
    refs_url = f"{url.rstrip('/')}/refs"
    auth_headers = {"Authorization": f"Bearer {token}"} if token else {}
    if client_module:
        res = client_module.get(refs_url, headers=auth_headers)
        if res.status_code == 404:
            raise FileNotFoundError("Remote repository not found")
        elif res.status_code in (401, 403):
            raise PermissionError("Authentication required or access denied")
        elif res.status_code != 200:
            raise RuntimeError(f"Failed to fetch remote refs: {res.text}")
        remote_refs = res.json()
    else:
        req = urllib.request.Request(refs_url, headers=auth_headers)
        try:
            with urllib.request.urlopen(req) as resp:
                remote_refs = json.loads(resp.read().decode())
        except urllib.error.HTTPError as e:
            if e.code == 404:
                raise FileNotFoundError("Remote repository not found")
            elif e.code in (401, 403):
                raise PermissionError("Authentication required or access denied")
            raise RuntimeError(f"HTTP Error {e.code}: {e.reason}")

    # 2. Collect objects to send
    remote_sha = remote_refs.get(local_ref)
    collected_objects: dict[str, tuple[str, bytes]] = {}
    known_shas = set()
    if remote_sha:
        known_shas.add(remote_sha)

    _collect_objects_for_commit(root, local_sha, known_shas, collected_objects)

    payload_objects = [
        {"sha": sha, "type": otype, "content_hex": odata.hex()}
        for sha, (otype, odata) in collected_objects.items()
    ]

    # Collect files for the dedicated repository_files table
    from mygit.engine.index import _get_tree_entries_flat
    from mygit.engine.objects import read_object
    file_manifest = []
    try:
        tree_entries = _get_tree_entries_flat(root, local_sha)
        for fpath, (fmode, fsha) in tree_entries.items():
            content_text = None
            is_bin = False
            file_sz = 0
            try:
                _, blob_bytes = read_object(root, fsha)
                file_sz = len(blob_bytes)
                try:
                    content_text = blob_bytes[:500000].decode("utf-8")
                except UnicodeDecodeError:
                    is_bin = True
            except Exception:
                file_abs = os.path.join(root, fpath)
                if os.path.isfile(file_abs):
                    file_sz = os.path.getsize(file_abs)
                    try:
                        with open(file_abs, "r", encoding="utf-8") as f:
                            content_text = f.read(500000)
                    except Exception:
                        is_bin = True

            file_manifest.append({
                "path": fpath,
                "blob_sha": fsha,
                "size": file_sz,
                "content_text": content_text,
                "is_binary": is_bin
            })
    except Exception as e:
        pass

    # 3. Post push payload in batches to handle large repositories safely
    push_url = f"{url.rstrip('/')}/push"
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"

    def _send_chunk(payload_dict: dict) -> None:
        if client_module:
            res = client_module.post(push_url, json=payload_dict, headers=headers)
            if res.status_code == 404:
                raise FileNotFoundError("Remote repository not found")
            elif res.status_code in (401, 403):
                raise PermissionError("Authentication required or access denied")
            elif res.status_code != 200:
                raise RuntimeError(f"Push failed: {res.text}")
        else:
            try:
                req = urllib.request.Request(push_url, data=json.dumps(payload_dict).encode(), headers=headers, method="POST")
                with urllib.request.urlopen(req) as resp:
                    pass
            except urllib.error.HTTPError as err:
                if err.code == 404:
                    raise FileNotFoundError("Remote repository not found")
                elif err.code in (401, 403):
                    raise PermissionError("Authentication required or access denied")
                err_body = err.read().decode(errors="replace")
                raise RuntimeError(f"Push failed ({err.code}): {err_body or err.reason}")

    total_objects = len(payload_objects)
    BATCH_SIZE = 15
    print(f"→ Uploading {total_objects} objects & {len(file_manifest)} files...", flush=True)

    if total_objects == 0:
        final_payload = {
            "ref": local_ref,
            "target_sha": local_sha,
            "force": False,
            "objects": [],
            "files": file_manifest,
        }
        _send_chunk(final_payload)
    else:
        for idx in range(0, total_objects, BATCH_SIZE):
            chunk = payload_objects[idx:idx + BATCH_SIZE]
            is_last = (idx + BATCH_SIZE) >= total_objects
            done_count = min(idx + BATCH_SIZE, total_objects)
            print(f"→ Syncing objects ({done_count}/{total_objects})...", flush=True)

            chunk_payload = {
                "ref": local_ref if is_last else None,
                "target_sha": local_sha if is_last else None,
                "force": False,
                "objects": chunk,
                "files": file_manifest if is_last else None,
            }
            uploaded = min(idx + len(chunk), total_objects)
            pct = int((uploaded / total_objects) * 100)
            print(f"Uploading objects: {uploaded}/{total_objects} ({pct}%)...", flush=True)
            _send_chunk(chunk_payload)


def fetch(root: str, remote_name: str = "origin", client_module=None, token: Optional[str] = None) -> None:
    """Fetch objects and refs from remote."""
    url = get_remote_url(root, remote_name)
    if not url:
        raise ValueError(f"No remote URL configured for '{remote_name}'")

    from mygit.engine.credentials import load_token
    token = token or os.environ.get("MYGIT_AUTH_TOKEN") or load_token() or ""
    auth_headers = {"Authorization": f"Bearer {token}"} if token else {}

    refs_url = f"{url.rstrip('/')}/refs"
    if client_module:
        res = client_module.get(refs_url, headers=auth_headers)
        if res.status_code != 200:
            raise RuntimeError(f"Failed to fetch remote refs: {res.text}")
        remote_refs = res.json()
    else:
        req = urllib.request.Request(refs_url, headers=auth_headers)
        with urllib.request.urlopen(req) as resp:
            remote_refs = json.loads(resp.read().decode())

    # For each remote ref, fetch missing objects
    for ref, sha in remote_refs.items():
        if ref == "HEAD":
            continue
        _download_commit_and_objects(root, url, sha, client_module, token=token)
        # Update tracking ref (e.g. refs/heads/main or refs/remotes/origin/main)
        update_ref(root, ref, sha)


def _download_commit_and_objects(root: str, base_url: str, commit_sha: str, client_module=None, token: Optional[str] = None) -> None:
    """Download commit object and its hierarchy if not present locally."""
    from mygit.engine.objects import object_exists
    if object_exists(root, commit_sha):
        return

    auth_headers = {"Authorization": f"Bearer {token}"} if token else {}
    # Download raw object
    obj_url = f"{base_url.rstrip('/')}/objects/{commit_sha}"
    if client_module:
        res = client_module.get(obj_url, headers=auth_headers)
        if res.status_code != 200:
            raise RuntimeError(f"Failed to download object {commit_sha}")
        data = res.content
    else:
        req = urllib.request.Request(obj_url, headers=auth_headers)
        with urllib.request.urlopen(req) as resp:
            data = resp.read()

    # Write compressed object directly to local object store
    obj_file = os.path.join(repo_path(root, "objects", commit_sha[:2]), commit_sha[2:])
    os.makedirs(os.path.dirname(obj_file), exist_ok=True)
    with open(obj_file, "wb") as f:
        f.write(data)

    _, body = read_object(root, commit_sha)
    info = parse_commit(body)
    _download_tree_and_objects(root, base_url, info["tree"], client_module, token=token)

    for p in info["parents"]:
        _download_commit_and_objects(root, base_url, p, client_module, token=token)


def _download_tree_and_objects(root: str, base_url: str, tree_sha: str, client_module=None, token: Optional[str] = None) -> None:
    """Download tree and all child blobs recursively."""
    from mygit.engine.objects import object_exists
    auth_headers = {"Authorization": f"Bearer {token}"} if token else {}
    if not object_exists(root, tree_sha):
        obj_url = f"{base_url.rstrip('/')}/objects/{tree_sha}"
        if client_module:
            res = client_module.get(obj_url, headers=auth_headers)
            data = res.content
        else:
            req = urllib.request.Request(obj_url, headers=auth_headers)
            with urllib.request.urlopen(req) as resp:
                data = resp.read()
        obj_file = os.path.join(repo_path(root, "objects", tree_sha[:2]), tree_sha[2:])
        os.makedirs(os.path.dirname(obj_file), exist_ok=True)
        with open(obj_file, "wb") as f:
            f.write(data)

    _, body = read_object(root, tree_sha)
    entries = parse_tree(body)
    for mode, name, sha in entries:
        if not object_exists(root, sha):
            obj_url = f"{base_url.rstrip('/')}/objects/{sha}"
            if client_module:
                res = client_module.get(obj_url, headers=auth_headers)
                data = res.content
            else:
                req = urllib.request.Request(obj_url, headers=auth_headers)
                with urllib.request.urlopen(req) as resp:
                    data = resp.read()
            obj_file = os.path.join(repo_path(root, "objects", sha[:2]), sha[2:])
            os.makedirs(os.path.dirname(obj_file), exist_ok=True)
            with open(obj_file, "wb") as f:
                f.write(data)
        if mode in ("40000", "040000"):
            _download_tree_and_objects(root, base_url, sha, client_module, token=token)


def clone(url: str, target_dir: str, client_module=None) -> str:
    """Clone a repository from remote URL into target_dir."""
    abs_target = os.path.abspath(target_dir)
    os.makedirs(abs_target, exist_ok=True)
    init_repo(abs_target)

    set_remote_url(abs_target, "origin", url)
    fetch(abs_target, "origin", client_module=client_module)

    # Check out HEAD or main
    main_sha = resolve_ref(abs_target, "refs/heads/main")
    if main_sha:
        set_head(abs_target, "ref: refs/heads/main")
        checkout_tree(abs_target, main_sha)

    return abs_target


def pull(root: str, remote_name: str = "origin", branch: Optional[str] = None, client_module=None) -> None:
    """Fetch and update working tree with changes from remote."""
    from mygit.engine.refs import get_current_branch, resolve_ref
    from mygit.engine.index import checkout_tree

    if not branch:
        branch = get_current_branch(root)
        if not branch:
            raise ValueError("Detached HEAD")

    local_ref = f"refs/heads/{branch}"
    old_sha = resolve_ref(root, local_ref)

    fetch(root, remote_name, client_module=client_module)

    new_sha = resolve_ref(root, local_ref)
    if new_sha and new_sha != old_sha:
        checkout_tree(root, new_sha)
        print(f"Fast-forward {branch} -> {new_sha[:7]}")
    else:
        print("Already up to date.")
