"""Diff generation in unified format using difflib."""

import difflib
from typing import Optional

from mygit.engine.objects import parse_commit, parse_tree, read_object, resolve_sha
from mygit.engine.refs import resolve_head


def diff_blobs(
    old_content: str,
    new_content: str,
    old_path: str = "a",
    new_path: str = "b",
) -> str:
    """Generate a unified diff between two text contents.

    Args:
        old_content: Original text content.
        new_content: New text content.
        old_path: Path label for the original file.
        new_path: Path label for the new file.

    Returns:
        Unified diff string.
    """
    old_lines = old_content.splitlines(keepends=True)
    new_lines = new_content.splitlines(keepends=True)

    diff = difflib.unified_diff(
        old_lines,
        new_lines,
        fromfile=f"a/{old_path}",
        tofile=f"b/{new_path}",
    )
    return "".join(diff)


def _flatten_tree(
    root: str, tree_sha: Optional[str], prefix: str = ""
) -> dict[str, tuple[str, str]]:
    """Recursively flatten a tree into path -> (mode, sha) dict.

    Args:
        root: Repository root directory.
        tree_sha: Tree object SHA, or None for empty tree.
        prefix: Path prefix.

    Returns:
        Dict mapping file path -> (mode, blob_sha).
    """
    if tree_sha is None:
        return {}

    _, tree_body = read_object(root, tree_sha)
    entries = parse_tree(tree_body)
    result: dict[str, tuple[str, str]] = {}

    for mode, name, sha in entries:
        full_path = f"{prefix}/{name}" if prefix else name
        if mode in ("40000", "040000"):
            result.update(_flatten_tree(root, sha, full_path))
        else:
            result[full_path] = (mode, sha)

    return result


def diff_trees(
    root: str,
    old_tree_sha: Optional[str],
    new_tree_sha: Optional[str],
) -> str:
    """Generate diffs between two tree objects.

    Args:
        root: Repository root directory.
        old_tree_sha: SHA of the old tree (None for empty).
        new_tree_sha: SHA of the new tree (None for empty).

    Returns:
        Combined unified diff string.
    """
    old_entries = _flatten_tree(root, old_tree_sha)
    new_entries = _flatten_tree(root, new_tree_sha)

    all_paths = sorted(set(old_entries.keys()) | set(new_entries.keys()))
    diffs: list[str] = []

    for path in all_paths:
        old_sha = old_entries.get(path, (None, None))[1]
        new_sha = new_entries.get(path, (None, None))[1]

        if old_sha == new_sha:
            continue

        old_content = ""
        new_content = ""

        if old_sha:
            try:
                _, data = read_object(root, old_sha)
                old_content = data.decode(errors="replace")
            except Exception:
                old_content = "(binary)"

        if new_sha:
            try:
                _, data = read_object(root, new_sha)
                new_content = data.decode(errors="replace")
            except Exception:
                new_content = "(binary)"

        diff = diff_blobs(old_content, new_content, path, path)
        if diff:
            diffs.append(diff)

    return "\n".join(diffs)


def diff_working_tree(root: str) -> str:
    """Diff working tree against the index.

    Args:
        root: Repository root directory.

    Returns:
        Unified diff string.
    """
    import os
    from mygit.engine.index import read_index
    from mygit.engine.objects import hash_object

    entries = read_index(root)
    diffs: list[str] = []

    for mode, sha, path in entries:
        abs_path = os.path.join(root, path)
        if not os.path.exists(abs_path):
            # File deleted — show deletion diff
            _, old_data = read_object(root, sha)
            try:
                old_content = old_data.decode()
            except UnicodeDecodeError:
                continue
            diff = diff_blobs(old_content, "", path, path)
            if diff:
                diffs.append(diff)
            continue

        with open(abs_path, "rb") as f:
            current_data = f.read()

        current_sha = hash_object(current_data, "blob")
        if current_sha != sha:
            _, old_data = read_object(root, sha)
            try:
                old_content = old_data.decode()
                new_content = current_data.decode()
            except UnicodeDecodeError:
                continue
            diff = diff_blobs(old_content, new_content, path, path)
            if diff:
                diffs.append(diff)

    return "\n".join(diffs)


def diff_staged(root: str) -> str:
    """Diff index against HEAD.

    Args:
        root: Repository root directory.

    Returns:
        Unified diff string.
    """
    from mygit.engine.index import read_index

    entries = read_index(root)
    index_dict: dict[str, tuple[str, str]] = {
        path: (mode, sha) for mode, sha, path in entries
    }

    # Get HEAD tree
    head_sha = resolve_head(root)
    head_dict: dict[str, tuple[str, str]] = {}
    if head_sha:
        _, commit_body = read_object(root, head_sha)
        commit_info = parse_commit(commit_body)
        head_dict = _flatten_tree(root, commit_info["tree"])

    all_paths = sorted(set(index_dict.keys()) | set(head_dict.keys()))
    diffs: list[str] = []

    for path in all_paths:
        old_sha = head_dict.get(path, (None, None))[1]
        new_sha = index_dict.get(path, (None, None))[1]

        if old_sha == new_sha:
            continue

        old_content = ""
        new_content = ""

        if old_sha:
            try:
                _, data = read_object(root, old_sha)
                old_content = data.decode(errors="replace")
            except Exception:
                pass

        if new_sha:
            try:
                _, data = read_object(root, new_sha)
                new_content = data.decode(errors="replace")
            except Exception:
                pass

        diff = diff_blobs(old_content, new_content, path, path)
        if diff:
            diffs.append(diff)

    return "\n".join(diffs)


def diff_commits(root: str, ref_a: str, ref_b: str) -> str:
    """Diff between two commits/refs.

    Args:
        root: Repository root directory.
        ref_a: First commit SHA or ref name.
        ref_b: Second commit SHA or ref name.

    Returns:
        Unified diff string.
    """
    from mygit.engine.refs import resolve_ref

    # Resolve refs
    sha_a = resolve_ref(root, f"refs/heads/{ref_a}")
    if sha_a is None:
        sha_a = resolve_sha(root, ref_a)

    sha_b = resolve_ref(root, f"refs/heads/{ref_b}")
    if sha_b is None:
        sha_b = resolve_sha(root, ref_b)

    _, body_a = read_object(root, sha_a)
    _, body_b = read_object(root, sha_b)

    info_a = parse_commit(body_a)
    info_b = parse_commit(body_b)

    return diff_trees(root, info_a["tree"], info_b["tree"])
