"""Reference (branch/tag) management."""
from __future__ import annotations

import os
from typing import Optional

from mygit.engine.repo import repo_path


def read_head(root: str) -> str:
    """Read the HEAD file and return its content.

    Args:
        root: Repository root directory.

    Returns:
        HEAD content (e.g., "ref: refs/heads/main" or a bare SHA).
    """
    head_path = repo_path(root, "HEAD")
    with open(head_path, "r") as f:
        return f.read().strip()


def is_detached(root: str) -> bool:
    """Check if HEAD is detached (points directly to a SHA, not a ref).

    Args:
        root: Repository root directory.

    Returns:
        True if HEAD is a bare SHA (detached).
    """
    head = read_head(root)
    return not head.startswith("ref: ")


def get_current_branch(root: str) -> Optional[str]:
    """Get the name of the current branch.

    Args:
        root: Repository root directory.

    Returns:
        Branch name (e.g., "main"), or None if HEAD is detached.
    """
    head = read_head(root)
    if head.startswith("ref: "):
        ref = head[5:]  # Strip "ref: "
        if ref.startswith("refs/heads/"):
            return ref[len("refs/heads/"):]
        return ref
    return None


def resolve_ref(root: str, ref: str) -> Optional[str]:
    """Resolve a ref to a SHA.

    Args:
        root: Repository root directory.
        ref: Reference path (e.g., "refs/heads/main").

    Returns:
        40-char hex SHA, or None if the ref doesn't exist.
    """
    ref_path = repo_path(root, ref)
    if os.path.isfile(ref_path):
        with open(ref_path, "r") as f:
            return f.read().strip()
    return None


def resolve_head(root: str) -> Optional[str]:
    """Resolve HEAD to a SHA (following symbolic refs).

    Args:
        root: Repository root directory.

    Returns:
        40-char hex SHA, or None if no commits exist yet.
    """
    head = read_head(root)
    if head.startswith("ref: "):
        return resolve_ref(root, head[5:])
    # Detached HEAD — it's a bare SHA
    return head if len(head) == 40 else None


def update_ref(root: str, ref: str, sha: str) -> None:
    """Update a ref to point to a SHA.

    Args:
        root: Repository root directory.
        ref: Reference path (e.g., "refs/heads/main").
        sha: 40-char hex SHA.
    """
    ref_path = repo_path(root, ref)
    os.makedirs(os.path.dirname(ref_path), exist_ok=True)
    with open(ref_path, "w") as f:
        f.write(sha + "\n")


def delete_ref(root: str, ref: str) -> None:
    """Delete a ref.

    Args:
        root: Repository root directory.
        ref: Reference path (e.g., "refs/heads/feature").

    Raises:
        FileNotFoundError: If the ref doesn't exist.
    """
    ref_path = repo_path(root, ref)
    if not os.path.isfile(ref_path):
        raise FileNotFoundError(f"Ref not found: {ref}")
    os.remove(ref_path)


def set_head(root: str, value: str) -> None:
    """Set HEAD to a symbolic ref or a bare SHA.

    Args:
        root: Repository root directory.
        value: Either "ref: refs/heads/<branch>" or a 40-char SHA.
    """
    head_path = repo_path(root, "HEAD")
    with open(head_path, "w") as f:
        f.write(value + "\n")


def list_branches(root: str) -> list[str]:
    """List all branches.

    Args:
        root: Repository root directory.

    Returns:
        Sorted list of branch names.
    """
    heads_dir = repo_path(root, "refs", "heads")
    if not os.path.isdir(heads_dir):
        return []
    return sorted(os.listdir(heads_dir))


def list_tags(root: str) -> list[str]:
    """List all tags.

    Args:
        root: Repository root directory.

    Returns:
        Sorted list of tag names.
    """
    tags_dir = repo_path(root, "refs", "tags")
    if not os.path.isdir(tags_dir):
        return []
    return sorted(os.listdir(tags_dir))


def list_all_refs(root: str) -> dict[str, str]:
    """List all refs and their SHAs.

    Args:
        root: Repository root directory.

    Returns:
        Dict mapping ref path to SHA.
    """
    result: dict[str, str] = {}
    refs_dir = repo_path(root, "refs")
    if not os.path.isdir(refs_dir):
        return result

    for dirpath, _dirnames, filenames in os.walk(refs_dir):
        for name in filenames:
            full_path = os.path.join(dirpath, name)
            # Get path relative to .mygit/
            rel_path = os.path.relpath(full_path, repo_path(root))
            with open(full_path, "r") as f:
                sha = f.read().strip()
            result[rel_path] = sha

    return result
