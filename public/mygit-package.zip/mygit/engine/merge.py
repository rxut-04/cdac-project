"""Three-way merge with conflict detection."""
from __future__ import annotations

import os
import time
from typing import Optional

from mygit.engine.objects import (
    build_commit,
    hash_object,
    parse_commit,
    read_object,
)
from mygit.engine.index import (
    _flatten_tree,
    _get_author_info,
    _get_tz_offset,
    add_paths,
    checkout_tree,
    read_index,
    write_index,
)
from mygit.engine.refs import (
    get_current_branch,
    read_head,
    resolve_head,
    resolve_ref,
    update_ref,
)


def find_merge_base(root: str, sha_a: str, sha_b: str) -> Optional[str]:
    """Find the merge base (lowest common ancestor) of two commits.

    Uses a simple BFS approach.

    Args:
        root: Repository root directory.
        sha_a: First commit SHA.
        sha_b: Second commit SHA.

    Returns:
        SHA of the merge base, or None if no common ancestor.
    """
    # Collect all ancestors of sha_a
    ancestors_a: set[str] = set()
    queue = [sha_a]
    while queue:
        current = queue.pop(0)
        if current in ancestors_a:
            continue
        ancestors_a.add(current)
        _, body = read_object(root, current)
        info = parse_commit(body)
        queue.extend(info["parents"])

    # Walk sha_b's ancestors until we find one in ancestors_a
    queue = [sha_b]
    visited: set[str] = set()
    while queue:
        current = queue.pop(0)
        if current in visited:
            continue
        visited.add(current)
        if current in ancestors_a:
            return current
        _, body = read_object(root, current)
        info = parse_commit(body)
        queue.extend(info["parents"])

    return None


def _three_way_merge_text(
    base: str, ours: str, theirs: str,
    ours_label: str = "HEAD",
    theirs_label: str = "theirs",
) -> tuple[str, bool]:
    """Three-way merge of text content at file level.

    Args:
        base: Base (common ancestor) content.
        ours: Our (current branch) content.
        theirs: Their (merge source) content.
        ours_label: Label for our side in conflict markers.
        theirs_label: Label for their side in conflict markers.

    Returns:
        Tuple of (merged_content, has_conflicts).
    """
    base_lines = base.splitlines(keepends=True)
    ours_lines = ours.splitlines(keepends=True)
    theirs_lines = theirs.splitlines(keepends=True)

    # If ours == base, take theirs
    if ours_lines == base_lines:
        return theirs, False

    # If theirs == base, take ours
    if theirs_lines == base_lines:
        return ours, False

    # If both changed identically
    if ours_lines == theirs_lines:
        return ours, False

    # Simple line-by-line merge using difflib
    import difflib

    # Get changes from base -> ours and base -> theirs
    matcher_ours = difflib.SequenceMatcher(None, base_lines, ours_lines)
    matcher_theirs = difflib.SequenceMatcher(None, base_lines, theirs_lines)

    # Simplified approach: use diff3-style merge
    # For simplicity, we'll detect if both sides changed and mark conflicts
    result_lines: list[str] = []
    has_conflicts = False

    # Get opcodes for both sides
    ours_changes: dict[int, str] = {}  # base line index -> change
    theirs_changes: dict[int, str] = {}

    # Build maps of what each side did to each base line
    # This is a simplified merge that works at the whole-file level
    # For a more correct merge, we'd need a proper diff3 algorithm

    # Simple approach: if both modified, conflict; otherwise take the change
    # We use a chunk-based approach
    ours_opcodes = matcher_ours.get_opcodes()
    theirs_opcodes = matcher_theirs.get_opcodes()

    # Convert opcodes to a set of changed base line ranges
    def get_changed_ranges(opcodes):
        changed = set()
        for tag, i1, i2, j1, j2 in opcodes:
            if tag != "equal":
                for i in range(i1, max(i2, i1 + 1)):
                    changed.add(i)
        return changed

    ours_changed = get_changed_ranges(ours_opcodes)
    theirs_changed = get_changed_ranges(theirs_opcodes)

    # Check if changes overlap
    overlap = ours_changed & theirs_changed
    if not overlap:
        # No overlapping changes — apply both
        # Apply theirs changes to base, then ours changes
        # For simplicity: if only ours changed, use ours; if only theirs, use theirs
        # Interleave by going through base lines
        result = _apply_non_conflicting(
            base_lines, ours_lines, theirs_lines,
            ours_opcodes, theirs_opcodes
        )
        return result, False
    else:
        # Conflicts exist
        has_conflicts = True
        merged = []
        merged.append(f"<<<<<<< {ours_label}\n")
        merged.extend(ours_lines)
        merged.append(f"=======\n")
        merged.extend(theirs_lines)
        merged.append(f">>>>>>> {theirs_label}\n")
        return "".join(merged), True


def _apply_non_conflicting(
    base_lines: list[str],
    ours_lines: list[str],
    theirs_lines: list[str],
    ours_opcodes: list,
    theirs_opcodes: list,
) -> str:
    """Apply non-conflicting changes from both sides.

    Simple approach: build result by walking through base and applying changes.

    Returns:
        Merged content string.
    """
    # Build a map from base positions to replacements
    # for each side. Since there are no conflicts, we can apply both.

    # For simplicity with non-overlapping changes:
    # - Start with ours (which has our changes applied)
    # - Then apply theirs' changes on top of base too
    # This is a simplification — a real diff3 would be more precise.

    # Actually, the simplest correct approach for non-overlapping:
    # Take ours result, then find what theirs changed from base and apply those too.

    # Even simpler: since changes don't overlap, we can:
    # 1. For lines only changed by ours: use ours
    # 2. For lines only changed by theirs: use theirs
    # 3. For unchanged lines: use base

    # Build the result by processing chunks from theirs perspective,
    # but using ours where ours made changes.

    # Most correct simple approach: apply theirs' diff to ours
    # (since ours already has our changes, and theirs changes don't overlap)
    import difflib

    # Get what theirs changed from base
    result_lines = list(ours_lines)  # Start with ours

    # Find theirs insertions/changes relative to base
    # and apply them to our result. Since no overlap, this is safe.

    # Actually, simplest approach that works:
    # We know ours and theirs changes don't overlap in base lines.
    # Walk base lines, for each:
    #   - if ours changed it, use ours' version
    #   - if theirs changed it, use theirs' version
    #   - if neither, use base

    # Map base lines to their replacements
    ours_map: dict[int, list[str]] = {}  # base_idx -> replacement lines
    theirs_map: dict[int, list[str]] = {}

    for tag, i1, i2, j1, j2 in ours_opcodes:
        if tag == "replace":
            ours_map[i1] = list(ours_lines[j1:j2])
            for i in range(i1 + 1, i2):
                ours_map[i] = []  # consumed
        elif tag == "insert":
            ours_map.setdefault(i1, [])
            ours_map[i1] = list(ours_lines[j1:j2]) + ours_map.get(i1, [base_lines[i1]] if i1 < len(base_lines) else [])
        elif tag == "delete":
            for i in range(i1, i2):
                ours_map[i] = []

    for tag, i1, i2, j1, j2 in theirs_opcodes:
        if tag == "replace":
            theirs_map[i1] = list(theirs_lines[j1:j2])
            for i in range(i1 + 1, i2):
                theirs_map[i] = []
        elif tag == "insert":
            theirs_map.setdefault(i1, [])
            theirs_map[i1] = list(theirs_lines[j1:j2]) + theirs_map.get(i1, [base_lines[i1]] if i1 < len(base_lines) else [])
        elif tag == "delete":
            for i in range(i1, i2):
                theirs_map[i] = []

    result = []
    for i in range(len(base_lines)):
        if i in ours_map:
            result.extend(ours_map[i])
        elif i in theirs_map:
            result.extend(theirs_map[i])
        else:
            result.append(base_lines[i])

    # Handle trailing inserts (at end of file)
    # Check the last opcodes for inserts past the end
    for tag, i1, i2, j1, j2 in ours_opcodes:
        if tag == "insert" and i1 >= len(base_lines):
            result.extend(ours_lines[j1:j2])
    for tag, i1, i2, j1, j2 in theirs_opcodes:
        if tag == "insert" and i1 >= len(base_lines):
            result.extend(theirs_lines[j1:j2])

    return "".join(result)


def merge_branch(root: str, branch_name: str) -> dict:
    """Merge a branch into the current branch.

    Args:
        root: Repository root directory.
        branch_name: Name of the branch to merge.

    Returns:
        Dict with keys:
        - fast_forward: bool
        - conflicts: list of conflicted file paths
        - sha: commit SHA (if merge succeeded)
    """
    current_branch = get_current_branch(root)
    if current_branch is None:
        raise ValueError("Cannot merge in detached HEAD state")

    head_sha = resolve_head(root)
    if head_sha is None:
        raise ValueError("Cannot merge: no commits on current branch")

    target_sha = resolve_ref(root, f"refs/heads/{branch_name}")
    if target_sha is None:
        raise ValueError(f"Branch not found: {branch_name}")

    if head_sha == target_sha:
        return {"fast_forward": False, "conflicts": [], "sha": head_sha}

    # Find merge base
    base_sha = find_merge_base(root, head_sha, target_sha)

    # Fast-forward: if base == HEAD, just move HEAD to target
    if base_sha == head_sha:
        update_ref(root, f"refs/heads/{current_branch}", target_sha)
        checkout_tree(root, target_sha)
        return {"fast_forward": True, "conflicts": [], "sha": target_sha}

    # Fast-forward: if base == target, already up to date
    if base_sha == target_sha:
        return {"fast_forward": False, "conflicts": [], "sha": head_sha}

    # Three-way merge
    base_tree = {}
    if base_sha:
        base_tree = _get_commit_tree_entries(root, base_sha)

    ours_tree = _get_commit_tree_entries(root, head_sha)
    theirs_tree = _get_commit_tree_entries(root, target_sha)

    all_paths = sorted(
        set(base_tree.keys()) | set(ours_tree.keys()) | set(theirs_tree.keys())
    )

    conflicts: list[str] = []
    merged_entries: list[tuple[str, str, str]] = []

    for path in all_paths:
        base_entry = base_tree.get(path)
        ours_entry = ours_tree.get(path)
        theirs_entry = theirs_tree.get(path)

        base_sha_file = base_entry[1] if base_entry else None
        ours_sha_file = ours_entry[1] if ours_entry else None
        theirs_sha_file = theirs_entry[1] if theirs_entry else None

        # Both sides identical
        if ours_sha_file == theirs_sha_file:
            if ours_entry:
                merged_entries.append((ours_entry[0], ours_entry[1], path))
            continue

        # Only one side changed from base
        if ours_sha_file == base_sha_file and theirs_sha_file != base_sha_file:
            if theirs_entry:
                merged_entries.append((theirs_entry[0], theirs_entry[1], path))
            # else: theirs deleted it, and ours didn't change — accept deletion
            continue

        if theirs_sha_file == base_sha_file and ours_sha_file != base_sha_file:
            if ours_entry:
                merged_entries.append((ours_entry[0], ours_entry[1], path))
            continue

        # Both sides changed differently — try text merge
        base_content = _get_blob_content(root, base_sha_file)
        ours_content = _get_blob_content(root, ours_sha_file)
        theirs_content = _get_blob_content(root, theirs_sha_file)

        merged_content, has_conflict = _three_way_merge_text(
            base_content, ours_content, theirs_content,
            ours_label="HEAD",
            theirs_label=branch_name,
        )

        if has_conflict:
            conflicts.append(path)
            # Write conflicted file to working tree
            abs_path = os.path.join(root, path)
            os.makedirs(os.path.dirname(abs_path), exist_ok=True)
            with open(abs_path, "w") as f:
                f.write(merged_content)
        else:
            # Write merged content as blob
            merged_sha = hash_object(
                merged_content.encode(), "blob", write=True, root=root
            )
            mode = ours_entry[0] if ours_entry else theirs_entry[0] if theirs_entry else "100644"
            merged_entries.append((mode, merged_sha, path))

    if conflicts:
        # Don't create commit, write what we can to index
        write_index(root, merged_entries)
        return {"fast_forward": False, "conflicts": conflicts, "sha": ""}

    # Success — create merge commit
    write_index(root, merged_entries)

    # Build tree from merged entries
    from mygit.engine.index import write_tree
    tree_sha = write_tree(root)

    name, email = _get_author_info(root)
    timestamp = int(time.time())
    tz_offset = _get_tz_offset()

    commit_body = build_commit(
        tree_sha=tree_sha,
        parents=[head_sha, target_sha],
        author=name,
        author_email=email,
        committer=name,
        committer_email=email,
        message=f"Merge branch '{branch_name}' into {current_branch}",
        timestamp=timestamp,
        tz_offset=tz_offset,
    )

    commit_sha = hash_object(commit_body, "commit", write=True, root=root)
    update_ref(root, f"refs/heads/{current_branch}", commit_sha)

    # Update working tree
    checkout_tree(root, commit_sha)

    return {"fast_forward": False, "conflicts": [], "sha": commit_sha}


def _get_commit_tree_entries(
    root: str, commit_sha: str
) -> dict[str, tuple[str, str]]:
    """Get flattened tree entries from a commit.

    Args:
        root: Repository root directory.
        commit_sha: Commit SHA.

    Returns:
        Dict mapping path -> (mode, blob_sha).
    """
    _, body = read_object(root, commit_sha)
    info = parse_commit(body)
    return _flatten_tree(root, info["tree"], "")


def _get_blob_content(root: str, sha: Optional[str]) -> str:
    """Get blob content as string.

    Args:
        root: Repository root directory.
        sha: Blob SHA, or None for empty content.

    Returns:
        File content string.
    """
    if sha is None:
        return ""
    _, data = read_object(root, sha)
    return data.decode(errors="replace")
