"""Index (staging area) management.

The index is stored as a text file at .mygit/index:
    # mygit index v1
    <mode> <sha-hex> <path>
    ...

Entries are sorted by path.
"""
from __future__ import annotations

import fnmatch
import os
import time
from typing import Optional

from mygit.engine.objects import (
    build_commit,
    build_tree,
    hash_object,
    parse_commit,
    parse_tree,
    read_object,
)
from mygit.engine.refs import (
    get_current_branch,
    read_head,
    resolve_head,
    resolve_ref,
    set_head,
    update_ref,
)
from mygit.engine.repo import repo_path

INDEX_HEADER = "# mygit index v1"


def read_index(root: str) -> list[tuple[str, str, str]]:
    """Read the index file.

    Args:
        root: Repository root directory.

    Returns:
        List of (mode, sha, path) tuples, sorted by path.
    """
    index_path = repo_path(root, "mygit-index")
    if not os.path.isfile(index_path):
        return []

    entries: list[tuple[str, str, str]] = []
    with open(index_path, "r") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split(" ", 2)
            if len(parts) == 3:
                entries.append((parts[0], parts[1], parts[2]))

    return sorted(entries, key=lambda e: e[2])


def write_index(root: str, entries: list[tuple[str, str, str]]) -> None:
    """Write the index file.

    Args:
        root: Repository root directory.
        entries: List of (mode, sha, path) tuples.
    """
    index_path = repo_path(root, "mygit-index")
    sorted_entries = sorted(entries, key=lambda e: e[2])

    with open(index_path, "w") as f:
        f.write(INDEX_HEADER + "\n")
        for mode, sha, path in sorted_entries:
            f.write(f"{mode} {sha} {path}\n")


def _read_ignore_patterns(root: str) -> list[str]:
    """Read .mygitignore and .gitignore patterns.

    Args:
        root: Repository root directory.

    Returns:
        List of glob patterns.
    """
    patterns: list[str] = []
    for filename in (".mygitignore", ".gitignore"):
        ignore_file = os.path.join(root, filename)
        if not os.path.isfile(ignore_file):
            continue
        with open(ignore_file, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and line not in patterns:
                    patterns.append(line)
    return patterns


def _is_ignored(path: str, patterns: list[str]) -> bool:
    """Check if a path matches any ignore pattern.

    Args:
        path: Relative file path.
        patterns: List of glob patterns.

    Returns:
        True if the path should be ignored.
    """
    # Always ignore .mygit directory
    if path == ".mygit" or path.startswith(".mygit/") or path.startswith(".mygit\\"):
        return True

    for pattern in patterns:
        if fnmatch.fnmatch(path, pattern):
            return True
        # Also match against the basename
        if fnmatch.fnmatch(os.path.basename(path), pattern):
            return True
    return False


def add_paths(root: str, paths: list[str]) -> None:
    """Stage files or directories.

    Args:
        root: Repository root directory.
        paths: List of file/directory paths to stage (relative or absolute).
    """
    entries = read_index(root)
    entry_dict: dict[str, tuple[str, str]] = {e[2]: (e[0], e[1]) for e in entries}
    ignore_patterns = _read_ignore_patterns(root)

    for path in paths:
        abs_path = os.path.join(root, path) if not os.path.isabs(path) else path
        abs_path = os.path.normpath(abs_path)

        if os.path.isfile(abs_path):
            rel_path = os.path.relpath(abs_path, root)
            # Normalize to forward slashes
            rel_path = rel_path.replace(os.sep, "/")
            if _is_ignored(rel_path, ignore_patterns):
                continue
            _add_file(root, rel_path, entry_dict)
        elif os.path.isdir(abs_path):
            for dirpath, dirnames, filenames in os.walk(abs_path):
                # Filter out ignored directories
                dirnames[:] = [
                    d for d in dirnames
                    if not _is_ignored(
                        os.path.relpath(os.path.join(dirpath, d), root).replace(os.sep, "/"),
                        ignore_patterns,
                    )
                ]
                for filename in filenames:
                    file_abs = os.path.join(dirpath, filename)
                    rel_path = os.path.relpath(file_abs, root).replace(os.sep, "/")
                    if _is_ignored(rel_path, ignore_patterns):
                        continue
                    _add_file(root, rel_path, entry_dict)
        else:
            raise FileNotFoundError(f"Path not found: {path}")

    # Convert back to list
    new_entries = [(mode, sha, path) for path, (mode, sha) in entry_dict.items()]
    write_index(root, new_entries)


def _add_file(
    root: str, rel_path: str, entry_dict: dict[str, tuple[str, str]]
) -> None:
    """Add a single file to the index dict.

    Args:
        root: Repository root directory.
        rel_path: Path relative to the repository root.
        entry_dict: Mutable dict mapping path -> (mode, sha).
    """
    abs_path = os.path.join(root, rel_path)
    with open(abs_path, "rb") as f:
        data = f.read()

    sha = hash_object(data, "blob", write=True, root=root)

    # Determine mode
    if os.path.islink(abs_path):
        mode = "120000"
    elif os.access(abs_path, os.X_OK):
        mode = "100755"
    else:
        mode = "100644"

    entry_dict[rel_path] = (mode, sha)


def status(root: str) -> dict:
    """Compute repository status.

    Args:
        root: Repository root directory.

    Returns:
        Dict with keys:
        - staged: list of (change_type, path) for index vs HEAD
        - modified: list of paths modified in working tree vs index
        - deleted: list of paths deleted from working tree but in index
        - untracked: list of untracked file paths
    """
    index_entries = read_index(root)
    index_dict: dict[str, tuple[str, str]] = {
        e[2]: (e[0], e[1]) for e in index_entries
    }

    # Get HEAD tree entries
    head_dict: dict[str, tuple[str, str]] = {}
    head_sha = resolve_head(root)
    if head_sha:
        head_dict = _get_tree_entries_flat(root, head_sha)

    # Staged changes (index vs HEAD)
    staged: list[tuple[str, str]] = []
    for path, (mode, sha) in index_dict.items():
        if path not in head_dict:
            staged.append(("new file", path))
        elif head_dict[path] != (mode, sha):
            staged.append(("modified", path))
    for path in head_dict:
        if path not in index_dict:
            staged.append(("deleted", path))

    # Working tree changes
    modified: list[str] = []
    deleted: list[str] = []
    for path, (mode, sha) in index_dict.items():
        abs_path = os.path.join(root, path)
        if not os.path.exists(abs_path):
            deleted.append(path)
        else:
            with open(abs_path, "rb") as f:
                current_data = f.read()
            current_sha = hash_object(current_data, "blob")
            if current_sha != sha:
                modified.append(path)

    # Untracked files
    ignore_patterns = _read_ignore_patterns(root)
    untracked: list[str] = []
    for dirpath, dirnames, filenames in os.walk(root):
        # Filter out ignored directories
        dirnames[:] = [
            d for d in dirnames
            if not _is_ignored(
                os.path.relpath(os.path.join(dirpath, d), root).replace(os.sep, "/"),
                ignore_patterns,
            )
        ]
        for filename in filenames:
            abs_path = os.path.join(dirpath, filename)
            rel_path = os.path.relpath(abs_path, root).replace(os.sep, "/")
            if _is_ignored(rel_path, ignore_patterns):
                continue
            if rel_path not in index_dict:
                untracked.append(rel_path)

    return {
        "staged": staged,
        "modified": modified,
        "deleted": deleted,
        "untracked": untracked,
    }


def _get_tree_entries_flat(
    root: str, commit_sha: str
) -> dict[str, tuple[str, str]]:
    """Get all file entries from a commit's tree, flattened.

    Args:
        root: Repository root directory.
        commit_sha: Commit SHA.

    Returns:
        Dict mapping path -> (mode, sha) for all files.
    """
    _, commit_body = read_object(root, commit_sha)
    commit_info = parse_commit(commit_body)
    tree_sha = commit_info["tree"]
    return _flatten_tree(root, tree_sha, "")


def _flatten_tree(
    root: str, tree_sha: str, prefix: str
) -> dict[str, tuple[str, str]]:
    """Recursively flatten a tree into file entries.

    Args:
        root: Repository root directory.
        tree_sha: Tree object SHA.
        prefix: Path prefix for entries.

    Returns:
        Dict mapping full path -> (mode, sha).
    """
    _, tree_body = read_object(root, tree_sha)
    entries = parse_tree(tree_body)
    result: dict[str, tuple[str, str]] = {}

    for mode, name, sha in entries:
        full_path = f"{prefix}{name}" if not prefix else f"{prefix}/{name}"
        if mode == "40000" or mode == "040000":
            result.update(_flatten_tree(root, sha, full_path))
        else:
            result[full_path] = (mode, sha)

    return result


def write_tree(root: str) -> str:
    """Build tree objects from the current index.

    Args:
        root: Repository root directory.

    Returns:
        SHA of the root tree object.
    """
    entries = read_index(root)
    if not entries:
        raise ValueError("Nothing to commit (empty index)")

    return _build_tree_recursive(root, entries, "")


def _build_tree_recursive(
    root: str,
    entries: list[tuple[str, str, str]],
    prefix: str,
) -> str:
    """Recursively build tree objects from index entries.

    Args:
        root: Repository root directory.
        entries: All index entries (mode, sha, path).
        prefix: Current directory prefix.

    Returns:
        SHA of the tree object for this level.
    """
    tree_entries: list[tuple[str, str, str]] = []  # (mode, name, sha)
    # Group entries by their top-level component at this prefix
    children: dict[str, list[tuple[str, str, str]]] = {}

    for mode, sha, path in entries:
        if prefix:
            if not path.startswith(prefix + "/"):
                continue
            remaining = path[len(prefix) + 1:]
        else:
            remaining = path

        if "/" in remaining:
            # This entry is in a subdirectory
            dirname = remaining.split("/")[0]
            if dirname not in children:
                children[dirname] = []
            children[dirname].append((mode, sha, path))
        else:
            # Direct child file
            tree_entries.append((mode, remaining, sha))

    # Create subtrees
    for dirname, child_entries in sorted(children.items()):
        child_prefix = f"{prefix}/{dirname}" if prefix else dirname
        subtree_sha = _build_tree_recursive(root, child_entries, child_prefix)
        tree_entries.append(("40000", dirname, subtree_sha))

    tree_data = build_tree(tree_entries)
    return hash_object(tree_data, "tree", write=True, root=root)


def _get_author_info(root: str) -> tuple[str, str]:
    """Get author name and email from config or environment.

    Args:
        root: Repository root directory.

    Returns:
        (name, email) tuple.
    """
    # Check environment variables first
    name = os.environ.get("MYGIT_AUTHOR_NAME")
    email = os.environ.get("MYGIT_AUTHOR_EMAIL")

    if name and email:
        return name, email

    # Try config file
    config_path = repo_path(root, "config")
    if os.path.isfile(config_path):
        with open(config_path, "r") as f:
            for line in f:
                line = line.strip()
                if line.startswith("name="):
                    name = name or line[5:]
                elif line.startswith("email="):
                    email = email or line[6:]

    return name or "mygit user", email or "mygit@localhost"


def _get_tz_offset() -> str:
    """Get the current timezone offset as a string like '+0530' or '-0800'.

    Returns:
        Timezone offset string.
    """
    # Get UTC offset in seconds
    utc_offset = time.timezone if time.daylight == 0 else time.altzone
    # time.timezone is seconds WEST of UTC, so negate for the conventional sign
    utc_offset = -utc_offset
    sign = "+" if utc_offset >= 0 else "-"
    utc_offset = abs(utc_offset)
    hours = utc_offset // 3600
    minutes = (utc_offset % 3600) // 60
    return f"{sign}{hours:02d}{minutes:02d}"


def commit(root: str, message: str) -> str:
    """Create a commit from the current index.

    Args:
        root: Repository root directory.
        message: Commit message.

    Returns:
        SHA of the new commit.

    Raises:
        ValueError: If nothing to commit.
    """
    tree_sha = write_tree(root)
    name, email = _get_author_info(root)

    # Get parent
    parents: list[str] = []
    head_sha = resolve_head(root)
    if head_sha:
        parents.append(head_sha)

    timestamp = int(time.time())
    tz_offset = _get_tz_offset()

    commit_body = build_commit(
        tree_sha=tree_sha,
        parents=parents,
        author=name,
        author_email=email,
        committer=name,
        committer_email=email,
        message=message,
        timestamp=timestamp,
        tz_offset=tz_offset,
    )

    commit_sha = hash_object(commit_body, "commit", write=True, root=root)

    # Update branch ref
    head = read_head(root)
    if head.startswith("ref: "):
        ref = head[5:]
        update_ref(root, ref, commit_sha)
    else:
        # Detached HEAD — just update HEAD
        set_head(root, commit_sha)

    return commit_sha


def has_uncommitted_changes(root: str) -> bool:
    """Check if there are uncommitted changes (staged or working tree).

    Args:
        root: Repository root directory.

    Returns:
        True if there are uncommitted changes.
    """
    result = status(root)
    return bool(
        result["staged"] or result["modified"] or result["deleted"]
    )


def checkout_tree(root: str, commit_sha: str) -> None:
    """Restore working tree from a commit.

    Args:
        root: Repository root directory.
        commit_sha: SHA of the commit to check out.
    """
    # Get current files from index
    current_entries = read_index(root)
    current_paths = {e[2] for e in current_entries}

    # Get target tree entries
    target_dict = _get_tree_entries_flat(root, commit_sha)

    # Remove files not in target
    for path in current_paths:
        if path not in target_dict:
            abs_path = os.path.join(root, path)
            if os.path.exists(abs_path):
                os.remove(abs_path)
                # Clean up empty directories
                _cleanup_empty_dirs(root, os.path.dirname(abs_path))

    # Write target files
    for path, (mode, sha) in target_dict.items():
        abs_path = os.path.join(root, path)
        os.makedirs(os.path.dirname(abs_path), exist_ok=True)
        _, data = read_object(root, sha)
        with open(abs_path, "wb") as f:
            f.write(data)
        # Set executable bit if needed
        if mode == "100755":
            os.chmod(abs_path, 0o755)

    # Update index
    new_entries = [
        (mode, sha, path) for path, (mode, sha) in target_dict.items()
    ]
    write_index(root, new_entries)


def _cleanup_empty_dirs(root: str, dir_path: str) -> None:
    """Remove empty directories up to the repo root.

    Args:
        root: Repository root directory.
        dir_path: Directory to start cleaning from.
    """
    while dir_path and dir_path != root and os.path.isdir(dir_path):
        try:
            os.rmdir(dir_path)
            dir_path = os.path.dirname(dir_path)
        except OSError:
            break
