"""Repository initialization and discovery."""
from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

MYGIT_DIR = ".mygit"


def find_repo_root(start: Optional[str] = None) -> str:
    """Walk up from `start` (default: cwd) until a .mygit directory is found.

    Returns the directory containing .mygit.
    Raises FileNotFoundError if no repository is found.
    """
    path = Path(start) if start else Path.cwd()
    path = path.resolve()

    while True:
        if (path / MYGIT_DIR).is_dir():
            return str(path)
        parent = path.parent
        if parent == path:
            raise FileNotFoundError(
                "fatal: not a mygit repository (or any parent up to mount point /)"
            )
        path = parent


def repo_path(root: str, *parts: str) -> str:
    """Return an absolute path inside the .mygit directory.

    Args:
        root: Repository root (directory containing .mygit).
        *parts: Path components relative to .mygit/.

    Returns:
        Absolute path string.
    """
    return os.path.join(root, MYGIT_DIR, *parts)


def init_repo(path: Optional[str] = None) -> str:
    """Initialize a new mygit repository.

    Creates .mygit/ with objects/, refs/heads/, refs/tags/, and HEAD.

    Args:
        path: Directory to initialize. Defaults to current directory.

    Returns:
        Absolute path to the repository root.

    Raises:
        FileExistsError: If .mygit already exists.
    """
    root = os.path.abspath(path) if path else os.getcwd()
    mygit_dir = os.path.join(root, MYGIT_DIR)

    if os.path.exists(mygit_dir):
        raise FileExistsError(f"Already a mygit repository: {mygit_dir}")

    os.makedirs(os.path.join(mygit_dir, "objects"), exist_ok=True)
    os.makedirs(os.path.join(mygit_dir, "refs", "heads"), exist_ok=True)
    os.makedirs(os.path.join(mygit_dir, "refs", "tags"), exist_ok=True)

    head_path = os.path.join(mygit_dir, "HEAD")
    with open(head_path, "w") as f:
        f.write("ref: refs/heads/main\n")

    return root
