"""mygit engine - Core VCS functionality (stdlib only)."""
from __future__ import annotations
