"""mygit engine - Core VCS functionality (stdlib only)."""
