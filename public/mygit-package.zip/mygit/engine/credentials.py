"""Terminal credential and JWT token management for mygit CLI.

Enables 'mygit login', 'mygit whoami', and 'mygit logout', securely storing
the bearer token in ~/.mygit/credentials with 0600 permissions.
"""

import json
import os
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Dict, List, Optional


def get_credentials_dir() -> str:
    """Return the user config directory (~/.mygit)."""
    creds_dir = os.path.expanduser("~/.mygit")
    if not os.path.exists(creds_dir):
        os.makedirs(creds_dir, mode=0o700, exist_ok=True)
    return creds_dir


def get_credentials_file() -> str:
    """Return path to the credentials JSON file (~/.mygit/credentials)."""
    return os.path.join(get_credentials_dir(), "credentials")


def save_credentials(
    token: str,
    username: str,
    email: str,
    user_id: Optional[int] = None,
    backend_url: str = "http://localhost:8080",
) -> None:
    """Save token and identity to ~/.mygit/credentials with restrictive permissions (0600)."""
    creds_path = get_credentials_file()
    payload = {
        "token": token,
        "username": username,
        "email": email,
        "id": user_id,
        "backend_url": backend_url.rstrip("/"),
    }

    # Write file with private permissions
    flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC
    fd = os.open(creds_path, flags, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)


def load_credentials() -> Optional[Dict[str, Any]]:
    """Load credentials from ~/.mygit/credentials, if present."""
    creds_path = get_credentials_file()
    if not os.path.isfile(creds_path):
        return None
    try:
        with open(creds_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def load_token() -> Optional[str]:
    """Retrieve auth token from environment or ~/.mygit/credentials."""
    env_token = os.environ.get("MYGIT_AUTH_TOKEN")
    if env_token:
        return env_token.strip()

    creds = load_credentials()
    if creds and "token" in creds:
        return creds["token"]
    return None


def clear_credentials() -> bool:
    """Remove ~/.mygit/credentials on logout."""
    creds_path = get_credentials_file()
    if os.path.isfile(creds_path):
        try:
            os.remove(creds_path)
            return True
        except OSError:
            return False
    return False


def login_to_backend(
    email: str,
    password: str,
    backend_url: str = "http://localhost:8080",
) -> Dict[str, Any]:
    """Authenticate with Spring Boot backend (/api/auth/login) and persist JWT."""
    url = f"{backend_url.rstrip('/')}/api/auth/login"
    payload = json.dumps({"email": email, "password": password}).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=payload,
        headers={"Content-Type": "application/json", "Accept": "application/json"},
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            token = data.get("token")
            username = data.get("username", email.split("@")[0])
            user_id = data.get("id")

            if not token:
                raise ValueError("Server response did not include an authorization token.")

            save_credentials(
                token=token,
                username=username,
                email=email,
                user_id=user_id,
                backend_url=backend_url,
            )
            return data
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8")
        try:
            err_json = json.loads(body)
            msg = err_json.get("error", err_json.get("message", f"HTTP {e.code}"))
        except Exception:
            msg = f"HTTP {e.code}: {e.reason}"
        raise ValueError(f"Authentication failed: {msg}")
    except urllib.error.URLError as e:
        raise RuntimeError(f"Could not connect to authentication server at {backend_url}: {e.reason}")


def verify_session(
    token: Optional[str] = None,
    backend_url: Optional[str] = None,
) -> Dict[str, Any]:
    """Verify session against /api/auth/me using stored or provided JWT."""
    creds = load_credentials()
    resolved_token = token or (creds.get("token") if creds else None) or os.environ.get("MYGIT_AUTH_TOKEN")
    resolved_url = (backend_url or (creds.get("backend_url") if creds else None) or "http://localhost:8080").rstrip("/")

    if not resolved_token:
        raise ValueError("No authentication token found. Please run 'mygit login' first.")

    url = f"{resolved_url}/api/auth/me"
    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {resolved_token}",
            "Accept": "application/json",
        },
        method="GET",
    )

    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        if e.code == 401:
            raise ValueError("Authentication token is expired or invalid. Please run 'mygit login' again.")
        body = e.read().decode("utf-8")
        raise RuntimeError(f"HTTP {e.code}: {body}")
    except urllib.error.URLError as e:
        raise RuntimeError(f"Could not reach server at {resolved_url}: {e.reason}")


def create_remote_repo(
    name: str,
    description: str = "",
    is_private: bool = False,
    token: Optional[str] = None,
    backend_url: Optional[str] = None,
) -> Dict[str, Any]:
    """Create/insert a repository in the authenticated user's cloud workspace (Neon DB)."""
    creds = load_credentials()
    resolved_token = token or (creds.get("token") if creds else None) or os.environ.get("MYGIT_AUTH_TOKEN")
    resolved_url = (backend_url or (creds.get("backend_url") if creds else None) or "http://localhost:8080").rstrip("/")

    if not resolved_token:
        raise ValueError("No authentication token found. Please run 'mygit login' first.")

    url = f"{resolved_url}/api/repos"
    payload = json.dumps({
        "name": name,
        "description": description or f"Repository {name}",
        "isPrivate": is_private,
    }).encode("utf-8")

    req = urllib.request.Request(
        url,
        data=payload,
        headers={
            "Authorization": f"Bearer {resolved_token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8")
        if e.code == 409:
            raise FileExistsError(f"Repository '{name}' already exists in your cloud workspace.")
        if e.code == 401:
            raise PermissionError("Session expired or invalid token. Run 'mygit login' to re-authenticate.")
        try:
            err_json = json.loads(body)
            msg = err_json.get("error", err_json.get("message", f"HTTP {e.code}"))
        except Exception:
            msg = f"HTTP {e.code}: {body}"
        raise RuntimeError(f"Failed to create cloud repository: {msg}")
    except urllib.error.URLError as e:
        raise ConnectionError(f"Could not reach backend at {resolved_url}: {e.reason}")


def list_remote_repos(
    token: Optional[str] = None,
    backend_url: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """List all repositories belonging to the authenticated user from the cloud backend."""
    creds = load_credentials()
    resolved_token = token or (creds.get("token") if creds else None) or os.environ.get("MYGIT_AUTH_TOKEN")
    resolved_url = (backend_url or (creds.get("backend_url") if creds else None) or "http://localhost:8080").rstrip("/")

    if not resolved_token:
        raise ValueError("No authentication token found. Please run 'mygit login' first.")

    url = f"{resolved_url}/api/repos"
    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {resolved_token}",
            "Accept": "application/json",
        },
        method="GET",
    )

    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        if e.code == 401:
            raise PermissionError("Session expired or invalid token. Run 'mygit login' to re-authenticate.")
        body = e.read().decode("utf-8")
        raise RuntimeError(f"HTTP {e.code}: {body}")
    except urllib.error.URLError as e:
        raise ConnectionError(f"Could not reach backend at {resolved_url}: {e.reason}")


def delete_remote_repo(
    name: str,
    token: Optional[str] = None,
    backend_url: Optional[str] = None,
) -> Dict[str, Any]:
    """Delete a repository from the user's cloud workspace."""
    creds = load_credentials()
    resolved_token = token or (creds.get("token") if creds else None) or os.environ.get("MYGIT_AUTH_TOKEN")
    resolved_url = (backend_url or (creds.get("backend_url") if creds else None) or "http://localhost:8080").rstrip("/")

    if not resolved_token:
        raise ValueError("No authentication token found. Please run 'mygit login' first.")

    url = f"{resolved_url}/api/repos/{urllib.parse.quote(name)}"
    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {resolved_token}",
            "Accept": "application/json",
        },
        method="DELETE",
    )

    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        if e.code == 404:
            raise FileNotFoundError(f"Repository '{name}' not found in your workspace.")
        if e.code == 401:
            raise PermissionError("Session expired or invalid token. Run 'mygit login' to re-authenticate.")
        body = e.read().decode("utf-8")
        raise RuntimeError(f"HTTP {e.code}: {body}")
    except urllib.error.URLError as e:
        raise ConnectionError(f"Could not reach backend at {resolved_url}: {e.reason}")
