"""Git-compatible object storage: blob, tree, commit.

Objects are stored as zlib(b"<type> <size>\\0<body>") at
.mygit/objects/<sha[:2]>/<sha[2:]>.

SHA-1 is computed over the uncompressed header+body.
"""
from __future__ import annotations

import hashlib
import os
import zlib
from typing import Optional, Tuple

from mygit.engine.repo import repo_path

# Maximum decompressed object size (100 MB) to prevent zip bombs
MAX_OBJECT_SIZE = 100 * 1024 * 1024

VALID_OBJECT_TYPES = frozenset({b"blob", b"tree", b"commit", b"tag"})


def hash_object(
    data: bytes,
    obj_type: str = "blob",
    write: bool = False,
    root: Optional[str] = None,
) -> str:
    """Compute the SHA-1 hash of an object, optionally writing it to the store.

    Args:
        data: Raw object body (e.g., file content for blobs).
        obj_type: Object type ("blob", "tree", "commit", "tag").
        write: If True, write the object to the store.
        root: Repository root directory. Required if write is True.

    Returns:
        Hex SHA-1 string (40 chars).

    Raises:
        ValueError: If obj_type is invalid.
    """
    if obj_type.encode() not in VALID_OBJECT_TYPES:
        raise ValueError(f"Invalid object type: {obj_type}")

    header = f"{obj_type} {len(data)}\0".encode()
    full_content = header + data
    sha = hashlib.sha1(full_content).hexdigest()

    if write:
        if root is None:
            raise ValueError("root is required when write=True")
        _write_object(root, sha, full_content)

    return sha


def _write_object(root: str, sha: str, full_content: bytes) -> None:
    """Write a compressed object to the object store.

    Args:
        root: Repository root directory.
        sha: Hex SHA-1 of the object.
        full_content: Uncompressed header+body bytes.
    """
    obj_dir = repo_path(root, "objects", sha[:2])
    obj_file = os.path.join(obj_dir, sha[2:])

    if os.path.exists(obj_file):
        return  # Object already exists (content-addressable)

    os.makedirs(obj_dir, exist_ok=True)
    compressed = zlib.compress(full_content)

    # Atomic write: write to temp file then rename
    tmp_file = obj_file + ".tmp"
    try:
        with open(tmp_file, "wb") as f:
            f.write(compressed)
        os.rename(tmp_file, obj_file)
    except Exception:
        if os.path.exists(tmp_file):
            os.remove(tmp_file)
        raise


def read_object(root: str, sha: str) -> Tuple[str, bytes]:
    """Read an object from the store.

    Args:
        root: Repository root directory.
        sha: Full or abbreviated hex SHA-1 (minimum 4 chars).

    Returns:
        Tuple of (object_type, body_bytes).

    Raises:
        ValueError: If SHA is too short, ambiguous, or object is malformed.
        FileNotFoundError: If object doesn't exist.
    """
    full_sha = resolve_sha(root, sha)
    obj_file = os.path.join(repo_path(root, "objects", full_sha[:2]), full_sha[2:])

    with open(obj_file, "rb") as f:
        compressed = f.read()

    raw = zlib.decompress(compressed)

    if len(raw) > MAX_OBJECT_SIZE:
        raise ValueError(f"Object too large: {len(raw)} bytes (max {MAX_OBJECT_SIZE})")

    # Parse header: "<type> <size>\0<body>"
    null_idx = raw.index(b"\0")
    header = raw[:null_idx]
    body = raw[null_idx + 1:]

    parts = header.split(b" ", 1)
    if len(parts) != 2:
        raise ValueError(f"Malformed object header: {header!r}")

    obj_type = parts[0]
    declared_size = int(parts[1])

    if obj_type not in VALID_OBJECT_TYPES:
        raise ValueError(f"Unknown object type: {obj_type!r}")

    if len(body) != declared_size:
        raise ValueError(
            f"Size mismatch: header says {declared_size}, body is {len(body)}"
        )

    return obj_type.decode(), body


def object_exists(root: str, sha: str) -> bool:
    """Check if an object exists in the store.

    Args:
        root: Repository root directory.
        sha: Full hex SHA-1 (40 chars).

    Returns:
        True if the object file exists.
    """
    obj_file = os.path.join(repo_path(root, "objects", sha[:2]), sha[2:])
    return os.path.isfile(obj_file)


def resolve_sha(root: str, abbrev: str) -> str:
    """Resolve an abbreviated SHA to a full 40-char hex SHA.

    Args:
        root: Repository root directory.
        abbrev: Abbreviated SHA (minimum 4 characters).

    Returns:
        Full 40-character hex SHA-1.

    Raises:
        ValueError: If SHA is too short or ambiguous.
        FileNotFoundError: If no matching object is found.
    """
    if len(abbrev) < 4:
        raise ValueError(f"SHA too short (minimum 4 chars): {abbrev}")

    if len(abbrev) == 40:
        obj_file = os.path.join(
            repo_path(root, "objects", abbrev[:2]), abbrev[2:]
        )
        if not os.path.isfile(obj_file):
            raise FileNotFoundError(f"Object not found: {abbrev}")
        return abbrev

    prefix_dir = repo_path(root, "objects", abbrev[:2])
    if not os.path.isdir(prefix_dir):
        raise FileNotFoundError(f"Object not found: {abbrev}")

    suffix = abbrev[2:]
    matches = [
        abbrev[:2] + name
        for name in os.listdir(prefix_dir)
        if name.startswith(suffix)
    ]

    if len(matches) == 0:
        raise FileNotFoundError(f"Object not found: {abbrev}")
    if len(matches) > 1:
        raise ValueError(
            f"Ambiguous SHA prefix {abbrev}: matches {', '.join(sorted(matches))}"
        )

    return matches[0]


# ── Tree helpers ──────────────────────────────────────────────────────────


def make_tree_entry(mode: str, name: str, sha: str) -> bytes:
    """Create a single tree entry in Git binary format.

    Format: b"<mode> <name>\\0<20-byte raw sha>"

    Args:
        mode: Octal mode string (e.g., "100644").
        name: Entry name (filename or directory name).
        sha: Hex SHA-1 of the referenced object.

    Returns:
        Bytes for this tree entry.
    """
    sha_bytes = bytes.fromhex(sha)
    return f"{mode} {name}\0".encode() + sha_bytes


def tree_sort_key(name: str, mode: str) -> str:
    """Sort key for tree entries: directories sort as if name ends with '/'.

    Args:
        name: Entry name.
        mode: Octal mode string.

    Returns:
        Sort key string.
    """
    if mode == "040000" or mode == "40000":
        return name + "/"
    return name


def build_tree(entries: list[tuple[str, str, str]]) -> bytes:
    """Build a tree object body from a list of entries.

    Args:
        entries: List of (mode, name, sha) tuples.

    Returns:
        Binary tree body (without header).
    """
    sorted_entries = sorted(entries, key=lambda e: tree_sort_key(e[1], e[0]))
    parts: list[bytes] = []
    for mode, name, sha in sorted_entries:
        parts.append(make_tree_entry(mode, name, sha))
    return b"".join(parts)


def parse_tree(data: bytes) -> list[tuple[str, str, str]]:
    """Parse a tree object body into entries.

    Args:
        data: Raw tree object body.

    Returns:
        List of (mode, name, sha_hex) tuples.
    """
    entries: list[tuple[str, str, str]] = []
    i = 0
    while i < len(data):
        # Find the space separating mode from name
        space_idx = data.index(b" ", i)
        mode = data[i:space_idx].decode()

        # Find the null separating name from SHA
        null_idx = data.index(b"\0", space_idx)
        name = data[space_idx + 1:null_idx].decode()

        # Next 20 bytes are the raw SHA
        sha_bytes = data[null_idx + 1:null_idx + 21]
        sha_hex = sha_bytes.hex()

        entries.append((mode, name, sha_hex))
        i = null_idx + 21

    return entries


# ── Commit helpers ────────────────────────────────────────────────────────


def build_commit(
    tree_sha: str,
    parents: list[str],
    author: str,
    author_email: str,
    committer: str,
    committer_email: str,
    message: str,
    timestamp: Optional[int] = None,
    tz_offset: str = "+0000",
) -> bytes:
    """Build a commit object body.

    Args:
        tree_sha: SHA of the tree object.
        parents: List of parent commit SHAs.
        author: Author name.
        author_email: Author email.
        committer: Committer name.
        committer_email: Committer email.
        message: Commit message.
        timestamp: Unix timestamp (defaults to current time).
        tz_offset: Timezone offset string (e.g., "+0530").

    Returns:
        Commit body bytes.
    """
    import time

    if timestamp is None:
        timestamp = int(time.time())

    lines: list[str] = []
    lines.append(f"tree {tree_sha}")
    for parent in parents:
        lines.append(f"parent {parent}")
    lines.append(f"author {author} <{author_email}> {timestamp} {tz_offset}")
    lines.append(f"committer {committer} <{committer_email}> {timestamp} {tz_offset}")
    lines.append("")
    lines.append(message)

    return "\n".join(lines).encode()


def parse_commit(data: bytes) -> dict:
    """Parse a commit object body into its components.

    Args:
        data: Raw commit body bytes.

    Returns:
        Dict with keys: tree, parents, author, committer, message.
    """
    text = data.decode()
    # Split at the first blank line
    header_end = text.index("\n\n")
    header = text[:header_end]
    message = text[header_end + 2:]  # Skip the blank line

    result: dict = {
        "tree": "",
        "parents": [],
        "author": "",
        "committer": "",
        "message": message,
    }

    for line in header.split("\n"):
        if line.startswith("tree "):
            result["tree"] = line[5:]
        elif line.startswith("parent "):
            result["parents"].append(line[7:])
        elif line.startswith("author "):
            result["author"] = line[7:]
        elif line.startswith("committer "):
            result["committer"] = line[10:]

    return result


def cat_file_pretty(root: str, sha: str) -> str:
    """Pretty-print an object (like git cat-file -p).

    Args:
        root: Repository root directory.
        sha: Full or abbreviated SHA.

    Returns:
        Human-readable string representation.
    """
    obj_type, body = read_object(root, sha)

    if obj_type == "blob":
        try:
            return body.decode()
        except UnicodeDecodeError:
            return f"(binary data, {len(body)} bytes)"

    if obj_type == "tree":
        entries = parse_tree(body)
        lines: list[str] = []
        for mode, name, entry_sha in entries:
            # Determine object type for display
            if mode.startswith("04"):
                entry_type = "tree"
            else:
                entry_type = "blob"
            # Pad mode to 6 digits for display
            display_mode = mode.zfill(6)
            lines.append(f"{display_mode} {entry_type} {entry_sha}\t{name}")
        return "\n".join(lines)

    if obj_type == "commit":
        return body.decode()

    return body.decode()
