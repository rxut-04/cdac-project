"""mygit CLI - argparse entrypoint."""

import argparse
import os
import sys
from typing import Optional


def main(argv: Optional[list[str]] = None) -> None:
    """Main CLI entrypoint for mygit."""
    parser = argparse.ArgumentParser(
        prog="mygit",
        description="A Git-compatible version control system\nCreated by Om Raut (CDAC Pass Out Student)",
        epilog="Created with ❤️ by Om Raut (CDAC Pass Out Student)",
    )
    parser.add_argument(
        "-v", "--version",
        action="version",
        version="mygit v1.0.0 (Created by Om Raut - CDAC Pass Out Student)",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # init
    p_init = subparsers.add_parser("init", help="Initialize a new repository and register with cloud workspace")
    p_init.add_argument("path", nargs="?", default=".", help="Directory to initialize")
    p_init.add_argument("--no-remote", action="store_true", help="Do not register repository with cloud workspace")
    p_init.add_argument("--desc", default="", help="Repository description for cloud workspace")
    p_init.add_argument("--private", action="store_true", help="Set repository to private in cloud workspace")

    # hash-object
    p_hash = subparsers.add_parser("hash-object", help="Compute object hash")
    p_hash.add_argument("-w", action="store_true", help="Write object to store")
    p_hash.add_argument("-t", "--type", default="blob", help="Object type")
    p_hash.add_argument("file", help="File to hash")

    # cat-file
    p_cat = subparsers.add_parser("cat-file", help="Display object contents")
    group = p_cat.add_mutually_exclusive_group(required=True)
    group.add_argument("-p", action="store_true", help="Pretty-print object")
    group.add_argument("-t", action="store_true", help="Show object type")
    group.add_argument("-s", action="store_true", help="Show object size")
    p_cat.add_argument("sha", help="Object SHA")

    # write-tree
    subparsers.add_parser("write-tree", help="Create a tree from the index")

    # add
    p_add = subparsers.add_parser("add", help="Stage files")
    p_add.add_argument("paths", nargs="+", help="Files/directories to stage")

    # status
    subparsers.add_parser("status", help="Show working tree status")

    # commit
    p_commit = subparsers.add_parser("commit", help="Create a commit")
    p_commit.add_argument("-m", "--message", required=True, help="Commit message")

    # log
    p_log = subparsers.add_parser("log", help="Show commit history")
    p_log.add_argument("--oneline", action="store_true", help="One-line format")

    # show
    p_show = subparsers.add_parser("show", help="Show a commit")
    p_show.add_argument("commit", nargs="?", default="HEAD", help="Commit to show")

    # branch
    p_branch = subparsers.add_parser("branch", help="Manage branches")
    p_branch.add_argument("name", nargs="?", help="Branch name to create")
    p_branch.add_argument("-d", "--delete", action="store_true", help="Delete branch")

    # checkout
    p_checkout = subparsers.add_parser("checkout", help="Switch branches or restore files")
    p_checkout.add_argument("target", help="Branch name or SHA")
    p_checkout.add_argument("-b", action="store_true", help="Create and checkout new branch")

    # diff
    p_diff = subparsers.add_parser("diff", help="Show differences")
    p_diff.add_argument("--staged", action="store_true", help="Diff index vs HEAD")
    p_diff.add_argument("a", nargs="?", help="First commit/ref")
    p_diff.add_argument("b", nargs="?", help="Second commit/ref")

    # merge
    p_merge = subparsers.add_parser("merge", help="Merge a branch")
    p_merge.add_argument("branch", help="Branch to merge")

    # tag
    p_tag = subparsers.add_parser("tag", help="Create a tag")
    p_tag.add_argument("name", nargs="?", help="Tag name")

    # remote
    p_remote = subparsers.add_parser("remote", help="Manage remotes")
    p_remote_sub = p_remote.add_subparsers(dest="remote_command")
    p_remote_add = p_remote_sub.add_parser("add", help="Add a remote")
    p_remote_add.add_argument("remote_name", help="Remote name")
    p_remote_add.add_argument("url", help="Remote URL")

    # clone
    p_clone = subparsers.add_parser("clone", help="Clone a repository")
    p_clone.add_argument("url", help="Repository URL")
    p_clone.add_argument("directory", nargs="?", help="Target directory")

    # fetch
    p_fetch = subparsers.add_parser("fetch", help="Fetch from remote")
    p_fetch.add_argument("remote", nargs="?", default="origin", help="Remote name")

    # pull
    p_pull = subparsers.add_parser("pull", help="Pull from remote")
    p_pull.add_argument("remote", nargs="?", default="origin", help="Remote name")
    p_pull.add_argument("refspec", nargs="?", help="Branch to pull")

    # push
    p_push = subparsers.add_parser("push", help="Push to remote")
    p_push.add_argument("-u", "--set-upstream", action="store_true", help="Set upstream tracking branch")
    p_push.add_argument("-f", "--force", action="store_true", help="Force push")
    p_push.add_argument("remote", nargs="?", default="origin", help="Remote name")
    p_push.add_argument("refspec", nargs="?", help="Branch to push")

    # login (terminal JWT flow)
    p_login = subparsers.add_parser("login", help="Log in to mygit backend and store JWT credentials")
    p_login.add_argument("-e", "--email", help="Account email address")
    p_login.add_argument("-p", "--password", help="Account password")
    p_login.add_argument("--url", default="http://localhost:8080", help="Backend base URL (default: http://localhost:8080)")

    # logout
    subparsers.add_parser("logout", help="Log out and remove stored credentials")

    # whoami
    p_whoami = subparsers.add_parser("whoami", help="Display current authenticated user profile")
    p_whoami.add_argument("--url", help="Backend base URL override")

    # repo (cloud repository management)
    p_repo = subparsers.add_parser("repo", help="Manage cloud repositories in your Neon DB workspace")
    p_repo_sub = p_repo.add_subparsers(dest="repo_command", help="Repository commands")

    p_repo_list = p_repo_sub.add_parser("list", help="List cloud repositories")
    p_repo_list.add_argument("--url", help="Backend base URL override")

    p_repo_create = p_repo_sub.add_parser("create", help="Create a repository in your cloud workspace")
    p_repo_create.add_argument("name", help="Repository name")
    p_repo_create.add_argument("--desc", default="", help="Repository description")
    p_repo_create.add_argument("--private", action="store_true", help="Set repository to private")
    p_repo_create.add_argument("--init", action="store_true", help="Also initialize a local directory with this repository")

    p_repo_del = p_repo_sub.add_parser("delete", help="Delete a repository from your cloud workspace")
    p_repo_del.add_argument("name", help="Repository name to delete")
    p_repo_del.add_argument("-y", "--yes", action="store_true", help="Confirm deletion without prompting")

    args = parser.parse_args(argv)

    if args.command is None:
        parser.print_help()
        sys.exit(1)

    try:
        _dispatch(args)
    except Exception as e:
        print(f"error: {e}", file=sys.stderr)
        sys.exit(1)


def _dispatch(args: argparse.Namespace) -> None:
    """Dispatch to the appropriate command handler."""
    cmd = args.command

    if cmd == "init":
        _cmd_init(args)
    elif cmd == "hash-object":
        _cmd_hash_object(args)
    elif cmd == "cat-file":
        _cmd_cat_file(args)
    elif cmd == "write-tree":
        _cmd_write_tree(args)
    elif cmd == "add":
        _cmd_add(args)
    elif cmd == "status":
        _cmd_status(args)
    elif cmd == "commit":
        _cmd_commit(args)
    elif cmd == "log":
        _cmd_log(args)
    elif cmd == "show":
        _cmd_show(args)
    elif cmd == "branch":
        _cmd_branch(args)
    elif cmd == "checkout":
        _cmd_checkout(args)
    elif cmd == "diff":
        _cmd_diff(args)
    elif cmd == "merge":
        _cmd_merge(args)
    elif cmd == "tag":
        _cmd_tag(args)
    elif cmd == "remote":
        _cmd_remote(args)
    elif cmd == "clone":
        _cmd_clone(args)
    elif cmd == "fetch":
        _cmd_fetch(args)
    elif cmd == "pull":
        _cmd_pull(args)
    elif cmd == "push":
        _cmd_push(args)
    elif cmd == "login":
        _cmd_login(args)
    elif cmd == "logout":
        _cmd_logout(args)
    elif cmd == "whoami":
        _cmd_whoami(args)
    elif cmd == "repo":
        _cmd_repo(args)
    else:
        print(f"Unknown command: {cmd}", file=sys.stderr)
        sys.exit(1)


# ── Phase A Commands ──────────────────────────────────────────────────────


def _cmd_init(args: argparse.Namespace) -> None:
    """Initialize a new repository and register with cloud workspace if logged in."""
    from mygit.engine.repo import init_repo
    from mygit.engine.credentials import load_credentials, create_remote_repo
    from mygit.engine.network import set_remote_url

    path = os.path.abspath(args.path)
    root = init_repo(path)
    repo_name = os.path.basename(root)
    print(f"Initialized empty mygit repository in {root}/.mygit/")

    if not getattr(args, "no_remote", False):
        creds = load_credentials()
        if creds and creds.get("token"):
            username = creds.get("username", "user")
            backend_url = creds.get("backend_url", "http://localhost:8080")
            desc = getattr(args, "desc", "") or f"Repository {repo_name}"
            is_private = getattr(args, "private", False)

            try:
                res = create_remote_repo(name=repo_name, description=desc, is_private=is_private)
                remote_url = f"{backend_url}/api/repos/{repo_name}"
                set_remote_url(root, "origin", remote_url)
                vis = "private" if is_private else "public"
                print(f"✓ Registered {vis} repository '{username}/{repo_name}' in cloud workspace (Neon DB)")
                print(f"✓ Configured remote 'origin' -> {remote_url}")
            except FileExistsError:
                remote_url = f"{backend_url}/api/repos/{repo_name}"
                set_remote_url(root, "origin", remote_url)
                print(f"✓ Linked to existing cloud repository '{username}/{repo_name}'")
                print(f"✓ Configured remote 'origin' -> {remote_url}")
            except Exception as e:
                print(f"ℹ Local repository created. Cloud sync note: {e}")
        else:
            print("Tip: Run 'mygit login' on this device to link and sync repositories with your cloud workspace.")


def _cmd_hash_object(args: argparse.Namespace) -> None:
    """Hash a file and optionally write it to the object store."""
    from mygit.engine.objects import hash_object
    from mygit.engine.repo import find_repo_root

    with open(args.file, "rb") as f:
        data = f.read()

    root = None
    if args.w:
        root = find_repo_root()

    sha = hash_object(data, obj_type=args.type, write=args.w, root=root)
    print(sha)


def _cmd_cat_file(args: argparse.Namespace) -> None:
    """Display object info."""
    from mygit.engine.objects import read_object, cat_file_pretty
    from mygit.engine.repo import find_repo_root

    root = find_repo_root()

    if args.t:
        obj_type, _ = read_object(root, args.sha)
        print(obj_type)
    elif args.s:
        _, body = read_object(root, args.sha)
        print(len(body))
    elif args.p:
        print(cat_file_pretty(root, args.sha))


# ── Phase B Commands ──────────────────────────────────────────────────────


def _cmd_add(args: argparse.Namespace) -> None:
    """Stage files."""
    from mygit.engine.repo import find_repo_root
    from mygit.engine.index import add_paths

    root = find_repo_root()
    add_paths(root, args.paths)


def _cmd_status(args: argparse.Namespace) -> None:
    """Show working tree status."""
    from mygit.engine.repo import find_repo_root
    from mygit.engine.index import status
    from mygit.engine.refs import get_current_branch

    root = find_repo_root()
    branch = get_current_branch(root)
    if branch:
        print(f"On branch {branch}")
    else:
        print("HEAD detached")

    result = status(root)

    if result["staged"]:
        print("\nChanges to be committed:")
        for change_type, path in sorted(result["staged"]):
            print(f"  {change_type}: {path}")

    if result["modified"]:
        print("\nChanges not staged for commit:")
        for path in sorted(result["modified"]):
            print(f"  modified: {path}")

    if result["deleted"]:
        print("\nDeleted files:")
        for path in sorted(result["deleted"]):
            print(f"  deleted: {path}")

    if result["untracked"]:
        print("\nUntracked files:")
        for path in sorted(result["untracked"]):
            print(f"  {path}")


def _cmd_write_tree(args: argparse.Namespace) -> None:
    """Create a tree object from the current index."""
    from mygit.engine.repo import find_repo_root
    from mygit.engine.index import write_tree

    root = find_repo_root()
    sha = write_tree(root)
    print(sha)


def _cmd_commit(args: argparse.Namespace) -> None:
    """Create a commit."""
    from mygit.engine.repo import find_repo_root
    from mygit.engine.index import commit

    root = find_repo_root()
    sha = commit(root, args.message)
    print(f"[{sha[:7]}] {args.message}")


def _cmd_log(args: argparse.Namespace) -> None:
    """Show commit history."""
    from mygit.engine.repo import find_repo_root
    from mygit.engine.refs import resolve_head
    from mygit.engine.objects import read_object, parse_commit

    root = find_repo_root()
    sha = resolve_head(root)
    if sha is None:
        print("No commits yet.")
        return

    while sha:
        _, body = read_object(root, sha)
        info = parse_commit(body)

        if args.oneline:
            first_line = info["message"].split("\n")[0]
            print(f"{sha[:7]} {first_line}")
        else:
            print(f"commit {sha}")
            print(f"Author: {info['author']}")
            print()
            for line in info["message"].split("\n"):
                print(f"    {line}")
            print()

        sha = info["parents"][0] if info["parents"] else None


def _cmd_show(args: argparse.Namespace) -> None:
    """Show a commit."""
    from mygit.engine.repo import find_repo_root
    from mygit.engine.refs import resolve_head
    from mygit.engine.objects import read_object, parse_commit, resolve_sha
    from mygit.engine.diff import diff_trees

    root = find_repo_root()

    if args.commit == "HEAD":
        sha = resolve_head(root)
        if sha is None:
            print("No commits yet.")
            return
    else:
        sha = resolve_sha(root, args.commit)

    _, body = read_object(root, sha)
    info = parse_commit(body)

    print(f"commit {sha}")
    print(f"Author: {info['author']}")
    print()
    for line in info["message"].split("\n"):
        print(f"    {line}")
    print()

    # Diff against parent
    parent_tree = None
    if info["parents"]:
        _, parent_body = read_object(root, info["parents"][0])
        parent_info = parse_commit(parent_body)
        parent_tree = parent_info["tree"]

    diff_output = diff_trees(root, parent_tree, info["tree"])
    if diff_output:
        print(diff_output)


# ── Phase C Commands ──────────────────────────────────────────────────────


def _cmd_branch(args: argparse.Namespace) -> None:
    """Manage branches."""
    from mygit.engine.repo import find_repo_root
    from mygit.engine.refs import (
        list_branches, resolve_head, update_ref, delete_ref,
        get_current_branch,
    )

    root = find_repo_root()

    if args.name is None:
        # List branches
        current = get_current_branch(root)
        for branch in list_branches(root):
            prefix = "* " if branch == current else "  "
            print(f"{prefix}{branch}")
        return

    if args.delete:
        current = get_current_branch(root)
        if args.name == current:
            print("error: Cannot delete the currently checked-out branch.", file=sys.stderr)
            sys.exit(1)
        delete_ref(root, f"refs/heads/{args.name}")
        print(f"Deleted branch {args.name}")
        return

    # Create branch
    head_sha = resolve_head(root)
    if head_sha is None:
        print("error: Cannot create branch without any commits.", file=sys.stderr)
        sys.exit(1)
    update_ref(root, f"refs/heads/{args.name}", head_sha)
    print(f"Created branch {args.name} at {head_sha[:7]}")


def _cmd_checkout(args: argparse.Namespace) -> None:
    """Switch branches or restore files."""
    from mygit.engine.repo import find_repo_root
    from mygit.engine.refs import (
        resolve_head, resolve_ref, update_ref, set_head,
        list_branches,
    )
    from mygit.engine.objects import resolve_sha
    from mygit.engine.index import checkout_tree, has_uncommitted_changes

    root = find_repo_root()
    target = args.target

    if args.b:
        # Create and checkout new branch
        head_sha = resolve_head(root)
        if head_sha is None:
            print("error: Cannot create branch without any commits.", file=sys.stderr)
            sys.exit(1)
        update_ref(root, f"refs/heads/{target}", head_sha)
        set_head(root, f"ref: refs/heads/{target}")
        print(f"Switched to new branch '{target}'")
        return

    # Check for uncommitted changes
    if has_uncommitted_changes(root):
        print("error: Your local changes would be overwritten by checkout.", file=sys.stderr)
        print("Please commit or stash them before switching branches.", file=sys.stderr)
        sys.exit(1)

    # Try as branch name first
    branches = list_branches(root)
    if target in branches:
        sha = resolve_ref(root, f"refs/heads/{target}")
        if sha is None:
            print(f"error: Branch '{target}' exists but has no SHA.", file=sys.stderr)
            sys.exit(1)
        checkout_tree(root, sha)
        set_head(root, f"ref: refs/heads/{target}")
        print(f"Switched to branch '{target}'")
        return

    # Try as SHA
    try:
        sha = resolve_sha(root, target)
        checkout_tree(root, sha)
        set_head(root, sha)
        print(f"HEAD is now at {sha[:7]} (detached)")
    except (FileNotFoundError, ValueError) as e:
        print(f"error: {e}", file=sys.stderr)
        sys.exit(1)


def _cmd_diff(args: argparse.Namespace) -> None:
    """Show differences."""
    from mygit.engine.repo import find_repo_root
    from mygit.engine.diff import diff_working_tree, diff_staged, diff_commits

    root = find_repo_root()

    if args.a and args.b:
        output = diff_commits(root, args.a, args.b)
    elif args.staged:
        output = diff_staged(root)
    else:
        output = diff_working_tree(root)

    if output:
        print(output)


def _cmd_merge(args: argparse.Namespace) -> None:
    """Merge a branch."""
    from mygit.engine.repo import find_repo_root
    from mygit.engine.merge import merge_branch

    root = find_repo_root()
    result = merge_branch(root, args.branch)

    if result["fast_forward"]:
        print(f"Fast-forward merge to {result['sha'][:7]}")
    elif result["conflicts"]:
        print("CONFLICT: Merge conflicts in the following files:")
        for path in result["conflicts"]:
            print(f"  {path}")
        print("Automatic merge failed; fix conflicts and then commit the result.")
    else:
        print(f"Merge commit: {result['sha'][:7]}")


def _cmd_tag(args: argparse.Namespace) -> None:
    """Create or list tags."""
    from mygit.engine.repo import find_repo_root
    from mygit.engine.refs import resolve_head, update_ref, list_tags

    root = find_repo_root()

    if args.name is None:
        for tag in list_tags(root):
            print(tag)
        return

    head_sha = resolve_head(root)
    if head_sha is None:
        print("error: Cannot create tag without any commits.", file=sys.stderr)
        sys.exit(1)
    update_ref(root, f"refs/tags/{args.name}", head_sha)
    print(f"Created tag {args.name} at {head_sha[:7]}")


# ── Phase E Commands ──────────────────────────────────────────────────────


def _cmd_remote(args: argparse.Namespace) -> None:
    """Manage remotes."""
    from mygit.engine.repo import find_repo_root
    from mygit.engine.network import set_remote_url, get_remote_url

    root = find_repo_root()
    if args.remote_command == "add":
        set_remote_url(root, args.remote_name, args.url)
        print(f"Added remote '{args.remote_name}': {args.url}")
    else:
        url = get_remote_url(root, "origin")
        if url:
            print(f"origin\t{url}")


def _cmd_clone(args: argparse.Namespace) -> None:
    """Clone repository."""
    from mygit.engine.network import clone

    target_dir = args.directory
    if not target_dir:
        # Default dir from url
        target_dir = args.url.rstrip("/").split("/")[-1].replace(".mygit", "")
    clone(args.url, target_dir)
    print(f"Cloned into '{target_dir}'")


def _cmd_fetch(args: argparse.Namespace) -> None:
    """Fetch from remote."""
    from mygit.engine.repo import find_repo_root
    from mygit.engine.network import fetch

    root = find_repo_root()
    fetch(root, args.remote)
    print(f"Fetched from '{args.remote}'")


def _cmd_pull(args: argparse.Namespace) -> None:
    """Pull from remote."""
    from mygit.engine.repo import find_repo_root
    from mygit.engine.network import pull, get_remote_url

    root = find_repo_root()
    remote_url = get_remote_url(root, args.remote)
    if not remote_url:
        print(f"error: No remote '{args.remote}' configured. Add one with: mygit remote add origin <url>", file=sys.stderr)
        sys.exit(1)

    branch = getattr(args, "refspec", None)
    try:
        pull(root, args.remote, branch)
        print(f"✓ Successfully pulled and synchronized from '{args.remote}' ({remote_url})")
    except Exception as e:
        print(f"error: Pull failed: {e}", file=sys.stderr)
        sys.exit(1)


def _cmd_push(args: argparse.Namespace) -> None:
    """Push to remote."""
    from mygit.engine.repo import find_repo_root
    from mygit.engine.network import push, get_remote_url

    root = find_repo_root()
    remote_url = get_remote_url(root, args.remote)
    if not remote_url:
        print(f"error: No remote '{args.remote}' configured. Add one with: mygit remote add origin <url>", file=sys.stderr)
        sys.exit(1)

    branch = args.refspec
    try:
        push(root, args.remote, branch)
        print(f"✓ Successfully pushed to '{args.remote}' ({remote_url})")
    except Exception as e:
        print(f"error: Push failed: {e}", file=sys.stderr)
        sys.exit(1)


def _cmd_login(args: argparse.Namespace) -> None:
    """Log in to backend and persist JWT credentials."""
    import getpass
    from mygit.engine.credentials import login_to_backend, get_credentials_file

    email = args.email
    if not email:
        try:
            email = input("Email: ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\nAborted.")
            sys.exit(1)

    if not email:
        print("error: Email is required", file=sys.stderr)
        sys.exit(1)

    password = args.password
    if not password:
        try:
            password = getpass.getpass("Password: ")
        except (KeyboardInterrupt, EOFError):
            print("\nAborted.")
            sys.exit(1)

    if not password:
        print("error: Password is required", file=sys.stderr)
        sys.exit(1)

    backend_url = getattr(args, "url", "http://localhost:8080") or "http://localhost:8080"
    print(f"Connecting to {backend_url}...")

    try:
        data = login_to_backend(email, password, backend_url)
        username = data.get("username", email.split("@")[0])
        user_id = data.get("id")
        creds_file = get_credentials_file()
        print(f"✓ Authenticated successfully as '{username}' (User ID: {user_id})")
        print(f"✓ Token saved securely to {creds_file}")
    except Exception as e:
        print(f"error: {e}", file=sys.stderr)
        sys.exit(1)


def _cmd_logout(args: argparse.Namespace) -> None:
    """Log out and remove credentials."""
    from mygit.engine.credentials import clear_credentials
    if clear_credentials():
        print("✓ Logged out successfully. Stored credentials removed.")
    else:
        print("No active login session found.")


def _cmd_whoami(args: argparse.Namespace) -> None:
    """Display authenticated user profile."""
    from mygit.engine.credentials import load_credentials, verify_session

    creds = load_credentials()
    if not creds:
        print("Not logged in. Run 'mygit login' to authenticate.")
        sys.exit(1)

    print("Stored credentials:")
    print(f"  Username: {creds.get('username')}")
    print(f"  Email:    {creds.get('email')}")
    print(f"  User ID:  {creds.get('id')}")
    print(f"  Backend:  {creds.get('backend_url', 'http://localhost:8080')}")

    try:
        remote_url = getattr(args, "url", None)
        live_info = verify_session(backend_url=remote_url)
        print(f"✓ Session verified with live backend (active as '{live_info.get('username')}')")
    except Exception as e:
        print(f"⚠ Live session verification failed: {e}")


def _cmd_repo(args: argparse.Namespace) -> None:
    """Handle cloud repository commands."""
    from mygit.engine.credentials import (
        list_remote_repos,
        create_remote_repo,
        delete_remote_repo,
    )

    cmd = getattr(args, "repo_command", None) or "list"
    if cmd == "list":
        try:
            repos = list_remote_repos(backend_url=getattr(args, "url", None))
            if not repos:
                print("No repositories found in your cloud workspace.")
                print("Create one using 'mygit repo create <name>' or 'mygit init <name>'.")
                return

            print(f"{'NAME':<24} {'VISIBILITY':<12} {'UPDATED':<20} {'DESCRIPTION'}")
            print("-" * 75)
            for r in repos:
                vis = "private" if r.get("isPrivate") else "public"
                updated = (r.get("updatedAt") or "")[:19].replace("T", " ")
                desc = (r.get("description") or "")[:35]
                print(f"{r.get('name'):<24} {vis:<12} {updated:<20} {desc}")
        except Exception as e:
            print(f"error: {e}", file=sys.stderr)
            sys.exit(1)

    elif cmd == "create":
        try:
            repo_name = args.name.strip()
            desc = args.desc or f"Repository {repo_name}"
            is_private = args.private

            created = create_remote_repo(
                name=repo_name,
                description=desc,
                is_private=is_private,
            )
            owner = created.get("ownerUsername", "user")
            vis = "private" if created.get("isPrivate") else "public"
            print(f"✓ Successfully created {vis} repository '{owner}/{repo_name}' in cloud workspace (Neon DB)!")
            print(f"  Remote URL: http://localhost:8080/api/repos/{repo_name}")

            if getattr(args, "init", False):
                from mygit.engine.repo import init_repo
                from mygit.engine.network import set_remote_url

                local_dir = os.path.abspath(repo_name)
                root = init_repo(local_dir)
                set_remote_url(root, "origin", f"http://localhost:8080/api/repos/{repo_name}")
                print(f"✓ Initialized local repository in {local_dir}/.mygit/")
                print(f"✓ Configured remote 'origin' -> http://localhost:8080/api/repos/{repo_name}")
            else:
                print(f"  To initialize locally, run: mygit init {repo_name}")
        except Exception as e:
            print(f"error: {e}", file=sys.stderr)
            sys.exit(1)

    elif cmd == "delete":
        repo_name = args.name.strip()
        if not getattr(args, "yes", False):
            confirm = input(f"Are you sure you want to delete cloud repository '{repo_name}'? (y/N): ")
            if confirm.lower() not in ("y", "yes"):
                print("Aborted.")
                return

        try:
            delete_remote_repo(repo_name)
            print(f"✓ Repository '{repo_name}' was successfully deleted from your cloud workspace.")
        except Exception as e:
            print(f"error: {e}", file=sys.stderr)
            sys.exit(1)


if __name__ == "__main__":
    main()
