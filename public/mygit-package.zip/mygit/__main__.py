"""mygit CLI entrypoint: python -m mygit"""
from __future__ import annotations
from mygit.cli import main

main()
