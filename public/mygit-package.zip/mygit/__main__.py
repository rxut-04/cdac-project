"""mygit CLI entrypoint: python -m mygit"""
from mygit.cli import main

main()
