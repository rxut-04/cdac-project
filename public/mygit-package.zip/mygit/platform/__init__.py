"""mygit platform - Web application."""
