"""mygit platform - Web application."""
from __future__ import annotations
