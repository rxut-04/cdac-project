"""Pull request and comment routes."""

import os
import shutil
import tempfile
from typing import Optional

from fastapi import APIRouter, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse

from mygit.platform.app import get_current_user, verify_csrf
from mygit.platform.models import Comment, PullRequest, Repo, User, validate_name
from mygit.platform.storage import BareRepoAdapter

router = APIRouter()


@router.get("/{owner}/{name}/pulls", response_class=HTMLResponse)
async def list_prs(
    request: Request,
    owner: str,
    name: str,
):
    """List pull requests for a repository."""
    if not validate_name(owner) or not validate_name(name):
        raise HTTPException(status_code=400, detail="Invalid name")

    user = get_current_user(request, request.app)
    session = request.app.state.db_session_factory()
    try:
        repo_obj = session.query(Repo).filter(Repo.owner == owner, Repo.name == name).first()
        if not repo_obj:
            raise HTTPException(status_code=404, detail="Repo not found")
        if repo_obj.is_private and (not user or user["username"] != owner):
            raise HTTPException(status_code=403, detail="Forbidden")

        prs = session.query(PullRequest).filter(PullRequest.repo_id == repo_obj.id).all()
        templates = request.app.state.templates
        return templates.TemplateResponse(
            request=request,
            name="pr_list.html",
            context={
                "user": user,
                "repo": repo_obj,
                "prs": prs,
            },
        )
    finally:
        session.close()


@router.get("/{owner}/{name}/pulls/new", response_class=HTMLResponse)
async def new_pr_page(
    request: Request,
    owner: str,
    name: str,
):
    """Show open pull request form."""
    user = get_current_user(request, request.app)
    if not user:
        return RedirectResponse(url="/login", status_code=303)

    session = request.app.state.db_session_factory()
    try:
        repo_obj = session.query(Repo).filter(Repo.owner == owner, Repo.name == name).first()
        if not repo_obj:
            raise HTTPException(status_code=404, detail="Repo not found")

        adapter = BareRepoAdapter(owner, name)
        branches = adapter.list_branches()

        templates = request.app.state.templates
        return templates.TemplateResponse(
            request=request,
            name="pr_new.html",
            context={
                "user": user,
                "repo": repo_obj,
                "branches": branches,
                "error": None,
            },
        )
    finally:
        session.close()


@router.post("/{owner}/{name}/pulls/new")
async def create_pr(
    request: Request,
    owner: str,
    name: str,
    csrf_token: str = Form(...),
    title: str = Form(...),
    body: str = Form(""),
    source_branch: str = Form(...),
    target_branch: str = Form(...),
):
    """Create a new pull request."""
    user = get_current_user(request, request.app)
    if not user:
        return RedirectResponse(url="/login", status_code=303)

    if not verify_csrf(request, request.app, csrf_token):
        return HTMLResponse("CSRF verification failed", status_code=403)

    if source_branch == target_branch:
        raise HTTPException(status_code=400, detail="Source and target branches cannot be identical")

    session = request.app.state.db_session_factory()
    try:
        repo_obj = session.query(Repo).filter(Repo.owner == owner, Repo.name == name).first()
        if not repo_obj:
            raise HTTPException(status_code=404, detail="Repo not found")

        pr = PullRequest(
            repo_id=repo_obj.id,
            author=user["username"],
            source_branch=source_branch,
            target_branch=target_branch,
            title=title,
            body=body,
            status="open",
        )
        session.add(pr)
        session.commit()

        return RedirectResponse(url=f"/{owner}/{name}/pulls/{pr.id}", status_code=303)
    finally:
        session.close()


@router.get("/{owner}/{name}/pulls/{pr_id}", response_class=HTMLResponse)
async def view_pr(
    request: Request,
    owner: str,
    name: str,
    pr_id: int,
):
    """View PR detail: commits, diffs, conflicts check, comments."""
    user = get_current_user(request, request.app)
    session = request.app.state.db_session_factory()
    try:
        repo_obj = session.query(Repo).filter(Repo.owner == owner, Repo.name == name).first()
        if not repo_obj:
            raise HTTPException(status_code=404, detail="Repo not found")
        if repo_obj.is_private and (not user or user["username"] != owner):
            raise HTTPException(status_code=403, detail="Forbidden")

        pr = session.query(PullRequest).filter(PullRequest.id == pr_id).first()
        if not pr:
            raise HTTPException(status_code=404, detail="Pull request not found")

        adapter = BareRepoAdapter(owner, name)
        src_sha = adapter.resolve_ref(f"refs/heads/{pr.source_branch}")
        tgt_sha = adapter.resolve_ref(f"refs/heads/{pr.target_branch}")

        diff_chunks = []
        commits = []
        has_conflicts = False
        conflict_files = []

        if src_sha and tgt_sha:
            # Gather commits on source not on target
            curr_sha = src_sha
            while curr_sha and curr_sha != tgt_sha:
                info = adapter.get_commit_info(curr_sha)
                commits.append({"sha": curr_sha, **info})
                curr_sha = info["parents"][0] if info["parents"] else None

            # Tree diff
            src_tree = adapter.get_commit_info(src_sha)["tree"]
            tgt_tree = adapter.get_commit_info(tgt_sha)["tree"]

            from mygit.engine.diff import diff_blobs
            tgt_entries = adapter.get_tree_files_flat(tgt_tree)
            src_entries = adapter.get_tree_files_flat(src_tree)
            all_paths = sorted(set(tgt_entries.keys()) | set(src_entries.keys()))

            for path in all_paths:
                old_sha = tgt_entries.get(path, (None, None))[1]
                new_sha = src_entries.get(path, (None, None))[1]
                if old_sha != new_sha:
                    old_c = adapter.get_blob_content(old_sha).decode(errors="replace") if old_sha else ""
                    new_c = adapter.get_blob_content(new_sha).decode(errors="replace") if new_sha else ""
                    dtext = diff_blobs(old_c, new_c, path, path)
                    if dtext:
                        diff_chunks.append({"path": path, "diff": dtext})

            # Check for merge conflicts in a temp sandbox
            with tempfile.TemporaryDirectory() as tmpdir:
                # Copy bare repo into a temp repo with working tree
                temp_repo = os.path.join(tmpdir, "repo")
                shutil.copytree(adapter.bare_path, os.path.join(temp_repo, ".mygit"))
                from mygit.engine.refs import set_head
                from mygit.engine.index import checkout_tree
                from mygit.engine.merge import merge_branch

                set_head(temp_repo, f"ref: refs/heads/{pr.target_branch}")
                checkout_tree(temp_repo, tgt_sha)
                merge_res = merge_branch(temp_repo, pr.source_branch)
                if merge_res["conflicts"]:
                    has_conflicts = True
                    conflict_files = merge_res["conflicts"]

        templates = request.app.state.templates
        return templates.TemplateResponse(
            request=request,
            name="pr_view.html",
            context={
                "user": user,
                "repo": repo_obj,
                "pr": pr,
                "commits": commits,
                "diff_chunks": diff_chunks,
                "has_conflicts": has_conflicts,
                "conflict_files": conflict_files,
            },
        )
    finally:
        session.close()


@router.post("/{owner}/{name}/pulls/{pr_id}/comment")
async def add_pr_comment(
    request: Request,
    owner: str,
    name: str,
    pr_id: int,
    csrf_token: str = Form(...),
    body: str = Form(...),
):
    """Add a comment to a PR."""
    user = get_current_user(request, request.app)
    if not user:
        return RedirectResponse(url="/login", status_code=303)

    if not verify_csrf(request, request.app, csrf_token):
        return HTMLResponse("CSRF verification failed", status_code=403)

    session = request.app.state.db_session_factory()
    try:
        pr = session.query(PullRequest).filter(PullRequest.id == pr_id).first()
        if not pr:
            raise HTTPException(status_code=404, detail="PR not found")

        comment = Comment(
            pr_id=pr.id,
            author=user["username"],
            body=body,
        )
        session.add(comment)
        session.commit()

        return RedirectResponse(url=f"/{owner}/{name}/pulls/{pr_id}", status_code=303)
    finally:
        session.close()


@router.post("/{owner}/{name}/pulls/{pr_id}/merge")
async def merge_pr(
    request: Request,
    owner: str,
    name: str,
    pr_id: int,
    csrf_token: str = Form(...),
):
    """Merge a pull request using the engine merge in a temporary working dir."""
    user = get_current_user(request, request.app)
    if not user:
        return RedirectResponse(url="/login", status_code=303)

    if not verify_csrf(request, request.app, csrf_token):
        return HTMLResponse("CSRF verification failed", status_code=403)

    session = request.app.state.db_session_factory()
    try:
        repo_obj = session.query(Repo).filter(Repo.owner == owner, Repo.name == name).first()
        if not repo_obj:
            raise HTTPException(status_code=404, detail="Repo not found")
        if repo_obj.owner != user["username"]:
            raise HTTPException(status_code=403, detail="Only repo owner can merge pull requests")

        pr = session.query(PullRequest).filter(PullRequest.id == pr_id).first()
        if not pr or pr.status != "open":
            raise HTTPException(status_code=400, detail="Cannot merge this PR")

        adapter = BareRepoAdapter(owner, name)
        src_sha = adapter.resolve_ref(f"refs/heads/{pr.source_branch}")
        tgt_sha = adapter.resolve_ref(f"refs/heads/{pr.target_branch}")

        if not src_sha or not tgt_sha:
            raise HTTPException(status_code=400, detail="Branch reference missing")

        # Perform merge in temp working directory
        with tempfile.TemporaryDirectory() as tmpdir:
            temp_repo = os.path.join(tmpdir, "repo")
            shutil.copytree(adapter.bare_path, os.path.join(temp_repo, ".mygit"))

            from mygit.engine.refs import set_head
            from mygit.engine.index import checkout_tree
            from mygit.engine.merge import merge_branch

            set_head(temp_repo, f"ref: refs/heads/{pr.target_branch}")
            checkout_tree(temp_repo, tgt_sha)

            merge_res = merge_branch(temp_repo, pr.source_branch)
            if merge_res["conflicts"]:
                raise HTTPException(status_code=409, detail=f"Conflicts detected: {merge_res['conflicts']}")

            new_commit_sha = merge_res["sha"]

            # Copy any newly generated objects back into the bare repo
            temp_objects = os.path.join(temp_repo, ".mygit", "objects")
            for root_dir, _, files in os.walk(temp_objects):
                for f in files:
                    rel = os.path.relpath(os.path.join(root_dir, f), temp_objects)
                    target_obj = os.path.join(adapter.bare_path, "objects", rel)
                    if not os.path.exists(target_obj):
                        os.makedirs(os.path.dirname(target_obj), exist_ok=True)
                        shutil.copy(os.path.join(root_dir, f), target_obj)

            # Update target ref in bare repo
            adapter.update_ref(f"refs/heads/{pr.target_branch}", new_commit_sha)

        pr.status = "merged"
        session.commit()

        return RedirectResponse(url=f"/{owner}/{name}/pulls/{pr_id}", status_code=303)
    finally:
        session.close()


@router.post("/{owner}/{name}/pulls/{pr_id}/close")
async def close_pr(
    request: Request,
    owner: str,
    name: str,
    pr_id: int,
    csrf_token: str = Form(...),
):
    """Close a pull request without merging."""
    user = get_current_user(request, request.app)
    if not user:
        return RedirectResponse(url="/login", status_code=303)

    if not verify_csrf(request, request.app, csrf_token):
        return HTMLResponse("CSRF verification failed", status_code=403)

    session = request.app.state.db_session_factory()
    try:
        pr = session.query(PullRequest).filter(PullRequest.id == pr_id).first()
        if not pr:
            raise HTTPException(status_code=404, detail="PR not found")
        pr.status = "closed"
        session.commit()

        return RedirectResponse(url=f"/{owner}/{name}/pulls/{pr_id}", status_code=303)
    finally:
        session.close()
