"""Network sync protocol routes for mygit client.

Endpoints:
  GET  /<owner>/<repo>.mygit/refs        -> JSON mapping of refs to SHAs
  GET  /<owner>/<repo>.mygit/objects/<sha> -> raw compressed object
  POST /<owner>/<repo>.mygit/push        -> upload missing objects + update a ref
"""

import os
from typing import Optional
from pydantic import BaseModel

from fastapi import APIRouter, Header, HTTPException, Request, Response
from fastapi.responses import JSONResponse

from mygit.platform.auth import verify_api_token
from mygit.platform.models import Repo, Token, User, Activity, validate_name
from mygit.platform.storage import BareRepoAdapter, get_repo_path

router = APIRouter()


class PushPayload(BaseModel):
    ref: str
    target_sha: str
    force: bool = False
    objects: list[dict]  # list of {"sha": str, "content_hex": str, "type": str}


@router.get("/{owner}/{repo_name_with_ext}/refs")
async def get_refs(
    owner: str,
    repo_name_with_ext: str,
    request: Request,
):
    """Return all refs and current SHAs."""
    if not repo_name_with_ext.endswith(".mygit"):
        raise HTTPException(status_code=400, detail="Invalid repository URL")
    repo_name = repo_name_with_ext[:-6]

    if not validate_name(owner) or not validate_name(repo_name):
        raise HTTPException(status_code=400, detail="Invalid name")

    session = request.app.state.db_session_factory()
    try:
        repo_obj = session.query(Repo).filter(
            Repo.owner == owner, Repo.name == repo_name
        ).first()
        if not repo_obj:
            raise HTTPException(status_code=404, detail="Repository not found")

        adapter = BareRepoAdapter(owner, repo_name)
        refs = adapter.list_refs()
        return refs
    finally:
        session.close()


@router.get("/{owner}/{repo_name_with_ext}/objects/{sha}")
async def get_object(
    owner: str,
    repo_name_with_ext: str,
    sha: str,
):
    """Return raw compressed object."""
    if not repo_name_with_ext.endswith(".mygit"):
        raise HTTPException(status_code=400, detail="Invalid repository URL")
    repo_name = repo_name_with_ext[:-6]

    if not validate_name(owner) or not validate_name(repo_name) or not validate_name(sha):
        raise HTTPException(status_code=400, detail="Invalid path components")

    adapter = BareRepoAdapter(owner, repo_name)
    obj_file = adapter.objects_path(sha)
    if not os.path.isfile(obj_file):
        raise HTTPException(status_code=404, detail="Object not found")

    with open(obj_file, "rb") as f:
        data = f.read()

    return Response(content=data, media_type="application/octet-stream")


@router.post("/{owner}/{repo_name_with_ext}/push")
async def handle_push(
    owner: str,
    repo_name_with_ext: str,
    payload: PushPayload,
    request: Request,
    authorization: Optional[str] = Header(None),
):
    """Receive pushed objects and update the specified ref."""
    if not repo_name_with_ext.endswith(".mygit"):
        raise HTTPException(status_code=400, detail="Invalid repository URL")
    repo_name = repo_name_with_ext[:-6]

    if not validate_name(owner) or not validate_name(repo_name):
        raise HTTPException(status_code=400, detail="Invalid name")

    # Authenticate via Token
    if not authorization:
        raise HTTPException(status_code=401, detail="Authentication required")

    token_str = authorization.replace("Bearer ", "").strip()
    session = request.app.state.db_session_factory()
    try:
        repo_obj = session.query(Repo).filter(
            Repo.owner == owner, Repo.name == repo_name
        ).first()
        if not repo_obj:
            raise HTTPException(status_code=404, detail="Repository not found")

        # Check token validity and ownership
        user = session.query(User).filter(User.username == owner).first()
        if not user:
            raise HTTPException(status_code=404, detail="Owner not found")

        valid_auth = False
        for tok in user.tokens:
            if verify_api_token(token_str, tok.token_hash):
                valid_auth = True
                break

        if not valid_auth:
            raise HTTPException(status_code=403, detail="Invalid credentials or insufficient permissions")

        adapter = BareRepoAdapter(owner, repo_name)

        # 1. Store all incoming objects
        for obj in payload.objects:
            obj_bytes = bytes.fromhex(obj["content_hex"])
            adapter.write_object(obj_bytes, obj["type"])

        # 2. Check fast-forward requirement unless forced
        current_sha = adapter.resolve_ref(payload.ref)
        if current_sha and current_sha != payload.target_sha and not payload.force:
            from mygit.engine.merge import find_merge_base
            base = find_merge_base(adapter.bare_path, current_sha, payload.target_sha)
            if base != current_sha:
                raise HTTPException(
                    status_code=400,
                    detail="Non-fast-forward push rejected. Pull first or force.",
                )

        # 3. Update the ref
        adapter.update_ref(payload.ref, payload.target_sha)

        # 4. Trigger post-push hook / activity logging (Phase F requirement)
        activity = Activity(
            repo_id=repo_obj.id,
            actor=owner,
            action="push",
            details=f"Pushed commit {payload.target_sha[:7]} to {payload.ref}",
        )
        session.add(activity)
        session.commit()

        return {"status": "ok", "ref": payload.ref, "sha": payload.target_sha}
    finally:
        session.close()
