"""Repository management and browsing routes."""
from __future__ import annotations

import os
from typing import Optional
import bleach
import markdown
from pygments import highlight
from pygments.formatters import HtmlFormatter
from pygments.lexers import get_lexer_for_filename, TextLexer

from fastapi import APIRouter, Form, Request, Response, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse

from mygit.platform.app import get_current_user, verify_csrf
from mygit.platform.models import Repo, User, validate_name
from mygit.platform.storage import create_bare_repo, delete_bare_repo, BareRepoAdapter, get_repo_path
from mygit.engine.diff import diff_trees

router = APIRouter()

ALLOWED_TAGS = list(bleach.sanitizer.ALLOWED_TAGS) + [
    "h1", "h2", "h3", "h4", "h5", "h6", "p", "pre", "code", "blockquote", "hr",
    "ul", "ol", "li", "table", "thead", "tbody", "tr", "th", "td", "img", "span"
]
ALLOWED_ATTRIBUTES = {
    **bleach.sanitizer.ALLOWED_ATTRIBUTES,
    "*": ["class", "id"],
    "img": ["src", "alt", "title", "width", "height"],
}


@router.get("/repos", response_class=HTMLResponse)
async def list_repos(request: Request):
    """List accessible repositories."""
    user = get_current_user(request, request.app)
    session = request.app.state.db_session_factory()
    try:
        if user:
            repos = session.query(Repo).filter(
                (Repo.is_private == False) | (Repo.owner == user["username"])
            ).all()
        else:
            repos = session.query(Repo).filter(Repo.is_private == False).all()

        templates = request.app.state.templates
        return templates.TemplateResponse(
            request=request,
            name="repo_list.html",
            context={"user": user, "repos": repos},
        )
    finally:
        session.close()


@router.get("/repos/new", response_class=HTMLResponse)
async def new_repo_page(request: Request):
    """Show create repository page."""
    user = get_current_user(request, request.app)
    if not user:
        return RedirectResponse(url="/login", status_code=303)
    templates = request.app.state.templates
    return templates.TemplateResponse(
        request=request,
        name="repo_new.html",
        context={"user": user, "error": None},
    )


@router.post("/repos/new")
async def create_repo(
    request: Request,
    csrf_token: str = Form(...),
    name: str = Form(...),
    description: str = Form(""),
    is_private: Optional[str] = Form(None),
):
    """Create a new bare repository."""
    user = get_current_user(request, request.app)
    if not user:
        return RedirectResponse(url="/login", status_code=303)

    if not verify_csrf(request, request.app, csrf_token):
        return HTMLResponse("CSRF verification failed", status_code=403)

    if not validate_name(name):
        templates = request.app.state.templates
        return templates.TemplateResponse(
            request=request,
            name="repo_new.html",
            context={"user": user, "error": "Invalid repo name: must match ^[a-zA-Z0-9._-]+$ and not contain '..'"},
            status_code=400,
        )

    session = request.app.state.db_session_factory()
    try:
        existing = session.query(Repo).filter(
            Repo.owner == user["username"], Repo.name == name
        ).first()
        if existing:
            templates = request.app.state.templates
            return templates.TemplateResponse(
                request=request,
                name="repo_new.html",
                context={"user": user, "error": f"Repository '{name}' already exists."},
                status_code=400,
            )

        # Create model and bare repo directory
        private_flag = bool(is_private)
        repo_obj = Repo(
            owner=user["username"],
            name=name,
            description=description,
            is_private=private_flag,
        )
        session.add(repo_obj)
        session.commit()

        create_bare_repo(user["username"], name)
        return RedirectResponse(url=f"/{user['username']}/{name}", status_code=303)
    finally:
        session.close()


@router.get("/{owner}/{name}", response_class=HTMLResponse)
async def repo_home(
    request: Request,
    owner: str,
    name: str,
    branch: Optional[str] = None,
):
    """Repo home page showing file tree, README, branches."""
    if not validate_name(owner) or not validate_name(name):
        raise HTTPException(status_code=400, detail="Invalid owner or repo name")

    user = get_current_user(request, request.app)
    session = request.app.state.db_session_factory()
    try:
        repo_obj = session.query(Repo).filter(
            Repo.owner == owner, Repo.name == name
        ).first()
        if not repo_obj:
            raise HTTPException(status_code=404, detail="Repository not found")

        if repo_obj.is_private and (not user or user["username"] != owner):
            raise HTTPException(status_code=403, detail="Access denied")

        adapter = BareRepoAdapter(owner, name)
        branches = adapter.list_branches()
        current_branch = branch if branch and branch in branches else ("main" if "main" in branches else (branches[0] if branches else None))

        files = []
        readme_html = None
        latest_commit = None

        if current_branch:
            commit_sha = adapter.resolve_ref(f"refs/heads/{current_branch}")
            if commit_sha:
                commit_info = adapter.get_commit_info(commit_sha)
                latest_commit = {"sha": commit_sha, **commit_info}
                files = adapter.get_tree_files(commit_info["tree"])

                # Look for README.md
                for mode, fpath, fsha in files:
                    if fpath.lower() in ("readme.md", "readme.txt", "readme"):
                        blob = adapter.get_blob_content(fsha)
                        raw_text = blob.decode(errors="replace")
                        if fpath.lower().endswith(".md"):
                            rendered = markdown.markdown(raw_text, extensions=["fenced_code", "tables"])
                            readme_html = bleach.clean(rendered, tags=ALLOWED_TAGS, attributes=ALLOWED_ATTRIBUTES)
                        else:
                            readme_html = f"<pre>{bleach.clean(raw_text)}</pre>"
                        break

        templates = request.app.state.templates
        return templates.TemplateResponse(
            request=request,
            name="repo_view.html",
            context={
                "user": user,
                "repo": repo_obj,
                "branches": branches,
                "current_branch": current_branch,
                "files": files,
                "readme_html": readme_html,
                "latest_commit": latest_commit,
            },
        )
    finally:
        session.close()


@router.get("/{owner}/{name}/blob/{branch}/{file_path:path}", response_class=HTMLResponse)
async def view_file(
    request: Request,
    owner: str,
    name: str,
    branch: str,
    file_path: str,
):
    """File viewer with Pygments syntax highlighting."""
    if not validate_name(owner) or not validate_name(name):
        raise HTTPException(status_code=400, detail="Invalid name")

    user = get_current_user(request, request.app)
    session = request.app.state.db_session_factory()
    try:
        repo_obj = session.query(Repo).filter(Repo.owner == owner, Repo.name == name).first()
        if not repo_obj:
            raise HTTPException(status_code=404, detail="Repo not found")
        if repo_obj.is_private and (not user or user["username"] != owner):
            raise HTTPException(status_code=403, detail="Forbidden")

        adapter = BareRepoAdapter(owner, name)
        commit_sha = adapter.resolve_ref(f"refs/heads/{branch}")
        if not commit_sha:
            raise HTTPException(status_code=404, detail=f"Branch {branch} not found")

        commit_info = adapter.get_commit_info(commit_sha)
        files = adapter.get_tree_files(commit_info["tree"])

        file_sha = None
        for mode, fpath, fsha in files:
            if fpath == file_path:
                file_sha = fsha
                break

        if not file_sha:
            raise HTTPException(status_code=404, detail=f"File {file_path} not found")

        raw_bytes = adapter.get_blob_content(file_sha)
        try:
            content_str = raw_bytes.decode()
            try:
                lexer = get_lexer_for_filename(file_path, content_str)
            except Exception:
                lexer = TextLexer()
            formatter = HtmlFormatter(linenos=True, cssclass="highlight")
            highlighted_code = highlight(content_str, lexer, formatter)
            highlight_css = formatter.get_style_defs(".highlight")
        except UnicodeDecodeError:
            highlighted_code = f"<p><em>Binary file ({len(raw_bytes)} bytes)</em></p>"
            highlight_css = ""

        templates = request.app.state.templates
        return templates.TemplateResponse(
            request=request,
            name="file_view.html",
            context={
                "user": user,
                "repo": repo_obj,
                "branch": branch,
                "file_path": file_path,
                "highlighted_code": highlighted_code,
                "highlight_css": highlight_css,
            },
        )
    finally:
        session.close()


@router.get("/{owner}/{name}/commits", response_class=HTMLResponse)
async def commit_list(
    request: Request,
    owner: str,
    name: str,
    branch: Optional[str] = None,
):
    """List commits on a branch."""
    if not validate_name(owner) or not validate_name(name):
        raise HTTPException(status_code=400, detail="Invalid name")

    user = get_current_user(request, request.app)
    session = request.app.state.db_session_factory()
    try:
        repo_obj = session.query(Repo).filter(Repo.owner == owner, Repo.name == name).first()
        if not repo_obj:
            raise HTTPException(status_code=404, detail="Repo not found")
        if repo_obj.is_private and (not user or user["username"] != owner):
            raise HTTPException(status_code=403, detail="Forbidden")

        adapter = BareRepoAdapter(owner, name)
        branches = adapter.list_branches()
        target_branch = branch if branch and branch in branches else ("main" if "main" in branches else (branches[0] if branches else None))

        commits = []
        if target_branch:
            curr_sha = adapter.resolve_ref(f"refs/heads/{target_branch}")
            while curr_sha:
                info = adapter.get_commit_info(curr_sha)
                commits.append({"sha": curr_sha, **info})
                curr_sha = info["parents"][0] if info["parents"] else None

        templates = request.app.state.templates
        return templates.TemplateResponse(
            request=request,
            name="commit_list.html",
            context={
                "user": user,
                "repo": repo_obj,
                "branch": target_branch,
                "branches": branches,
                "commits": commits,
            },
        )
    finally:
        session.close()


@router.get("/{owner}/{name}/commit/{sha}", response_class=HTMLResponse)
async def view_commit(
    request: Request,
    owner: str,
    name: str,
    sha: str,
):
    """View a single commit and its unified diff against parent."""
    if not validate_name(owner) or not validate_name(name):
        raise HTTPException(status_code=400, detail="Invalid name")

    user = get_current_user(request, request.app)
    session = request.app.state.db_session_factory()
    try:
        repo_obj = session.query(Repo).filter(Repo.owner == owner, Repo.name == name).first()
        if not repo_obj:
            raise HTTPException(status_code=404, detail="Repo not found")
        if repo_obj.is_private and (not user or user["username"] != owner):
            raise HTTPException(status_code=403, detail="Forbidden")

        adapter = BareRepoAdapter(owner, name)
        info = adapter.get_commit_info(sha)

        parent_tree = None
        if info["parents"]:
            parent_info = adapter.get_commit_info(info["parents"][0])
            parent_tree = parent_info["tree"]

        from mygit.engine.diff import diff_blobs
        old_entries = adapter.get_tree_files_flat(parent_tree)
        new_entries = adapter.get_tree_files_flat(info["tree"])

        all_paths = sorted(set(old_entries.keys()) | set(new_entries.keys()))
        diff_chunks = []
        for path in all_paths:
            old_sha = old_entries.get(path, (None, None))[1]
            new_sha = new_entries.get(path, (None, None))[1]
            if old_sha == new_sha:
                continue

            old_c = adapter.get_blob_content(old_sha).decode(errors="replace") if old_sha else ""
            new_c = adapter.get_blob_content(new_sha).decode(errors="replace") if new_sha else ""
            diff_text = diff_blobs(old_c, new_c, path, path)
            if diff_text:
                diff_chunks.append({"path": path, "diff": diff_text})

        templates = request.app.state.templates
        return templates.TemplateResponse(
            request=request,
            name="commit_view.html",
            context={
                "user": user,
                "repo": repo_obj,
                "commit": {"sha": sha, **info},
                "diff_chunks": diff_chunks,
            },
        )
    finally:
        session.close()
