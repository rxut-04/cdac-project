"""Authentication routes: register, login, logout."""
from __future__ import annotations

from fastapi import APIRouter, Form, Request, Response
from fastapi.responses import HTMLResponse, RedirectResponse

from mygit.platform.auth import (
    check_rate_limit,
    generate_csrf_token,
    generate_session_token,
    hash_password,
    reset_rate_limit,
    validate_registration,
    verify_password,
    generate_api_token,
)
from mygit.platform.models import User, Token, validate_name

router = APIRouter()


@router.get("/register", response_class=HTMLResponse)
async def register_page(request: Request):
    """Show registration form."""
    templates = request.app.state.templates
    return templates.TemplateResponse(
        request=request,
        name="register.html",
        context={"error": None},
    )


@router.post("/register")
async def register(
    request: Request,
    username: str = Form(...),
    password: str = Form(...),
    password_confirm: str = Form(...),
):
    """Handle registration form submission."""
    templates = request.app.state.templates

    if password != password_confirm:
        return templates.TemplateResponse(
            request=request,
            name="register.html",
            context={"error": "Passwords do not match"},
            status_code=400,
        )

    error = validate_registration(username, password)
    if error:
        return templates.TemplateResponse(
            request=request,
            name="register.html",
            context={"error": error},
            status_code=400,
        )

    session = request.app.state.db_session_factory()
    try:
        # Check if user exists
        existing = session.query(User).filter(User.username == username).first()
        if existing:
            return templates.TemplateResponse(
                request=request,
                name="register.html",
                context={"error": "Username already taken"},
                status_code=400,
            )

        user = User(
            username=username,
            password_hash=hash_password(password),
        )
        session.add(user)
        session.commit()

        # Auto-login
        session_token = generate_session_token()
        csrf_token = generate_csrf_token()
        request.app.state.sessions[session_token] = {
            "user_id": user.id,
            "username": user.username,
            "csrf_token": csrf_token,
        }

        response = RedirectResponse(url="/", status_code=303)
        response.set_cookie(
            key="session_token",
            value=session_token,
            httponly=True,
            samesite="lax",
        )
        return response
    finally:
        session.close()


@router.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    """Show login form."""
    templates = request.app.state.templates
    return templates.TemplateResponse(
        request=request,
        name="login.html",
        context={"error": None},
    )


@router.post("/login")
async def login(
    request: Request,
    username: str = Form(...),
    password: str = Form(...),
):
    """Handle login form submission."""
    templates = request.app.state.templates
    client_ip = request.client.host if request.client else "unknown"

    if not check_rate_limit(client_ip):
        return templates.TemplateResponse(
            request=request,
            name="login.html",
            context={"error": "Too many attempts. Try again later."},
            status_code=429,
        )

    session = request.app.state.db_session_factory()
    try:
        user = session.query(User).filter(User.username == username).first()
        if not user or not verify_password(user.password_hash, password):
            return templates.TemplateResponse(
                request=request,
                name="login.html",
                context={"error": "Invalid username or password"},
                status_code=401,
            )

        reset_rate_limit(client_ip)

        session_token = generate_session_token()
        csrf_token = generate_csrf_token()
        request.app.state.sessions[session_token] = {
            "user_id": user.id,
            "username": user.username,
            "csrf_token": csrf_token,
        }

        response = RedirectResponse(url="/", status_code=303)
        response.set_cookie(
            key="session_token",
            value=session_token,
            httponly=True,
            samesite="lax",
        )
        return response
    finally:
        session.close()


@router.get("/logout")
async def logout(request: Request):
    """Logout and clear session."""
    session_token = request.cookies.get("session_token")
    if session_token:
        request.app.state.sessions.pop(session_token, None)

    response = RedirectResponse(url="/", status_code=303)
    response.delete_cookie("session_token")
    return response


@router.get("/tokens", response_class=HTMLResponse)
async def tokens_page(request: Request):
    """Show API tokens page."""
    from mygit.platform.app import get_current_user
    templates = request.app.state.templates
    user = get_current_user(request, request.app)
    if not user:
        return RedirectResponse(url="/login", status_code=303)

    session = request.app.state.db_session_factory()
    try:
        tokens = session.query(Token).filter(
            Token.user_id == user["user_id"]
        ).all()
        return templates.TemplateResponse(
            request=request,
            name="tokens.html",
            context={"user": user, "tokens": tokens, "new_token": None},
        )
    finally:
        session.close()


@router.post("/tokens/create")
async def create_token(
    request: Request,
    csrf_token: str = Form(...),
    label: str = Form(""),
):
    """Create a new API token."""
    from mygit.platform.app import get_current_user, verify_csrf
    templates = request.app.state.templates
    user = get_current_user(request, request.app)
    if not user:
        return RedirectResponse(url="/login", status_code=303)

    if not verify_csrf(request, request.app, csrf_token):
        return HTMLResponse("CSRF validation failed", status_code=403)

    raw_token, token_hash = generate_api_token()

    session = request.app.state.db_session_factory()
    try:
        token = Token(
            user_id=user["user_id"],
            token_hash=token_hash,
            label=label,
        )
        session.add(token)
        session.commit()

        tokens = session.query(Token).filter(
            Token.user_id == user["user_id"]
        ).all()
        return templates.TemplateResponse(
            request=request,
            name="tokens.html",
            context={
                "user": user,
                "tokens": tokens,
                "new_token": raw_token,
            },
        )
    finally:
        session.close()
