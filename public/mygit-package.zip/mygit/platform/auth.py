"""Authentication: register, login, sessions, CSRF, rate limiting."""

import hashlib
import hmac
import os
import secrets
import time
from typing import Optional

from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError

from mygit.platform.models import Token, User, validate_name

ph = PasswordHasher()

# Rate limiting store: IP -> (attempt_count, window_start)
_rate_limit_store: dict[str, tuple[int, float]] = {}
RATE_LIMIT_MAX = 10
RATE_LIMIT_WINDOW = 300  # 5 minutes


def hash_password(password: str) -> str:
    """Hash a password using argon2.

    Args:
        password: Plaintext password.

    Returns:
        Argon2 hash string.
    """
    return ph.hash(password)


def verify_password(password_hash: str, password: str) -> bool:
    """Verify a password against its hash.

    Args:
        password_hash: Stored argon2 hash.
        password: Plaintext password to verify.

    Returns:
        True if the password matches.
    """
    try:
        return ph.verify(password_hash, password)
    except VerifyMismatchError:
        return False


def generate_session_token() -> str:
    """Generate a cryptographically secure session token.

    Returns:
        Random hex token (64 chars).
    """
    return secrets.token_hex(32)


def generate_csrf_token() -> str:
    """Generate a CSRF token.

    Returns:
        Random hex token (32 chars).
    """
    return secrets.token_hex(16)


def generate_api_token() -> tuple[str, str]:
    """Generate an API token and its hash.

    Returns:
        (raw_token, token_hash) tuple. Raw token is shown once to the user.
    """
    raw_token = secrets.token_hex(32)
    token_hash = hashlib.sha256(raw_token.encode()).hexdigest()
    return raw_token, token_hash


def verify_api_token(raw_token: str, token_hash: str) -> bool:
    """Verify an API token against its hash.

    Args:
        raw_token: The raw API token.
        token_hash: The stored hash.

    Returns:
        True if the token matches.
    """
    computed = hashlib.sha256(raw_token.encode()).hexdigest()
    return hmac.compare_digest(computed, token_hash)


def check_rate_limit(ip: str) -> bool:
    """Check if an IP has exceeded the login rate limit.

    Args:
        ip: Client IP address.

    Returns:
        True if the request is allowed.
    """
    now = time.time()

    if ip in _rate_limit_store:
        count, window_start = _rate_limit_store[ip]
        if now - window_start > RATE_LIMIT_WINDOW:
            # Window expired, reset
            _rate_limit_store[ip] = (1, now)
            return True
        if count >= RATE_LIMIT_MAX:
            return False
        _rate_limit_store[ip] = (count + 1, window_start)
    else:
        _rate_limit_store[ip] = (1, now)

    return True


def reset_rate_limit(ip: str) -> None:
    """Reset rate limit for an IP (e.g., on successful login).

    Args:
        ip: Client IP address.
    """
    _rate_limit_store.pop(ip, None)


def validate_registration(username: str, password: str) -> Optional[str]:
    """Validate registration input.

    Args:
        username: Desired username.
        password: Desired password.

    Returns:
        Error message string, or None if valid.
    """
    if not validate_name(username):
        return "Username must match [a-zA-Z0-9._-]+ and cannot contain '..' or start with '/'"
    if len(username) < 3:
        return "Username must be at least 3 characters"
    if len(username) > 64:
        return "Username must be at most 64 characters"
    if len(password) < 8:
        return "Password must be at least 8 characters"
    return None
