"""FastAPI application factory for the mygit platform."""

import os
from typing import Optional

from fastapi import FastAPI, Request, Response
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.base import BaseHTTPMiddleware

from mygit.platform.models import Base, create_db

# Session store: token -> {user_id, username, csrf_token}
sessions: dict[str, dict] = {}


def create_app(
    db_url: Optional[str] = None,
    data_dir: Optional[str] = None,
) -> FastAPI:
    """Create and configure the FastAPI application.

    Args:
        db_url: SQLAlchemy database URL. Defaults to sqlite:///data/mygit.db.
        data_dir: Directory for repo storage. Sets MYGIT_DATA_DIR env var.

    Returns:
        Configured FastAPI application.
    """
    if data_dir:
        os.environ["MYGIT_DATA_DIR"] = data_dir

    if db_url is None:
        db_url = "sqlite:///data/mygit.db"

    SessionLocal = create_db(db_url)

    app = FastAPI(title="mygit", docs_url=None, redoc_url=None)

    # Store session factory on app state
    app.state.db_session_factory = SessionLocal
    app.state.sessions = sessions

    # Templates
    template_dir = os.path.join(os.path.dirname(__file__), "templates")
    templates = Jinja2Templates(directory=template_dir)
    app.state.templates = templates

    # Security headers middleware
    @app.middleware("http")
    async def security_headers(request: Request, call_next):
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        return response

    # Request size limit middleware (10MB)
    MAX_BODY_SIZE = 10 * 1024 * 1024

    # Include routes
    from mygit.platform.routes.auth_routes import router as auth_router
    from mygit.platform.routes.repo_routes import router as repo_router
    from mygit.platform.routes.api_routes import router as api_router
    from mygit.platform.routes.pr_routes import router as pr_router

    app.include_router(auth_router)
    app.include_router(repo_router)
    app.include_router(api_router)
    app.include_router(pr_router)

    # Health check
    @app.get("/healthz")
    async def healthz():
        return {"status": "ok"}

    # Home page
    @app.get("/", response_class=HTMLResponse)
    async def home(request: Request):
        user = get_current_user(request, app)
        return templates.TemplateResponse(
            request=request,
            name="home.html",
            context={"user": user},
        )

    return app


def run_server():
    """CLI helper to launch the web platform directly."""
    import uvicorn
    uvicorn.run("mygit.platform.app:create_app", factory=True, host="0.0.0.0", port=8000, reload=True)


def get_db(app: FastAPI):
    """Get a database session.

    Args:
        app: FastAPI application.

    Yields:
        SQLAlchemy session.
    """
    session = app.state.db_session_factory()
    try:
        yield session
    finally:
        session.close()


def get_current_user(request: Request, app: FastAPI) -> Optional[dict]:
    """Get the current user from the session cookie.

    Args:
        request: FastAPI request.
        app: FastAPI application.

    Returns:
        Dict with user info, or None if not logged in.
    """
    session_token = request.cookies.get("session_token")
    if not session_token:
        return None
    return app.state.sessions.get(session_token)


def verify_csrf(request: Request, app: FastAPI, form_token: str) -> bool:
    """Verify CSRF token from form submission.

    Args:
        request: FastAPI request.
        app: FastAPI application.
        form_token: CSRF token from the form.

    Returns:
        True if the CSRF token is valid.
    """
    user = get_current_user(request, app)
    if not user:
        return False
    return user.get("csrf_token") == form_token
