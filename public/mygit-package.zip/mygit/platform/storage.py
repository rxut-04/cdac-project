"""Repository storage management for the platform.

Bare repositories are stored at data/repos/<owner>/<name>.mygit/
"""
from __future__ import annotations

import os
import shutil
from typing import Optional

from mygit.engine.repo import MYGIT_DIR, init_repo, repo_path
from mygit.engine.objects import read_object, parse_tree, parse_commit, hash_object
from mygit.engine.refs import (
    resolve_ref,
    list_all_refs,
    list_branches,
    resolve_head,
    update_ref,
)
from mygit.engine.index import _flatten_tree
from mygit.platform.models import validate_name

DEFAULT_DATA_DIR = "data/repos"


def get_data_dir() -> str:
    """Get the data directory path from env or default.

    Returns:
        Absolute path to the data directory.
    """
    return os.environ.get("MYGIT_DATA_DIR", DEFAULT_DATA_DIR)


def get_repo_path(owner: str, name: str) -> str:
    """Get the filesystem path for a bare repository.

    Args:
        owner: Repository owner username.
        name: Repository name.

    Returns:
        Absolute path to the bare repository.

    Raises:
        ValueError: If owner or name is invalid.
    """
    if not validate_name(owner):
        raise ValueError(f"Invalid owner name: {owner}")
    if not validate_name(name):
        raise ValueError(f"Invalid repo name: {name}")

    data_dir = get_data_dir()
    return os.path.join(data_dir, owner, f"{name}.mygit")


def create_bare_repo(owner: str, name: str) -> str:
    """Create a bare repository for the platform.

    A bare repo has the same layout as .mygit/ but at the top level.
    Layout: data/repos/<owner>/<name>.mygit/{objects,refs/heads,refs/tags,HEAD}

    Args:
        owner: Repository owner username.
        name: Repository name.

    Returns:
        Path to the created repository.

    Raises:
        FileExistsError: If the repository already exists.
    """
    repo_dir = get_repo_path(owner, name)

    if os.path.exists(repo_dir):
        raise FileExistsError(f"Repository already exists: {owner}/{name}")

    os.makedirs(os.path.join(repo_dir, "objects"), exist_ok=True)
    os.makedirs(os.path.join(repo_dir, "refs", "heads"), exist_ok=True)
    os.makedirs(os.path.join(repo_dir, "refs", "tags"), exist_ok=True)

    with open(os.path.join(repo_dir, "HEAD"), "w") as f:
        f.write("ref: refs/heads/main\n")

    return repo_dir


def delete_bare_repo(owner: str, name: str) -> None:
    """Delete a bare repository.

    Args:
        owner: Repository owner username.
        name: Repository name.

    Raises:
        FileNotFoundError: If the repository doesn't exist.
    """
    repo_dir = get_repo_path(owner, name)
    if not os.path.exists(repo_dir):
        raise FileNotFoundError(f"Repository not found: {owner}/{name}")
    shutil.rmtree(repo_dir)


def bare_repo_path(owner: str, name: str, *parts: str) -> str:
    """Get a path inside a bare repository.

    Args:
        owner: Repository owner username.
        name: Repository name.
        *parts: Path components inside the repo.

    Returns:
        Absolute path.
    """
    repo_dir = get_repo_path(owner, name)
    return os.path.join(repo_dir, *parts)


def get_bare_repo_root(owner: str, name: str) -> str:
    """Get the root path of a bare repository.

    For bare repos, the repo root IS the .mygit equivalent.
    We need a wrapper that makes the engine work with bare repos.

    Args:
        owner: Repository owner.
        name: Repository name.

    Returns:
        A pseudo-root path for use with the engine.
    """
    return get_repo_path(owner, name)


class BareRepoAdapter:
    """Adapter to make the engine work with bare repos.

    In a bare repo, the objects/refs/HEAD live directly in the repo dir,
    not in a .mygit subdirectory. This adapter creates a symlink or
    provides methods that adjust paths.
    """

    def __init__(self, owner: str, name: str):
        self.owner = owner
        self.name = name
        self.bare_path = get_repo_path(owner, name)

    def objects_path(self, sha: str) -> str:
        """Get object file path."""
        return os.path.join(self.bare_path, "objects", sha[:2], sha[2:])

    def ref_path(self, ref: str) -> str:
        """Get ref file path."""
        return os.path.join(self.bare_path, ref)

    def read_object(self, sha: str) -> tuple[str, bytes]:
        """Read an object from the bare repo."""
        import zlib
        obj_file = self.objects_path(sha)
        with open(obj_file, "rb") as f:
            compressed = f.read()
        raw = zlib.decompress(compressed)
        null_idx = raw.index(b"\0")
        header = raw[:null_idx]
        body = raw[null_idx + 1:]
        obj_type = header.split(b" ", 1)[0].decode()
        return obj_type, body

    def get_tree_files_flat(self, tree_sha: Optional[str], prefix: str = "") -> dict[str, tuple[str, str]]:
        """Flatten a tree in bare repo into path -> (mode, sha)."""
        if not tree_sha:
            return {}
        _, tree_body = self.read_object(tree_sha)
        entries = parse_tree(tree_body)
        result: dict[str, tuple[str, str]] = {}
        for mode, name, sha in entries:
            full_path = f"{prefix}/{name}" if prefix else name
            if mode in ("40000", "040000"):
                result.update(self.get_tree_files_flat(sha, full_path))
            else:
                result[full_path] = (mode, sha)
        return result

    def list_refs(self) -> dict[str, str]:
        """List all refs in the bare repo."""
        result: dict[str, str] = {}
        refs_dir = os.path.join(self.bare_path, "refs")
        if not os.path.isdir(refs_dir):
            return result
        for dirpath, _dirs, files in os.walk(refs_dir):
            for name in files:
                full = os.path.join(dirpath, name)
                ref = os.path.relpath(full, self.bare_path)
                with open(full, "r") as f:
                    result[ref] = f.read().strip()
        # Also include HEAD
        head_path = os.path.join(self.bare_path, "HEAD")
        if os.path.isfile(head_path):
            with open(head_path, "r") as f:
                head_content = f.read().strip()
            if head_content.startswith("ref: "):
                ref = head_content[5:]
                ref_path = os.path.join(self.bare_path, ref)
                if os.path.isfile(ref_path):
                    with open(ref_path, "r") as f:
                        result["HEAD"] = f.read().strip()
            else:
                result["HEAD"] = head_content
        return result

    def resolve_ref(self, ref: str) -> Optional[str]:
        """Resolve a ref to a SHA."""
        ref_file = os.path.join(self.bare_path, ref)
        if os.path.isfile(ref_file):
            with open(ref_file, "r") as f:
                return f.read().strip()
        return None

    def list_branches(self) -> list[str]:
        """List branch names."""
        heads_dir = os.path.join(self.bare_path, "refs", "heads")
        if not os.path.isdir(heads_dir):
            return []
        return sorted(os.listdir(heads_dir))

    def get_tree_files(
        self, tree_sha: str, prefix: str = ""
    ) -> list[tuple[str, str, str]]:
        """Get file entries from a tree recursively.

        Returns:
            List of (mode, name, sha) with full paths.
        """
        _, body = self.read_object(tree_sha)
        entries = parse_tree(body)
        result: list[tuple[str, str, str]] = []
        for mode, name, sha in entries:
            full_path = f"{prefix}/{name}" if prefix else name
            if mode in ("40000", "040000"):
                result.extend(self.get_tree_files(sha, full_path))
            else:
                result.append((mode, full_path, sha))
        return result

    def get_commit_info(self, sha: str) -> dict:
        """Parse a commit object."""
        _, body = self.read_object(sha)
        return parse_commit(body)

    def get_blob_content(self, sha: str) -> bytes:
        """Get blob content."""
        _, body = self.read_object(sha)
        return body

    def object_exists(self, sha: str) -> bool:
        """Check if an object exists."""
        return os.path.isfile(self.objects_path(sha))

    def write_object(self, data: bytes, obj_type: str = "blob") -> str:
        """Write an object to the bare repo."""
        import hashlib
        import zlib

        header = f"{obj_type} {len(data)}\0".encode()
        full_content = header + data
        sha = hashlib.sha1(full_content).hexdigest()

        obj_dir = os.path.join(self.bare_path, "objects", sha[:2])
        obj_file = os.path.join(obj_dir, sha[2:])
        if not os.path.exists(obj_file):
            os.makedirs(obj_dir, exist_ok=True)
            compressed = zlib.compress(full_content)
            with open(obj_file, "wb") as f:
                f.write(compressed)

        return sha

    def update_ref(self, ref: str, sha: str) -> None:
        """Update a ref."""
        ref_path = os.path.join(self.bare_path, ref)
        os.makedirs(os.path.dirname(ref_path), exist_ok=True)
        with open(ref_path, "w") as f:
            f.write(sha + "\n")
