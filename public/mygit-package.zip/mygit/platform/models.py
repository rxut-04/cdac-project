"""SQLAlchemy models for the mygit platform."""

import datetime
import re
from typing import Optional

from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Enum,
    ForeignKey,
    Integer,
    String,
    Text,
    create_engine,
)
from sqlalchemy.orm import DeclarativeBase, Session, relationship, sessionmaker

# Validation regex for usernames, repo names, branch names
SAFE_NAME_RE = re.compile(r"^[a-zA-Z0-9._-]+$")


def validate_name(name: str) -> bool:
    """Validate a name against the safe regex.

    Args:
        name: Name to validate.

    Returns:
        True if the name is safe.
    """
    if not name or not SAFE_NAME_RE.match(name):
        return False
    if ".." in name or name.startswith("/") or name.startswith("\\"):
        return False
    return True


class Base(DeclarativeBase):
    """Base class for all models."""
    pass


class User(Base):
    """User account."""
    __tablename__ = "users"

    id: int = Column(Integer, primary_key=True, autoincrement=True)
    username: str = Column(String(64), unique=True, nullable=False, index=True)
    password_hash: str = Column(String(256), nullable=False)
    created_at: datetime.datetime = Column(
        DateTime, default=datetime.datetime.utcnow, nullable=False
    )

    repos = relationship("Repo", back_populates="owner_user", cascade="all, delete-orphan")
    tokens = relationship("Token", back_populates="user", cascade="all, delete-orphan")
    pull_requests = relationship("PullRequest", back_populates="author_user")
    comments = relationship("Comment", back_populates="author_user")


class Repo(Base):
    """Repository."""
    __tablename__ = "repos"

    id: int = Column(Integer, primary_key=True, autoincrement=True)
    owner: str = Column(String(64), ForeignKey("users.username"), nullable=False)
    name: str = Column(String(128), nullable=False)
    description: str = Column(Text, default="")
    is_private: bool = Column(Boolean, default=False)
    created_at: datetime.datetime = Column(
        DateTime, default=datetime.datetime.utcnow, nullable=False
    )

    owner_user = relationship("User", back_populates="repos")
    pull_requests = relationship(
        "PullRequest", back_populates="repo_obj", cascade="all, delete-orphan"
    )
    activities = relationship(
        "Activity", back_populates="repo_obj", cascade="all, delete-orphan"
    )

    __table_args__ = (
        # Unique constraint on (owner, name)
        {"sqlite_autoincrement": True},
    )


class Token(Base):
    """API/push token (hash stored, not plaintext)."""
    __tablename__ = "tokens"

    id: int = Column(Integer, primary_key=True, autoincrement=True)
    user_id: int = Column(Integer, ForeignKey("users.id"), nullable=False)
    token_hash: str = Column(String(128), nullable=False, unique=True)
    label: str = Column(String(128), default="")
    created_at: datetime.datetime = Column(
        DateTime, default=datetime.datetime.utcnow, nullable=False
    )

    user = relationship("User", back_populates="tokens")


class PullRequest(Base):
    """Pull request."""
    __tablename__ = "pull_requests"

    id: int = Column(Integer, primary_key=True, autoincrement=True)
    repo_id: int = Column(Integer, ForeignKey("repos.id"), nullable=False)
    author: str = Column(String(64), ForeignKey("users.username"), nullable=False)
    source_branch: str = Column(String(128), nullable=False)
    target_branch: str = Column(String(128), nullable=False)
    title: str = Column(String(256), nullable=False)
    body: str = Column(Text, default="")
    status: str = Column(String(16), default="open")  # open, closed, merged
    created_at: datetime.datetime = Column(
        DateTime, default=datetime.datetime.utcnow, nullable=False
    )

    repo_obj = relationship("Repo", back_populates="pull_requests")
    author_user = relationship("User", back_populates="pull_requests")
    comments = relationship(
        "Comment", back_populates="pull_request", cascade="all, delete-orphan"
    )


class Comment(Base):
    """Comment on a pull request."""
    __tablename__ = "comments"

    id: int = Column(Integer, primary_key=True, autoincrement=True)
    pr_id: int = Column(Integer, ForeignKey("pull_requests.id"), nullable=False)
    author: str = Column(String(64), ForeignKey("users.username"), nullable=False)
    body: str = Column(Text, nullable=False)
    created_at: datetime.datetime = Column(
        DateTime, default=datetime.datetime.utcnow, nullable=False
    )

    pull_request = relationship("PullRequest", back_populates="comments")
    author_user = relationship("User", back_populates="comments")


class Activity(Base):
    """Activity feed entry for post-push events."""
    __tablename__ = "activities"

    id: int = Column(Integer, primary_key=True, autoincrement=True)
    repo_id: int = Column(Integer, ForeignKey("repos.id"), nullable=False)
    actor: str = Column(String(64), nullable=False)
    action: str = Column(String(64), nullable=False)
    details: str = Column(Text, default="")
    created_at: datetime.datetime = Column(
        DateTime, default=datetime.datetime.utcnow, nullable=False
    )

    repo_obj = relationship("Repo", back_populates="activities")


def create_db(db_url: str = "sqlite:///data/mygit.db") -> sessionmaker:
    """Create the database and return a session factory.

    Args:
        db_url: SQLAlchemy database URL.

    Returns:
        A sessionmaker instance.
    """
    engine = create_engine(db_url, echo=False)
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine)
