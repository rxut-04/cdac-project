"""Phase A tests: Object store, init, hash-object, cat-file."""
from __future__ import annotations

import os
import subprocess
import tempfile
import pytest

from mygit.engine.repo import init_repo, find_repo_root, repo_path
from mygit.engine.objects import (
    hash_object,
    read_object,
    resolve_sha,
    build_tree,
    parse_tree,
    make_tree_entry,
    build_commit,
    parse_commit,
    cat_file_pretty,
)
from mygit.engine.refs import read_head


@pytest.fixture
def repo(tmp_path):
    """Create a temporary mygit repository."""
    root = str(tmp_path / "testrepo")
    os.makedirs(root)
    init_repo(root)
    return root


class TestInit:
    """Test repository initialization."""

    def test_init_creates_structure(self, tmp_path):
        """init should create .mygit with objects, refs/heads, refs/tags, HEAD."""
        root = str(tmp_path / "newrepo")
        os.makedirs(root)
        init_repo(root)

        assert os.path.isdir(os.path.join(root, ".mygit"))
        assert os.path.isdir(os.path.join(root, ".mygit", "objects"))
        assert os.path.isdir(os.path.join(root, ".mygit", "refs", "heads"))
        assert os.path.isdir(os.path.join(root, ".mygit", "refs", "tags"))
        assert os.path.isfile(os.path.join(root, ".mygit", "HEAD"))

    def test_head_content(self, tmp_path):
        """HEAD should contain 'ref: refs/heads/main'."""
        root = str(tmp_path / "newrepo")
        os.makedirs(root)
        init_repo(root)

        head = read_head(root)
        assert head == "ref: refs/heads/main"

    def test_init_already_exists(self, repo):
        """init should raise FileExistsError if .mygit already exists."""
        with pytest.raises(FileExistsError):
            init_repo(repo)

    def test_find_repo_root(self, repo):
        """find_repo_root should find the repo from a subdirectory."""
        subdir = os.path.join(repo, "sub", "deep")
        os.makedirs(subdir)
        found = find_repo_root(subdir)
        assert found == os.path.realpath(repo)

    def test_find_repo_root_not_found(self, tmp_path):
        """find_repo_root should raise FileNotFoundError if no repo."""
        with pytest.raises(FileNotFoundError):
            find_repo_root(str(tmp_path / "nonexistent"))


class TestHashObject:
    """Test blob hashing and storage."""

    def test_hash_blob(self):
        """hash_object should produce consistent SHA-1."""
        data = b"hello world\n"
        sha = hash_object(data, "blob")
        # This should match git hash-object
        assert len(sha) == 40
        assert all(c in "0123456789abcdef" for c in sha)

    def test_hash_matches_git(self, repo, tmp_path):
        """Hash produced by mygit should match real git hash-object."""
        content = b"test content for hashing\n"
        test_file = str(tmp_path / "testfile.txt")
        with open(test_file, "wb") as f:
            f.write(content)

        mygit_sha = hash_object(content, "blob")

        # Compare with real git
        result = subprocess.run(
            ["git", "hash-object", test_file],
            capture_output=True, text=True
        )
        git_sha = result.stdout.strip()

        assert mygit_sha == git_sha, f"mygit: {mygit_sha}, git: {git_sha}"

    def test_write_object(self, repo):
        """hash_object with write=True should create the object file."""
        data = b"stored content\n"
        sha = hash_object(data, "blob", write=True, root=repo)

        obj_path = os.path.join(
            repo, ".mygit", "objects", sha[:2], sha[2:]
        )
        assert os.path.isfile(obj_path)

    def test_read_object(self, repo):
        """read_object should return the original type and data."""
        data = b"round trip test\n"
        sha = hash_object(data, "blob", write=True, root=repo)

        obj_type, body = read_object(repo, sha)
        assert obj_type == "blob"
        assert body == data

    def test_idempotent_write(self, repo):
        """Writing the same object twice should not error."""
        data = b"duplicate\n"
        sha1 = hash_object(data, "blob", write=True, root=repo)
        sha2 = hash_object(data, "blob", write=True, root=repo)
        assert sha1 == sha2


class TestAbbreviatedSHA:
    """Test abbreviated SHA resolution."""

    def test_resolve_full_sha(self, repo):
        """resolve_sha should accept a full 40-char SHA."""
        data = b"resolve test\n"
        sha = hash_object(data, "blob", write=True, root=repo)
        assert resolve_sha(repo, sha) == sha

    def test_resolve_abbreviated(self, repo):
        """resolve_sha should resolve abbreviated SHAs (min 4 chars)."""
        data = b"abbrev test\n"
        sha = hash_object(data, "blob", write=True, root=repo)
        resolved = resolve_sha(repo, sha[:6])
        assert resolved == sha

    def test_resolve_too_short(self, repo):
        """resolve_sha should reject SHAs shorter than 4 chars."""
        with pytest.raises(ValueError, match="too short"):
            resolve_sha(repo, "abc")

    def test_resolve_not_found(self, repo):
        """resolve_sha should raise FileNotFoundError for missing objects."""
        with pytest.raises(FileNotFoundError):
            resolve_sha(repo, "deadbeefdeadbeefdeadbeefdeadbeefdeadbeef")


class TestTree:
    """Test tree object creation and parsing."""

    def test_build_and_parse_tree(self, repo):
        """Round-trip test for tree building and parsing."""
        # Create some blobs
        sha1 = hash_object(b"file1 content\n", "blob", write=True, root=repo)
        sha2 = hash_object(b"file2 content\n", "blob", write=True, root=repo)

        entries = [
            ("100644", "b.txt", sha2),
            ("100644", "a.txt", sha1),
        ]
        tree_data = build_tree(entries)

        # Parse it back
        parsed = parse_tree(tree_data)
        assert len(parsed) == 2
        # Should be sorted by name
        assert parsed[0][1] == "a.txt"
        assert parsed[1][1] == "b.txt"
        assert parsed[0][2] == sha1
        assert parsed[1][2] == sha2

    def test_tree_git_compatible(self, repo):
        """Tree objects should be readable by real git cat-file."""
        sha1 = hash_object(b"content a\n", "blob", write=True, root=repo)
        sha2 = hash_object(b"content b\n", "blob", write=True, root=repo)

        entries = [
            ("100644", "file_a.txt", sha1),
            ("100644", "file_b.txt", sha2),
        ]
        tree_data = build_tree(entries)
        tree_sha = hash_object(tree_data, "tree", write=True, root=repo)

        # Try reading with real git
        result = subprocess.run(
            ["git", "cat-file", "-p", tree_sha],
            capture_output=True, text=True,
            cwd=repo,
            env={**os.environ, "GIT_DIR": os.path.join(repo, ".mygit")},
        )
        assert result.returncode == 0, f"git cat-file failed: {result.stderr}"
        assert "file_a.txt" in result.stdout
        assert "file_b.txt" in result.stdout

    def test_tree_directory_sorting(self):
        """Directories should sort as if name ends with '/'."""
        sha = "a" * 40  # Dummy SHA

        entries = [
            ("100644", "foo.c", sha),
            ("040000", "foo", sha),
            ("100644", "foo.h", sha),
        ]
        tree_data = build_tree(entries)
        parsed = parse_tree(tree_data)

        names = [e[1] for e in parsed]
        # "foo" (dir, sorts as "foo/") should come after "foo.c" and "foo.h"
        # because "foo/" > "foo." > "foo.c" in ASCII
        assert names == ["foo.c", "foo.h", "foo"]

    def test_tree_with_subdirectory(self, repo):
        """Trees with subdirectories should work correctly."""
        blob_sha = hash_object(b"nested\n", "blob", write=True, root=repo)

        # Create subtree
        sub_entries = [("100644", "nested.txt", blob_sha)]
        sub_tree_data = build_tree(sub_entries)
        sub_tree_sha = hash_object(sub_tree_data, "tree", write=True, root=repo)

        # Create root tree
        root_entries = [
            ("100644", "root.txt", blob_sha),
            ("040000", "subdir", sub_tree_sha),
        ]
        root_tree_data = build_tree(root_entries)
        root_tree_sha = hash_object(root_tree_data, "tree", write=True, root=repo)

        # Verify with real git
        result = subprocess.run(
            ["git", "cat-file", "-p", root_tree_sha],
            capture_output=True, text=True,
            cwd=repo,
            env={**os.environ, "GIT_DIR": os.path.join(repo, ".mygit")},
        )
        assert result.returncode == 0
        assert "root.txt" in result.stdout
        assert "subdir" in result.stdout


class TestCommit:
    """Test commit object creation and parsing."""

    def test_build_and_parse_commit(self):
        """Round-trip test for commit building and parsing."""
        tree_sha = "a" * 40
        parent_sha = "b" * 40

        body = build_commit(
            tree_sha=tree_sha,
            parents=[parent_sha],
            author="Test Author",
            author_email="test@example.com",
            committer="Test Author",
            committer_email="test@example.com",
            message="Test commit message",
            timestamp=1700000000,
            tz_offset="+0530",
        )

        info = parse_commit(body)
        assert info["tree"] == tree_sha
        assert info["parents"] == [parent_sha]
        assert "Test Author" in info["author"]
        assert "test@example.com" in info["author"]
        assert "+0530" in info["author"]
        assert info["message"] == "Test commit message"

    def test_commit_no_parent(self):
        """First commit should have no parent lines."""
        tree_sha = "c" * 40
        body = build_commit(
            tree_sha=tree_sha,
            parents=[],
            author="Author",
            author_email="a@b.com",
            committer="Author",
            committer_email="a@b.com",
            message="Initial commit",
            timestamp=1700000000,
        )
        info = parse_commit(body)
        assert info["parents"] == []

    def test_commit_git_compatible(self, repo):
        """Commit objects should be readable by real git cat-file."""
        blob_sha = hash_object(b"hello\n", "blob", write=True, root=repo)
        tree_data = build_tree([("100644", "hello.txt", blob_sha)])
        tree_sha = hash_object(tree_data, "tree", write=True, root=repo)

        commit_body = build_commit(
            tree_sha=tree_sha,
            parents=[],
            author="Test User",
            author_email="test@test.com",
            committer="Test User",
            committer_email="test@test.com",
            message="Initial commit",
            timestamp=1700000000,
            tz_offset="+0000",
        )
        commit_sha = hash_object(commit_body, "commit", write=True, root=repo)

        result = subprocess.run(
            ["git", "cat-file", "-p", commit_sha],
            capture_output=True, text=True,
            cwd=repo,
            env={**os.environ, "GIT_DIR": os.path.join(repo, ".mygit")},
        )
        assert result.returncode == 0
        assert "tree " + tree_sha in result.stdout
        assert "Test User" in result.stdout
        assert "Initial commit" in result.stdout


class TestCatFile:
    """Test cat-file pretty printing."""

    def test_cat_file_blob(self, repo):
        """cat-file -p should display blob content."""
        data = b"pretty print me\n"
        sha = hash_object(data, "blob", write=True, root=repo)
        output = cat_file_pretty(repo, sha)
        assert output == "pretty print me\n"

    def test_cat_file_tree(self, repo):
        """cat-file -p should display tree entries."""
        blob_sha = hash_object(b"content\n", "blob", write=True, root=repo)
        tree_data = build_tree([("100644", "file.txt", blob_sha)])
        tree_sha = hash_object(tree_data, "tree", write=True, root=repo)

        output = cat_file_pretty(repo, tree_sha)
        assert "100644" in output
        assert "blob" in output
        assert "file.txt" in output
        assert blob_sha in output

    def test_cat_file_abbreviated_sha(self, repo):
        """cat-file should work with abbreviated SHAs."""
        data = b"abbreviated test\n"
        sha = hash_object(data, "blob", write=True, root=repo)
        output = cat_file_pretty(repo, sha[:6])
        assert output == "abbreviated test\n"


class TestCLI:
    """Test CLI commands for Phase A."""

    def test_cli_init(self, tmp_path):
        """CLI init should create a repository."""
        from mygit.cli import main as cli_main

        repo_dir = str(tmp_path / "cli_repo")
        os.makedirs(repo_dir)
        cli_main(["init", repo_dir])
        assert os.path.isdir(os.path.join(repo_dir, ".mygit"))

    def test_cli_hash_object(self, repo, tmp_path):
        """CLI hash-object should print SHA and optionally write."""
        import io
        from contextlib import redirect_stdout

        test_file = str(tmp_path / "hashme.txt")
        with open(test_file, "wb") as f:
            f.write(b"hash me\n")

        # Change to repo dir for find_repo_root
        old_cwd = os.getcwd()
        try:
            os.chdir(repo)
            buf = io.StringIO()
            with redirect_stdout(buf):
                from mygit.cli import main as cli_main
                cli_main(["hash-object", "-w", test_file])
            sha = buf.getvalue().strip()
            assert len(sha) == 40

            # Verify object was written
            obj_path = os.path.join(repo, ".mygit", "objects", sha[:2], sha[2:])
            assert os.path.isfile(obj_path)
        finally:
            os.chdir(old_cwd)
