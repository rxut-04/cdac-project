"""Coverage boost tests targeting specific missing lines in diff and merge."""
from __future__ import annotations

import os
from mygit.engine.repo import init_repo
from mygit.engine.objects import hash_object, build_commit, build_tree
from mygit.engine.diff import _flatten_tree, diff_trees
from mygit.engine.merge import find_merge_base


def test_merge_find_base_none(tmp_path):
    root = str(tmp_path / "repo_disjoint")
    os.makedirs(root, exist_ok=True)
    init_repo(root)

    t1 = hash_object(build_tree([]), "tree", write=True, root=root)
    c1 = hash_object(build_commit(t1, [], "A", "a@a", "A", "a@a", "Commit 1"), "commit", write=True, root=root)
    c2 = hash_object(build_commit(t1, [], "B", "b@b", "B", "b@b", "Commit 2"), "commit", write=True, root=root)

    # Completely disjoint commits
    assert find_merge_base(root, c1, c2) is None


def test_diff_trees_none_and_empty(tmp_path):
    root = str(tmp_path / "repo_diff")
    os.makedirs(root, exist_ok=True)
    init_repo(root)

    assert _flatten_tree(root, None) == {}

    b1 = hash_object(b"binary\x00data", "blob", write=True, root=root)
    t1 = hash_object(build_tree([("100644", "file.bin", b1)]), "tree", write=True, root=root)
    b2 = hash_object(b"binary\x00data2", "blob", write=True, root=root)
    t2 = hash_object(build_tree([("100644", "file.bin", b2)]), "tree", write=True, root=root)

    # Diff between binary trees
    diff_res = diff_trees(root, t1, t2)
    assert "file.bin" in diff_res
