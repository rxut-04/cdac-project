"""Test the interactive mygit dedicated shell."""

import os
from mygit.shell import MyGitShell


def test_shell_commands_execution(tmp_path):
    orig = os.getcwd()
    try:
        os.chdir(str(tmp_path))
        shell = MyGitShell()

        # Run init
        shell.onecmd("init")
        assert os.path.isdir(os.path.join(str(tmp_path), ".mygit"))

        # Create file and stage
        with open(str(tmp_path / "hello.txt"), "w") as f:
            f.write("shell test\n")

        shell.onecmd("add hello.txt")
        shell.onecmd("commit -m 'Initial from shell'")
        shell.onecmd("status")
        shell.onecmd("log --oneline")

        # Test prompt updates
        shell.update_prompt()
        assert "main" in shell.prompt

        # Test shell built-in cd/pwd
        sub = tmp_path / "subdir"
        sub.mkdir()
        shell.onecmd(f"cd {sub}")
        assert os.getcwd() == str(sub)

        # Test exit
        res = shell.onecmd("exit")
        assert res is True
    finally:
        os.chdir(orig)
