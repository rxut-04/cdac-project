"""Direct unit tests for network CLI and fetch helper functions."""

import os
import pytest
from mygit.engine.repo import init_repo
from mygit.engine.network import _download_tree_and_objects, fetch, pull, set_remote_url
from mygit.engine.objects import hash_object, build_tree


class DummyMockResponse:
    def __init__(self, content: bytes, status_code: int = 200):
        self.content = content
        self.status_code = status_code


class DummyMockClient:
    def __init__(self, objects_dict, refs_dict):
        self.objects_dict = objects_dict
        self.refs_dict = refs_dict

    def get(self, url: str):
        if url.endswith("/refs"):
            class R:
                status_code = 200
                @staticmethod
                def json():
                    return refs_dict
            return R()
        sha = url.split("/")[-1]
        if sha in self.objects_dict:
            return DummyMockResponse(self.objects_dict[sha])
        return DummyMockResponse(b"", 404)


def test_download_tree_mock(tmp_path):
    root = str(tmp_path / "mock_repo")
    os.makedirs(root, exist_ok=True)
    init_repo(root)

    # Make raw object bytes
    blob_content = b"sample blob"
    import zlib
    full_blob = f"blob {len(blob_content)}\0".encode() + blob_content
    import hashlib
    b_sha = hashlib.sha1(full_blob).hexdigest()
    b_comp = zlib.compress(full_blob)

    tree_entry = f"100644 sample.txt\0".encode() + bytes.fromhex(b_sha)
    full_tree = f"tree {len(tree_entry)}\0".encode() + tree_entry
    t_sha = hashlib.sha1(full_tree).hexdigest()
    t_comp = zlib.compress(full_tree)

    mock_client = DummyMockClient({t_sha: t_comp, b_sha: b_comp}, {})
    _download_tree_and_objects(root, "http://test", t_sha, client_module=mock_client)

    from mygit.engine.objects import object_exists
    assert object_exists(root, t_sha)
    assert object_exists(root, b_sha)
