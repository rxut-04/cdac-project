"""Phase B tests: Index, commits, history."""
from __future__ import annotations

import os
import subprocess
import pytest

from mygit.engine.repo import init_repo, repo_path
from mygit.engine.objects import hash_object, read_object, parse_commit
from mygit.engine.index import (
    read_index,
    write_index,
    add_paths,
    write_tree,
    commit,
    status,
)
from mygit.engine.refs import resolve_head, resolve_ref


@pytest.fixture
def repo(tmp_path):
    """Create a temporary mygit repository."""
    root = str(tmp_path / "testrepo")
    os.makedirs(root)
    init_repo(root)
    return root


def _write_file(root: str, path: str, content: str) -> None:
    """Helper to write a file in the repo."""
    abs_path = os.path.join(root, path)
    os.makedirs(os.path.dirname(abs_path), exist_ok=True)
    with open(abs_path, "w") as f:
        f.write(content)


class TestIndex:
    """Test index read/write."""

    def test_empty_index(self, repo):
        """Reading a non-existent index returns empty list."""
        entries = read_index(repo)
        assert entries == []

    def test_write_read_index(self, repo):
        """Round-trip test for index write and read."""
        entries = [
            ("100644", "a" * 40, "file1.txt"),
            ("100644", "b" * 40, "file2.txt"),
        ]
        write_index(repo, entries)
        read_back = read_index(repo)
        assert read_back == entries

    def test_index_sorted_by_path(self, repo):
        """Index entries should be sorted by path."""
        entries = [
            ("100644", "b" * 40, "z.txt"),
            ("100644", "a" * 40, "a.txt"),
        ]
        write_index(repo, entries)
        read_back = read_index(repo)
        assert read_back[0][2] == "a.txt"
        assert read_back[1][2] == "z.txt"


class TestAdd:
    """Test staging files."""

    def test_add_single_file(self, repo):
        """add should stage a single file."""
        _write_file(repo, "hello.txt", "hello world\n")
        add_paths(repo, ["hello.txt"])

        entries = read_index(repo)
        assert len(entries) == 1
        assert entries[0][2] == "hello.txt"
        assert entries[0][0] == "100644"

    def test_add_directory(self, repo):
        """add should recursively stage a directory."""
        _write_file(repo, "dir/a.txt", "aaa\n")
        _write_file(repo, "dir/b.txt", "bbb\n")
        add_paths(repo, ["dir"])

        entries = read_index(repo)
        assert len(entries) == 2
        paths = [e[2] for e in entries]
        assert "dir/a.txt" in paths
        assert "dir/b.txt" in paths

    def test_add_respects_mygitignore(self, repo):
        """add should skip files matching .mygitignore patterns."""
        _write_file(repo, ".mygitignore", "*.log\nbuild/\n")
        _write_file(repo, "code.py", "print('hi')\n")
        _write_file(repo, "debug.log", "log stuff\n")
        add_paths(repo, ["."])

        entries = read_index(repo)
        paths = [e[2] for e in entries]
        assert "code.py" in paths
        assert "debug.log" not in paths
        # .mygitignore itself should be addable
        assert ".mygitignore" in paths

    def test_add_updates_existing(self, repo):
        """add should update an already-staged file."""
        _write_file(repo, "file.txt", "version 1\n")
        add_paths(repo, ["file.txt"])
        sha1 = read_index(repo)[0][1]

        _write_file(repo, "file.txt", "version 2\n")
        add_paths(repo, ["file.txt"])
        sha2 = read_index(repo)[0][1]

        assert sha1 != sha2


class TestStatus:
    """Test status command."""

    def test_status_untracked(self, repo):
        """Untracked files should appear in status."""
        _write_file(repo, "new.txt", "new file\n")
        result = status(repo)
        assert "new.txt" in result["untracked"]

    def test_status_staged(self, repo):
        """Staged new files should appear."""
        _write_file(repo, "staged.txt", "staged\n")
        add_paths(repo, ["staged.txt"])
        result = status(repo)
        assert any(p == "staged.txt" for _, p in result["staged"])

    def test_status_modified(self, repo):
        """Modified files should appear."""
        _write_file(repo, "mod.txt", "original\n")
        add_paths(repo, ["mod.txt"])
        _write_file(repo, "mod.txt", "changed\n")
        result = status(repo)
        assert "mod.txt" in result["modified"]

    def test_status_deleted(self, repo):
        """Deleted files should appear."""
        _write_file(repo, "del.txt", "will delete\n")
        add_paths(repo, ["del.txt"])
        os.remove(os.path.join(repo, "del.txt"))
        result = status(repo)
        assert "del.txt" in result["deleted"]


class TestWriteTree:
    """Test tree creation from index."""

    def test_write_tree_single_file(self, repo):
        """write-tree with one file should create a valid tree."""
        _write_file(repo, "file.txt", "content\n")
        add_paths(repo, ["file.txt"])
        tree_sha = write_tree(repo)

        obj_type, body = read_object(repo, tree_sha)
        assert obj_type == "tree"

    def test_write_tree_nested(self, repo):
        """write-tree with nested directories should create subtrees."""
        _write_file(repo, "a.txt", "top level\n")
        _write_file(repo, "sub/b.txt", "nested\n")
        _write_file(repo, "sub/deep/c.txt", "deeply nested\n")
        add_paths(repo, ["."])

        tree_sha = write_tree(repo)

        # Verify with real git
        result = subprocess.run(
            ["git", "cat-file", "-p", tree_sha],
            capture_output=True, text=True,
            cwd=repo,
            env={**os.environ, "GIT_DIR": os.path.join(repo, ".mygit")},
        )
        assert result.returncode == 0
        assert "a.txt" in result.stdout
        assert "sub" in result.stdout

    def test_write_tree_empty_index(self, repo):
        """write-tree with empty index should raise ValueError."""
        with pytest.raises(ValueError, match="empty index"):
            write_tree(repo)


class TestCommit:
    """Test commit creation."""

    def test_first_commit(self, repo):
        """First commit should have no parent."""
        os.environ["MYGIT_AUTHOR_NAME"] = "Test Author"
        os.environ["MYGIT_AUTHOR_EMAIL"] = "test@example.com"
        try:
            _write_file(repo, "initial.txt", "initial content\n")
            add_paths(repo, ["initial.txt"])
            sha = commit(repo, "Initial commit")

            assert len(sha) == 40
            _, body = read_object(repo, sha)
            info = parse_commit(body)
            assert info["parents"] == []
            assert info["message"] == "Initial commit"
            assert "Test Author" in info["author"]
        finally:
            del os.environ["MYGIT_AUTHOR_NAME"]
            del os.environ["MYGIT_AUTHOR_EMAIL"]

    def test_second_commit(self, repo):
        """Second commit should have first as parent."""
        os.environ["MYGIT_AUTHOR_NAME"] = "Test"
        os.environ["MYGIT_AUTHOR_EMAIL"] = "t@t.com"
        try:
            _write_file(repo, "file.txt", "v1\n")
            add_paths(repo, ["file.txt"])
            sha1 = commit(repo, "First")

            _write_file(repo, "file.txt", "v2\n")
            add_paths(repo, ["file.txt"])
            sha2 = commit(repo, "Second")

            _, body = read_object(repo, sha2)
            info = parse_commit(body)
            assert info["parents"] == [sha1]
        finally:
            del os.environ["MYGIT_AUTHOR_NAME"]
            del os.environ["MYGIT_AUTHOR_EMAIL"]

    def test_commit_updates_branch_ref(self, repo):
        """commit should update the branch ref."""
        os.environ["MYGIT_AUTHOR_NAME"] = "Test"
        os.environ["MYGIT_AUTHOR_EMAIL"] = "t@t.com"
        try:
            _write_file(repo, "file.txt", "content\n")
            add_paths(repo, ["file.txt"])
            sha = commit(repo, "Commit")

            ref_sha = resolve_ref(repo, "refs/heads/main")
            assert ref_sha == sha
        finally:
            del os.environ["MYGIT_AUTHOR_NAME"]
            del os.environ["MYGIT_AUTHOR_EMAIL"]

    def test_git_log_reads_mygit_commits(self, repo):
        """Real git log should be able to read mygit commits."""
        os.environ["MYGIT_AUTHOR_NAME"] = "Test User"
        os.environ["MYGIT_AUTHOR_EMAIL"] = "test@test.com"
        try:
            _write_file(repo, "readme.txt", "Hello\n")
            add_paths(repo, ["readme.txt"])
            commit(repo, "Initial commit")

            _write_file(repo, "readme.txt", "Updated\n")
            add_paths(repo, ["readme.txt"])
            commit(repo, "Second commit")

            result = subprocess.run(
                ["git", "--git-dir=.mygit", "log", "--oneline"],
                capture_output=True, text=True,
                cwd=repo,
            )
            assert result.returncode == 0
            lines = result.stdout.strip().split("\n")
            assert len(lines) == 2
            assert "Second commit" in lines[0]
            assert "Initial commit" in lines[1]
        finally:
            del os.environ["MYGIT_AUTHOR_NAME"]
            del os.environ["MYGIT_AUTHOR_EMAIL"]

    def test_git_fsck_passes(self, repo):
        """Real git fsck should pass on repos created by mygit."""
        os.environ["MYGIT_AUTHOR_NAME"] = "Test User"
        os.environ["MYGIT_AUTHOR_EMAIL"] = "test@test.com"
        try:
            _write_file(repo, "file1.txt", "content 1\n")
            _write_file(repo, "dir/file2.txt", "content 2\n")
            add_paths(repo, ["."])
            commit(repo, "Commit with subdirectory")

            result = subprocess.run(
                ["git", "--git-dir=.mygit", "fsck"],
                capture_output=True, text=True,
                cwd=repo,
            )
            assert result.returncode == 0, f"git fsck failed: {result.stderr}"
        finally:
            del os.environ["MYGIT_AUTHOR_NAME"]
            del os.environ["MYGIT_AUTHOR_EMAIL"]

    def test_config_file_author(self, repo):
        """Author info should be read from .mygit/config."""
        # Remove env vars if set
        for key in ["MYGIT_AUTHOR_NAME", "MYGIT_AUTHOR_EMAIL"]:
            os.environ.pop(key, None)

        config_path = repo_path(repo, "config")
        with open(config_path, "w") as f:
            f.write("name=Config Author\nemail=config@test.com\n")

        _write_file(repo, "file.txt", "content\n")
        add_paths(repo, ["file.txt"])
        sha = commit(repo, "Config commit")

        _, body = read_object(repo, sha)
        info = parse_commit(body)
        assert "Config Author" in info["author"]
        assert "config@test.com" in info["author"]


class TestLog:
    """Test log command output."""

    def test_log_walks_parents(self, repo):
        """log should walk the parent chain."""
        os.environ["MYGIT_AUTHOR_NAME"] = "Test"
        os.environ["MYGIT_AUTHOR_EMAIL"] = "t@t.com"
        try:
            _write_file(repo, "f.txt", "1\n")
            add_paths(repo, ["f.txt"])
            sha1 = commit(repo, "First")

            _write_file(repo, "f.txt", "2\n")
            add_paths(repo, ["f.txt"])
            sha2 = commit(repo, "Second")

            _write_file(repo, "f.txt", "3\n")
            add_paths(repo, ["f.txt"])
            sha3 = commit(repo, "Third")

            # Walk from HEAD
            head = resolve_head(repo)
            assert head == sha3

            _, body = read_object(repo, sha3)
            info = parse_commit(body)
            assert info["parents"] == [sha2]

            _, body = read_object(repo, sha2)
            info = parse_commit(body)
            assert info["parents"] == [sha1]

            _, body = read_object(repo, sha1)
            info = parse_commit(body)
            assert info["parents"] == []
        finally:
            del os.environ["MYGIT_AUTHOR_NAME"]
            del os.environ["MYGIT_AUTHOR_EMAIL"]
