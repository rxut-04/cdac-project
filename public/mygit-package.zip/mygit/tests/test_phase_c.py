"""Phase C tests: Branches, checkout, diff, merge."""
from __future__ import annotations

import os
import subprocess
import pytest

from mygit.engine.repo import init_repo
from mygit.engine.objects import hash_object, read_object, parse_commit
from mygit.engine.index import (
    add_paths,
    commit,
    read_index,
    status,
    has_uncommitted_changes,
    checkout_tree,
)
from mygit.engine.refs import (
    resolve_head,
    resolve_ref,
    update_ref,
    set_head,
    get_current_branch,
    list_branches,
    list_tags,
)
from mygit.engine.diff import diff_blobs, diff_trees, diff_working_tree, diff_staged
from mygit.engine.merge import merge_branch, find_merge_base


@pytest.fixture
def repo(tmp_path):
    """Create a temporary mygit repository with initial commit."""
    root = str(tmp_path / "testrepo")
    os.makedirs(root)
    init_repo(root)
    os.environ["MYGIT_AUTHOR_NAME"] = "Test"
    os.environ["MYGIT_AUTHOR_EMAIL"] = "test@test.com"
    yield root
    os.environ.pop("MYGIT_AUTHOR_NAME", None)
    os.environ.pop("MYGIT_AUTHOR_EMAIL", None)


def _write_file(root: str, path: str, content: str) -> None:
    abs_path = os.path.join(root, path)
    os.makedirs(os.path.dirname(abs_path), exist_ok=True)
    with open(abs_path, "w") as f:
        f.write(content)


def _read_file(root: str, path: str) -> str:
    with open(os.path.join(root, path), "r") as f:
        return f.read()


def _make_commit(root: str, files: dict[str, str], msg: str) -> str:
    """Helper to write files, add, and commit."""
    for path, content in files.items():
        _write_file(root, path, content)
    add_paths(root, list(files.keys()))
    return commit(root, msg)


class TestBranch:
    """Test branch management."""

    def test_create_branch(self, repo):
        _make_commit(repo, {"f.txt": "data\n"}, "Initial")
        update_ref(repo, "refs/heads/feature", resolve_head(repo))
        branches = list_branches(repo)
        assert "feature" in branches
        assert "main" in branches

    def test_branch_points_to_head(self, repo):
        sha = _make_commit(repo, {"f.txt": "data\n"}, "Initial")
        update_ref(repo, "refs/heads/feature", sha)
        assert resolve_ref(repo, "refs/heads/feature") == sha

    def test_delete_branch(self, repo):
        _make_commit(repo, {"f.txt": "data\n"}, "Initial")
        update_ref(repo, "refs/heads/feature", resolve_head(repo))
        from mygit.engine.refs import delete_ref
        delete_ref(repo, "refs/heads/feature")
        assert "feature" not in list_branches(repo)

    def test_current_branch(self, repo):
        assert get_current_branch(repo) == "main"


class TestCheckout:
    """Test checkout."""

    def test_checkout_branch(self, repo):
        sha1 = _make_commit(repo, {"f.txt": "version1\n"}, "V1")
        update_ref(repo, "refs/heads/feature", sha1)
        set_head(repo, "ref: refs/heads/feature")

        _make_commit(repo, {"f.txt": "version2\n"}, "V2")

        # Checkout main (which still points to sha1)
        checkout_tree(repo, sha1)
        set_head(repo, "ref: refs/heads/main")

        content = _read_file(repo, "f.txt")
        assert content == "version1\n"
        assert get_current_branch(repo) == "main"

    def test_checkout_removes_extra_files(self, repo):
        sha1 = _make_commit(repo, {"a.txt": "a\n"}, "Only a")
        _make_commit(repo, {"a.txt": "a\n", "b.txt": "b\n"}, "Add b")

        checkout_tree(repo, sha1)
        assert not os.path.exists(os.path.join(repo, "b.txt"))

    def test_checkout_refuses_dirty_tree(self, repo):
        _make_commit(repo, {"f.txt": "original\n"}, "Init")
        update_ref(repo, "refs/heads/other", resolve_head(repo))

        # Modify file without committing
        _write_file(repo, "f.txt", "modified\n")

        assert has_uncommitted_changes(repo)

    def test_checkout_detached_head(self, repo):
        sha = _make_commit(repo, {"f.txt": "data\n"}, "Init")
        set_head(repo, sha)
        assert get_current_branch(repo) is None


class TestDiff:
    """Test diff generation."""

    def test_diff_blobs(self):
        old = "line1\nline2\nline3\n"
        new = "line1\nmodified\nline3\n"
        result = diff_blobs(old, new, "test.txt", "test.txt")
        assert "---" in result
        assert "+++" in result
        assert "-line2" in result
        assert "+modified" in result

    def test_diff_working_tree(self, repo):
        _make_commit(repo, {"f.txt": "original\n"}, "Init")
        _write_file(repo, "f.txt", "changed\n")
        result = diff_working_tree(repo)
        assert "-original" in result
        assert "+changed" in result

    def test_diff_staged(self, repo):
        _make_commit(repo, {"f.txt": "v1\n"}, "V1")
        _write_file(repo, "f.txt", "v2\n")
        add_paths(repo, ["f.txt"])
        result = diff_staged(repo)
        assert "-v1" in result
        assert "+v2" in result

    def test_diff_trees_new_file(self, repo):
        sha1 = _make_commit(repo, {"a.txt": "a\n"}, "Init")
        sha2 = _make_commit(repo, {"a.txt": "a\n", "b.txt": "b\n"}, "Add b")

        _, body1 = read_object(repo, sha1)
        _, body2 = read_object(repo, sha2)
        tree1 = parse_commit(body1)["tree"]
        tree2 = parse_commit(body2)["tree"]

        result = diff_trees(repo, tree1, tree2)
        assert "b.txt" in result
        assert "+b" in result


class TestTag:
    """Test tagging."""

    def test_create_tag(self, repo):
        sha = _make_commit(repo, {"f.txt": "data\n"}, "Init")
        update_ref(repo, "refs/tags/v1.0", sha)
        assert "v1.0" in list_tags(repo)
        assert resolve_ref(repo, "refs/tags/v1.0") == sha


class TestMerge:
    """Test merge operations."""

    def test_fast_forward_merge(self, repo):
        """Fast-forward merge when current branch is ancestor of target."""
        _make_commit(repo, {"f.txt": "base\n"}, "Base")
        base_sha = resolve_head(repo)

        # Create feature branch and add a commit
        update_ref(repo, "refs/heads/feature", base_sha)
        set_head(repo, "ref: refs/heads/feature")
        feature_sha = _make_commit(repo, {"f.txt": "feature\n"}, "Feature change")

        # Checkout main
        set_head(repo, "ref: refs/heads/main")
        checkout_tree(repo, base_sha)

        result = merge_branch(repo, "feature")
        assert result["fast_forward"] is True
        assert result["sha"] == feature_sha
        assert result["conflicts"] == []

        # Verify content
        assert _read_file(repo, "f.txt") == "feature\n"

    def test_clean_merge(self, repo):
        """Clean three-way merge with non-conflicting changes."""
        _make_commit(repo, {"a.txt": "a\n", "b.txt": "b\n"}, "Base")
        base_sha = resolve_head(repo)

        # Create feature branch modifying a.txt
        update_ref(repo, "refs/heads/feature", base_sha)
        set_head(repo, "ref: refs/heads/feature")
        checkout_tree(repo, base_sha)
        _make_commit(repo, {"a.txt": "a-modified\n", "b.txt": "b\n"}, "Modify a")

        # Back to main, modify b.txt
        set_head(repo, "ref: refs/heads/main")
        checkout_tree(repo, base_sha)
        _make_commit(repo, {"a.txt": "a\n", "b.txt": "b-modified\n"}, "Modify b")

        result = merge_branch(repo, "feature")
        assert result["fast_forward"] is False
        assert result["conflicts"] == []
        assert result["sha"] != ""

        # Both changes should be present
        assert _read_file(repo, "a.txt") == "a-modified\n"
        assert _read_file(repo, "b.txt") == "b-modified\n"

        # Should be a merge commit with two parents
        _, body = read_object(repo, result["sha"])
        info = parse_commit(body)
        assert len(info["parents"]) == 2

    def test_conflicting_merge(self, repo):
        """Conflicting merge should write conflict markers."""
        _make_commit(repo, {"f.txt": "base content\n"}, "Base")
        base_sha = resolve_head(repo)

        # Feature modifies f.txt
        update_ref(repo, "refs/heads/feature", base_sha)
        set_head(repo, "ref: refs/heads/feature")
        checkout_tree(repo, base_sha)
        _make_commit(repo, {"f.txt": "feature version\n"}, "Feature")

        # Main also modifies f.txt differently
        set_head(repo, "ref: refs/heads/main")
        checkout_tree(repo, base_sha)
        _make_commit(repo, {"f.txt": "main version\n"}, "Main")

        result = merge_branch(repo, "feature")
        assert result["conflicts"] == ["f.txt"]
        assert result["fast_forward"] is False

        # Check conflict markers in file
        content = _read_file(repo, "f.txt")
        assert "<<<<<<<" in content
        assert "=======" in content
        assert ">>>>>>>" in content

    def test_merge_base(self, repo):
        """find_merge_base should find LCA."""
        sha1 = _make_commit(repo, {"f.txt": "1\n"}, "C1")
        sha2 = _make_commit(repo, {"f.txt": "2\n"}, "C2")

        # Branch from sha1
        update_ref(repo, "refs/heads/feature", sha1)
        set_head(repo, "ref: refs/heads/feature")
        checkout_tree(repo, sha1)
        sha3 = _make_commit(repo, {"f.txt": "3\n"}, "C3")

        base = find_merge_base(repo, sha2, sha3)
        assert base == sha1

    def test_git_fsck_after_merge(self, repo):
        """git fsck should pass after a merge commit."""
        _make_commit(repo, {"a.txt": "a\n", "b.txt": "b\n"}, "Base")
        base_sha = resolve_head(repo)

        update_ref(repo, "refs/heads/feature", base_sha)
        set_head(repo, "ref: refs/heads/feature")
        checkout_tree(repo, base_sha)
        _make_commit(repo, {"a.txt": "a-feat\n", "b.txt": "b\n"}, "Feat")

        set_head(repo, "ref: refs/heads/main")
        checkout_tree(repo, base_sha)
        _make_commit(repo, {"a.txt": "a\n", "b.txt": "b-main\n"}, "Main")

        merge_branch(repo, "feature")

        result = subprocess.run(
            ["git", "--git-dir=.mygit", "fsck"],
            capture_output=True, text=True,
            cwd=repo,
        )
        assert result.returncode == 0, f"git fsck failed: {result.stderr}"

    def test_merge_new_file_one_side(self, repo):
        """Merge where one side adds a new file."""
        _make_commit(repo, {"base.txt": "base\n"}, "Base")
        base_sha = resolve_head(repo)

        # Feature adds new file
        update_ref(repo, "refs/heads/feature", base_sha)
        set_head(repo, "ref: refs/heads/feature")
        checkout_tree(repo, base_sha)
        _make_commit(
            repo,
            {"base.txt": "base\n", "new.txt": "new content\n"},
            "Add new",
        )

        # Main stays
        set_head(repo, "ref: refs/heads/main")
        checkout_tree(repo, base_sha)

        result = merge_branch(repo, "feature")
        # Should be fast-forward since main didn't change
        assert result["fast_forward"] is True
        assert _read_file(repo, "new.txt") == "new content\n"
