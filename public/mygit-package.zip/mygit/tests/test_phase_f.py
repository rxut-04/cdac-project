"""Phase F tests: Pull Requests, merge execution, comments, security & hardening."""

import os
import pytest
from fastapi.testclient import TestClient

from mygit.platform.app import create_app
from mygit.engine.repo import init_repo
from mygit.engine.index import add_paths, commit
from mygit.engine.network import set_remote_url, push
from mygit.engine.refs import set_head, update_ref
from mygit.platform.auth import generate_api_token
from mygit.platform.models import User, Token, PullRequest, Activity


@pytest.fixture
def pr_env(tmp_path):
    db_path = str(tmp_path / "test.db")
    data_dir = str(tmp_path / "repos")
    os.makedirs(data_dir, exist_ok=True)

    app = create_app(db_url=f"sqlite:///{db_path}", data_dir=data_dir)
    client = TestClient(app)

    # 1. Register owner
    client.post(
        "/register",
        data={"username": "owner", "password": "password123", "password_confirm": "password123"},
    )
    raw_token, token_hash = generate_api_token()

    session = app.state.db_session_factory()
    u = session.query(User).filter(User.username == "owner").first()
    tok = Token(user_id=u.id, token_hash=token_hash, label="owner-token")
    session.add(tok)
    session.commit()
    session.close()

    cookie = client.cookies["session_token"]
    csrf_token = app.state.sessions[cookie]["csrf_token"]

    # 2. Create repo
    client.post(
        "/repos/new",
        data={"name": "testrepo", "csrf_token": csrf_token},
    )

    # 3. Setup local repo and push main & feature branches
    local_repo = str(tmp_path / "local")
    init_repo(local_repo)
    os.environ["MYGIT_AUTHOR_NAME"] = "Owner"
    os.environ["MYGIT_AUTHOR_EMAIL"] = "owner@test.com"

    with open(os.path.join(local_repo, "file1.txt"), "w") as f:
        f.write("base content\n")
    add_paths(local_repo, ["."])
    commit(local_repo, "Base commit")

    repo_url = "http://testserver/owner/testrepo.mygit"
    set_remote_url(local_repo, "origin", repo_url)
    push(local_repo, "origin", "main", token=raw_token, client_module=client)

    # Create feature branch
    update_ref(local_repo, "refs/heads/feature", commit(local_repo, "touch"))
    set_head(local_repo, "ref: refs/heads/feature")
    with open(os.path.join(local_repo, "feature.txt"), "w") as f:
        f.write("feature content\n")
    add_paths(local_repo, ["."])
    commit(local_repo, "Add feature file")
    push(local_repo, "origin", "feature", token=raw_token, client_module=client)

    return {
        "app": app,
        "client": client,
        "csrf_token": csrf_token,
        "local_repo": local_repo,
        "raw_token": raw_token,
    }


class TestPullRequests:
    """Test full Pull Request flow."""

    def test_pr_create_view_comment_merge(self, pr_env):
        client = pr_env["client"]
        csrf = pr_env["csrf_token"]

        # 1. Open PR: feature -> main
        res = client.post(
            "/owner/testrepo/pulls/new",
            data={
                "title": "Add feature file",
                "body": "This adds feature.txt",
                "source_branch": "feature",
                "target_branch": "main",
                "csrf_token": csrf,
            },
            follow_redirects=False,
        )
        assert res.status_code == 303
        pr_url = res.headers["location"]

        # 2. View PR page
        view_res = client.get(pr_url)
        assert view_res.status_code == 200
        assert "Add feature file" in view_res.text
        assert "feature.txt" in view_res.text
        assert "This branch has no conflicts" in view_res.text

        # 3. Comment on PR
        comm_res = client.post(
            f"{pr_url}/comment",
            data={"body": "Looks great, merging!", "csrf_token": csrf},
            follow_redirects=False,
        )
        assert comm_res.status_code == 303

        comm_view = client.get(pr_url)
        assert "Looks great, merging!" in comm_view.text

        # 4. Merge PR
        merge_res = client.post(
            f"{pr_url}/merge",
            data={"csrf_token": csrf},
            follow_redirects=False,
        )
        assert merge_res.status_code == 303

        # Assert status is now merged
        final_view = client.get(pr_url)
        assert "Merged" in final_view.text

        # Verify main branch on repo now includes feature.txt
        repo_home = client.get("/owner/testrepo?branch=main")
        assert "feature.txt" in repo_home.text


class TestHardeningAndSecurity:
    """Test security constraints, path traversal, CSRF, and headers."""

    def test_healthz_endpoint(self, pr_env):
        client = pr_env["client"]
        res = client.get("/healthz")
        assert res.status_code == 200
        assert res.json() == {"status": "ok"}

    def test_security_headers_present(self, pr_env):
        client = pr_env["client"]
        res = client.get("/healthz")
        assert res.headers.get("X-Content-Type-Options") == "nosniff"
        assert res.headers.get("X-Frame-Options") == "DENY"
        assert res.headers.get("X-XSS-Protection") == "1; mode=block"

    def test_path_traversal_rejected_in_routes(self, pr_env):
        client = pr_env["client"]
        # Try accessing directory traversal via URL
        res = client.get("/..%2F..%2Fetc/passwd")
        # Route parser or validation should reject
        assert res.status_code in (400, 404)

    def test_post_push_hook_activity(self, pr_env):
        app = pr_env["app"]
        session = app.state.db_session_factory()
        activities = session.query(Activity).all()
        assert len(activities) >= 1
        assert activities[0].action == "push"
        session.close()
