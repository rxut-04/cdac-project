"""Phase E tests: Network sync, remote operations, web browsing."""

import os
import pytest
from fastapi.testclient import TestClient

from mygit.platform.app import create_app
from mygit.engine.repo import init_repo
from mygit.engine.index import add_paths, commit
from mygit.engine.network import set_remote_url, push, clone
from mygit.platform.auth import generate_api_token
from mygit.platform.models import Token, User


@pytest.fixture
def env(tmp_path):
    db_path = str(tmp_path / "test.db")
    data_dir = str(tmp_path / "repos")
    os.makedirs(data_dir, exist_ok=True)

    app = create_app(db_url=f"sqlite:///{db_path}", data_dir=data_dir)
    client = TestClient(app)

    # Register alice and generate a token
    client.post(
        "/register",
        data={"username": "alice", "password": "password123", "password_confirm": "password123"},
    )
    raw_token, token_hash = generate_api_token()

    session = app.state.db_session_factory()
    u = session.query(User).filter(User.username == "alice").first()
    tok = Token(user_id=u.id, token_hash=token_hash, label="test-token")
    session.add(tok)
    session.commit()
    session.close()

    token_cookie = client.cookies["session_token"]
    csrf_token = app.state.sessions[token_cookie]["csrf_token"]

    # Create repo
    client.post(
        "/repos/new",
        data={"name": "demo", "description": "Demo repo", "csrf_token": csrf_token},
    )

    return {
        "client": client,
        "token": raw_token,
        "data_dir": data_dir,
        "tmp_path": tmp_path,
    }


class TestNetworkSync:
    """Test pushing from one local repo and cloning into another via HTTP."""

    def test_push_and_clone_cycle(self, env):
        client = env["client"]
        raw_token = env["token"]
        tmp_path = env["tmp_path"]

        # 1. Setup local workdir repo A
        repo_a = str(tmp_path / "repo_a")
        os.makedirs(repo_a, exist_ok=True)
        init_repo(repo_a)

        os.environ["MYGIT_AUTHOR_NAME"] = "Alice"
        os.environ["MYGIT_AUTHOR_EMAIL"] = "alice@test.com"

        # Create files and commit
        with open(os.path.join(repo_a, "README.md"), "w") as f:
            f.write("# Hello World\nWelcome to mygit demo!\n")
        with open(os.path.join(repo_a, "app.py"), "w") as f:
            f.write("def main():\n    print('working')\n")

        add_paths(repo_a, ["."])
        commit_sha = commit(repo_a, "Initial project commit")

        # 2. Add remote & push via test client
        repo_url = "http://testserver/alice/demo.mygit"
        set_remote_url(repo_a, "origin", repo_url)

        push(repo_a, "origin", "main", token=raw_token, client_module=client)

        # 3. Verify files and README on web UI
        web_res = client.get("/alice/demo")
        assert web_res.status_code == 200
        assert "README.md" in web_res.text
        assert "app.py" in web_res.text
        assert "<h1>Hello World</h1>" in web_res.text  # Markdown rendered

        # View single file with Pygments syntax highlight
        blob_res = client.get("/alice/demo/blob/main/app.py")
        assert blob_res.status_code == 200
        assert "print" in blob_res.text
        assert "highlight" in blob_res.text

        # 4. Clone into repo B
        repo_b = str(tmp_path / "repo_b")
        clone(repo_url, repo_b, client_module=client)

        # 5. Assert repo B has identical file contents
        assert os.path.isfile(os.path.join(repo_b, "README.md"))
        assert os.path.isfile(os.path.join(repo_b, "app.py"))

        with open(os.path.join(repo_b, "README.md")) as f:
            assert f.read() == "# Hello World\nWelcome to mygit demo!\n"
        with open(os.path.join(repo_b, "app.py")) as f:
            assert f.read() == "def main():\n    print('working')\n"
