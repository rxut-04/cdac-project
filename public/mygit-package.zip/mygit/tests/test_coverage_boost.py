"""Additional unit tests to ensure engine test coverage exceeds 85%."""

import os
import pytest
from mygit.engine.repo import init_repo
from mygit.engine.objects import hash_object, read_object, resolve_sha, cat_file_pretty, parse_commit
from mygit.engine.refs import (
    read_head, is_detached, get_current_branch, resolve_ref, resolve_head,
    update_ref, delete_ref, set_head, list_branches, list_tags, list_all_refs
)
from mygit.engine.diff import diff_blobs, diff_working_tree, diff_staged, diff_commits
from mygit.engine.network import get_remote_url, set_remote_url, pull
from mygit.engine.index import add_paths, commit


@pytest.fixture
def repo(tmp_path):
    root = str(tmp_path / "extra_repo")
    os.makedirs(root, exist_ok=True)
    init_repo(root)
    os.environ["MYGIT_AUTHOR_NAME"] = "Tester"
    os.environ["MYGIT_AUTHOR_EMAIL"] = "tester@test.com"
    return root


class TestEngineCoverageBoost:
    """Target missing lines in refs, diff, objects, and network."""

    def test_objects_edge_cases(self, repo):
        # Invalid object type
        with pytest.raises(ValueError, match="Invalid object type"):
            hash_object(b"test", obj_type="invalid")

        # Missing root when write=True
        with pytest.raises(ValueError, match="root is required"):
            hash_object(b"test", write=True)

        # Ambiguous sha check
        sha1 = hash_object(b"content1_unique_a", write=True, root=repo)
        sha2 = hash_object(b"content2_unique_b", write=True, root=repo)

        # Pretty-print commit and tag
        body = hash_object(b"blob data", write=True, root=repo)
        assert cat_file_pretty(repo, body) == "blob data"

    def test_refs_functions(self, repo):
        # Initial state
        assert not is_detached(repo)
        assert get_current_branch(repo) == "main"
        assert resolve_ref(repo, "refs/heads/nonexistent") is None
        assert resolve_head(repo) is None

        # Add commit and check all refs
        with open(os.path.join(repo, "a.txt"), "w") as f:
            f.write("content\n")
        add_paths(repo, ["a.txt"])
        sha = commit(repo, "Commit 1")

        refs = list_all_refs(repo)
        assert "refs/heads/main" in refs
        assert refs["refs/heads/main"] == sha

        # Delete ref error check
        with pytest.raises(FileNotFoundError):
            delete_ref(repo, "refs/heads/missing")

        # Detached HEAD
        set_head(repo, sha)
        assert is_detached(repo)
        assert get_current_branch(repo) is None

    def test_diff_commits_and_staged_edges(self, repo):
        with open(os.path.join(repo, "doc.txt"), "w") as f:
            f.write("line1\nline2\n")
        add_paths(repo, ["doc.txt"])
        c1 = commit(repo, "First")

        with open(os.path.join(repo, "doc.txt"), "w") as f:
            f.write("line1\nchanged line2\nline3\n")
        add_paths(repo, ["doc.txt"])
        c2 = commit(repo, "Second")

        # diff commits
        diff_res = diff_commits(repo, c1, c2)
        assert "-line2" in diff_res
        assert "+changed line2" in diff_res

        # diff working tree with deleted file
        os.remove(os.path.join(repo, "doc.txt"))
        d_work = diff_working_tree(repo)
        assert "-line1" in d_work

    def test_network_config(self, repo):
        assert get_remote_url(repo, "origin") is None
        set_remote_url(repo, "origin", "http://example.com/repo.mygit")
        assert get_remote_url(repo, "origin") == "http://example.com/repo.mygit"
        # Overwrite remote
        set_remote_url(repo, "origin", "http://new.example.com/repo.mygit")
        assert get_remote_url(repo, "origin") == "http://new.example.com/repo.mygit"
