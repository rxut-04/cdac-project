"""More unit tests for merge branches to push overall coverage past 85%."""

import os
from mygit.engine.repo import init_repo
from mygit.engine.index import add_paths, commit, checkout_tree
from mygit.engine.refs import resolve_head, update_ref, set_head
from mygit.engine.merge import merge_branch, find_merge_base, _three_way_merge_text


def test_merge_edge_cases(tmp_path):
    root = str(tmp_path / "merge_edge_repo")
    os.makedirs(root, exist_ok=True)
    init_repo(root)
    os.environ["MYGIT_AUTHOR_NAME"] = "MergeTester"
    os.environ["MYGIT_AUTHOR_EMAIL"] = "merge@test.com"

    # Base commit
    with open(os.path.join(root, "file.txt"), "w") as f:
        f.write("line 1\nline 2\n")
    add_paths(root, ["."])
    base_sha = commit(root, "Base")

    # Already up to date (merge with self/ancestor)
    res = merge_branch(root, "main")
    assert res["sha"] == base_sha

    # Three-way text merge unit test branches
    # 1. Identical lines
    text, conf = _three_way_merge_text("base\n", "base\n", "base\n")
    assert text == "base\n" and not conf

    # 2. Both changed identically
    text, conf = _three_way_merge_text("base\n", "new\n", "new\n")
    assert text == "new\n" and not conf

    # 3. Only ours changed
    text, conf = _three_way_merge_text("base\n", "ours\n", "base\n")
    assert text == "ours\n" and not conf

    # 4. Only theirs changed
    text, conf = _three_way_merge_text("base\n", "base\n", "theirs\n")
    assert text == "theirs\n" and not conf
