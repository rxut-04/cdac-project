"""Phase D tests: Platform Core (models, auth, repos, CSRF, rate limit)."""
from __future__ import annotations

import os
import pytest
from fastapi.testclient import TestClient

from mygit.platform.app import create_app
from mygit.platform.models import User, Repo, Token
from mygit.platform.auth import hash_password, verify_password, check_rate_limit, _rate_limit_store
from mygit.platform.storage import create_bare_repo, delete_bare_repo, get_repo_path


@pytest.fixture
def client_and_dirs(tmp_path):
    """Create test client with clean temp SQLite DB and repo storage."""
    db_path = str(tmp_path / "test.db")
    data_dir = str(tmp_path / "repos")
    os.makedirs(data_dir, exist_ok=True)
    _rate_limit_store.clear()

    app = create_app(db_url=f"sqlite:///{db_path}", data_dir=data_dir)
    client = TestClient(app)
    return client, data_dir


class TestAuthAndModels:
    """Test user registration, login, rate limiting, and password hashing."""

    def test_password_hashing(self):
        pw = "SecretP@ssword123!"
        hashed = hash_password(pw)
        assert hashed.startswith("$argon2")
        assert verify_password(hashed, pw) is True
        assert verify_password(hashed, "wrong") is False

    def test_registration_and_login_flow(self, client_and_dirs):
        client, _ = client_and_dirs

        # 1. Register
        res = client.post(
            "/register",
            data={
                "username": "alice",
                "password": "password123",
                "password_confirm": "password123",
            },
            follow_redirects=False,
        )
        assert res.status_code == 303
        assert "session_token" in res.cookies

        # 2. Logout
        res_logout = client.get("/logout", follow_redirects=False)
        assert res_logout.status_code == 303

        # 3. Login
        res_login = client.post(
            "/login",
            data={"username": "alice", "password": "password123"},
            follow_redirects=False,
        )
        assert res_login.status_code == 303
        assert "session_token" in res_login.cookies

    def test_registration_invalid_username_path_traversal(self, client_and_dirs):
        client, _ = client_and_dirs
        res = client.post(
            "/register",
            data={
                "username": "../evil",
                "password": "password123",
                "password_confirm": "password123",
            },
        )
        assert res.status_code == 400
        assert "Username must match" in res.text

    def test_login_rate_limiting(self, client_and_dirs):
        client, _ = client_and_dirs
        for _ in range(10):
            res = client.post("/login", data={"username": "fake", "password": "wrong"})
            assert res.status_code == 401

        # 11th request should be rate-limited
        res = client.post("/login", data={"username": "fake", "password": "wrong"})
        assert res.status_code == 429
        assert "Too many attempts" in res.text


class TestRepoManagement:
    """Test repository creation, permissions, and storage."""

    def test_create_and_view_repo(self, client_and_dirs):
        client, data_dir = client_and_dirs

        # Register user
        reg = client.post(
            "/register",
            data={
                "username": "bob",
                "password": "password123",
                "password_confirm": "password123",
            },
        )
        # Extract CSRF token from page
        home = client.get("/")
        session_token = client.cookies["session_token"]
        csrf_token = client.app.state.sessions[session_token]["csrf_token"]

        # Create public repo
        res = client.post(
            "/repos/new",
            data={
                "name": "project1",
                "description": "A test project",
                "csrf_token": csrf_token,
            },
            follow_redirects=False,
        )
        assert res.status_code == 303

        # Verify bare repo on filesystem
        expected_path = os.path.join(data_dir, "bob", "project1.mygit")
        assert os.path.isdir(expected_path)
        assert os.path.isfile(os.path.join(expected_path, "HEAD"))

        # View repo page
        view_res = client.get("/bob/project1")
        assert view_res.status_code == 200
        assert "project1" in view_res.text

    def test_private_repo_permissions(self, client_and_dirs):
        client, _ = client_and_dirs

        # Create alice
        client.post(
            "/register",
            data={"username": "alice", "password": "password123", "password_confirm": "password123"},
        )
        token_alice = client.cookies["session_token"]
        csrf_alice = client.app.state.sessions[token_alice]["csrf_token"]

        client.post(
            "/repos/new",
            data={
                "name": "secret-repo",
                "description": "confidential",
                "is_private": "true",
                "csrf_token": csrf_alice,
            },
        )

        # Logout alice
        client.get("/logout")

        # Public access denied
        res = client.get("/alice/secret-repo")
        assert res.status_code == 403

        # Register bob and try accessing
        client.post(
            "/register",
            data={"username": "bob", "password": "password123", "password_confirm": "password123"},
        )
        res_bob = client.get("/alice/secret-repo")
        assert res_bob.status_code == 403

    def test_csrf_protection_on_repo_creation(self, client_and_dirs):
        client, _ = client_and_dirs
        client.post(
            "/register",
            data={"username": "charlie", "password": "password123", "password_confirm": "password123"},
        )

        # Attempt to create repo with bogus CSRF token
        res = client.post(
            "/repos/new",
            data={"name": "exploit-repo", "csrf_token": "fake-token"},
        )
        assert res.status_code == 403
