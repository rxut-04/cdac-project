"""Dedicated interactive shell/terminal for mygit.

Allows running all mygit and git-like commands in an interactive loop with
history, command completion, and direct repository operations.
"""

import cmd
import os
import shlex
import sys
from typing import List, Optional

from mygit.cli import main as cli_entrypoint
from mygit.engine.repo import find_repo_root
from mygit.engine.refs import get_current_branch, resolve_head


class MyGitShell(cmd.Cmd):
    intro = (
        "\n"
        "==========================================================\n"
        "          Welcome to the mygit Dedicated Shell           \n"
        "  Git-compatible Version Control Engine & Platform CLI   \n"
        "  Type 'help' or '?' to list commands. Type 'exit' to quit.\n"
        "==========================================================\n"
    )

    def __init__(self):
        super().__init__()
        self.update_prompt()

    def update_prompt(self):
        """Update prompt to display current working directory and git branch."""
        try:
            root = find_repo_root()
            branch = get_current_branch(root) or "detached"
            repo_name = os.path.basename(root)
            self.prompt = f"\033[1;34mmygit\033[0m:(\033[1;32m{repo_name}\033[0m) [\033[1;33m{branch}\033[0m] $ "
        except Exception:
            cwd = os.path.basename(os.getcwd()) or "/"
            self.prompt = f"\033[1;34mmygit\033[0m:(\033[1;37m{cwd}\033[0m) $ "

    def default(self, line: str):
        """Execute mygit command via the CLI engine."""
        line = line.strip()
        if not line:
            return

        parts = shlex.split(line)
        cmd_name = parts[0]

        # Handle 'git <command>' or 'mygit <command>' prefix
        if cmd_name in ("git", "mygit"):
            parts = parts[1:]
            if not parts:
                return

        # Handle built-in shell commands like cd, pwd, ls
        if parts[0] == "cd":
            target = parts[1] if len(parts) > 1 else os.path.expanduser("~")
            try:
                os.chdir(os.path.expanduser(target))
            except Exception as e:
                print(f"cd: {e}", file=sys.stderr)
            self.update_prompt()
            return

        if parts[0] == "pwd":
            print(os.getcwd())
            return

        if parts[0] == "ls":
            import subprocess
            subprocess.run(["ls", "-la"] + parts[1:])
            return

        # Shell built-in utilities & redirections (e.g. echo, cat, touch, rm, mkdir)
        shell_builtins = {
            "echo", "cat", "touch", "rm", "mkdir", "rmdir", "cp", "mv",
            "grep", "find", "head", "tail", "which", "chmod"
        }
        if parts[0] in shell_builtins or any(op in line for op in (">", ">>", "|")):
            import subprocess
            try:
                subprocess.run(line, shell=True)
            except Exception as e:
                print(f"shell error: {e}", file=sys.stderr)
            self.update_prompt()
            return

        try:
            cli_entrypoint(parts)
        except SystemExit:
            pass
        except Exception as e:
            print(f"mygit error: {e}", file=sys.stderr)

        self.update_prompt()

    def do_exit(self, arg):
        """Exit the mygit interactive terminal."""
        print("\nExiting mygit shell. Bye!")
        return True

    def do_quit(self, arg):
        """Quit the mygit interactive terminal."""
        return self.do_exit(arg)

    def do_clear(self, arg):
        """Clear the terminal screen."""
        os.system("clear" if os.name == "posix" else "cls")

    # Command autocompletion helpers
    def completedefault(self, text, line, begidx, endidx):
        commands = [
            "init", "status", "add", "commit", "log", "diff",
            "branch", "checkout", "merge", "tag", "show",
            "hash-object", "cat-file", "write-tree",
            "remote", "clone", "fetch", "pull", "push",
            "cd", "ls", "pwd", "clear", "exit", "quit"
        ]
        return [c for c in commands if c.startswith(text)]


def run_shell():
    """Start the interactive terminal."""
    try:
        shell = MyGitShell()
        shell.cmdloop()
    except KeyboardInterrupt:
        print("\nInterrupted. Exiting.")


if __name__ == "__main__":
    run_shell()
